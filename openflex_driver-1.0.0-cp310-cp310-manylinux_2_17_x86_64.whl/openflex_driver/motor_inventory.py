#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整机电机清单 — 头部 / 底盘 / 升降台

控制模式:
  - position: CSP/MIT 位置控制，支持被动/主动回零
  - velocity: 速度控制，仅使能/失能
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Literal

ControlMode = Literal["position", "velocity"]


@dataclass(frozen=True)
class MotorSpec:
    component: str
    name: str
    can_channel: str
    motor_id: int
    control_mode: ControlMode
    description: str = ""


# 头部: 2 × RS (MIT/CSP 位置)
HEAD_MOTORS: List[MotorSpec] = [
    MotorSpec("head", "yaw", "can2", 1, "position", "偏航"),
    MotorSpec("head", "pitch", "can2", 2, "position", "俯仰"),
]

# 底盘: 4 × RS 转向 (CSP 位置) + 4 × UM 驱动 (PV 速度)
CHASSIS_STEERING_MOTORS: List[MotorSpec] = [
    MotorSpec("chassis", "FL_steering", "can5", 5, "position", "左前转向"),
    MotorSpec("chassis", "FR_steering", "can5", 6, "position", "右前转向"),
    MotorSpec("chassis", "BL_steering", "can5", 7, "position", "左后转向"),
    MotorSpec("chassis", "BR_steering", "can5", 8, "position", "右后转向"),
]

CHASSIS_DRIVING_MOTORS: List[MotorSpec] = [
    MotorSpec("chassis", "FL_driving", "can4", 1, "velocity", "左前驱动"),
    MotorSpec("chassis", "FR_driving", "can4", 2, "velocity", "右前驱动"),
    MotorSpec("chassis", "BL_driving", "can4", 3, "velocity", "左后驱动"),
    MotorSpec("chassis", "BR_driving", "can4", 4, "velocity", "右后驱动"),
]

# 升降台: 1 × CANopen 伺服 (速度模式 + 位置反馈)
COLUMN_MOTORS: List[MotorSpec] = [
    MotorSpec("column", "lift_axis", "can3", 16, "position", "升降轴(速度模式)"),
]


def position_motors() -> List[MotorSpec]:
    """所有位置类电机（含升降台速度轴的位置反馈）。"""
    return [
        *HEAD_MOTORS,
        *CHASSIS_STEERING_MOTORS,
        *COLUMN_MOTORS,
    ]


def velocity_motors() -> List[MotorSpec]:
    return list(CHASSIS_DRIVING_MOTORS)
