#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四转四驱舵轮底盘上层接口

转向轮: 灵足 RS 系列 (can5, ID 5-8, CSP 位置模式)
from ._lib.um_motor_manager import (
驱动轮: UM10540 轮毂一体机 (can4, Node ID 1-4, CANopen PV 速度模式)

协议与默认配置对齐 motor_chassis 项目。
"""

import math
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Union

import can

from ._lib.motor_manager import (
    disable_motor,
    enable_motor,
    get_motor_status_readonly,
    set_control_mode,
    set_motor_zero,
    set_zero_sta_parameter,
)
from ._lib.motor_control import csp_motion_control, csp_set_speed_limits
from ._lib.auto_calibration import auto_calibrate_zero
from ._lib.swerve_kinematics import (
    ChassisSpeeds,
    SwerveDriveKinematics,
    default_module_positions,
)
from ._lib.um_motor_manager import (
    configure_um_motor_tpdo,
    disable_um_motor,
    enable_um_motor,
    parse_um_motor_pdo,
    read_um_motor_pdo,
    read_um_motor_status,
    scan_um_motors,
    set_um_motor_speed_rpm,
    stop_um_motor,
)


MODULE_NAMES = ["FL", "FR", "BL", "BR"]
MODULE_NAMES_CN = {"FL": "左前", "FR": "右前", "BL": "左后", "BR": "右后"}


@dataclass
class WheelModuleConfig:
    name: str
    steering_id: int
    driving_id: int
    driving_direction: int = 1
    steering_direction: int = 1
    steering_zero_offset_rad: float = 0.0


DEFAULT_MODULES: Dict[str, WheelModuleConfig] = {
    # driving_direction 对齐 swerve_ros2_control.urdf.xacro
    "FL": WheelModuleConfig("FL", steering_id=5, driving_id=1, driving_direction=1),
    "FR": WheelModuleConfig("FR", steering_id=6, driving_id=2, driving_direction=-1),
    "BL": WheelModuleConfig("BL", steering_id=7, driving_id=3, driving_direction=1),
    "BR": WheelModuleConfig("BR", steering_id=8, driving_id=4, driving_direction=-1),
}


class Chassis:
    """底盘管理类（RS 转向 + UM 驱动，共 8 个电机）。"""

    STEERING_MOTOR_MODEL = "RS03"

    def __init__(
        self,
        steering_can: str = "can5",
        driving_can: str = "can4",
        modules: Optional[Dict[str, WheelModuleConfig]] = None,
        steering_angle_limit_rad: float = math.pi / 2.0,
        steering_speed_limit: float = 10.0,
        steering_current_limit: float = 8.0,
        steering_timeout: float = 0.2,
        driving_max_speed_rpm: float = 330.0,
        driving_profile_accel_ms: int = 1000,
        driving_profile_decel_ms: int = 1000,
        driving_can_watchdog_timeout_ms: int = 100,
        driving_can_watchdog_action: int = 2,
        driving_tpdo_period_ms: int = 20,
        driving_position_resolution: int = 2097152,
        # 主动回零（寻限位）默认参数 — RS03 转向
        active_zero_torque: float = 1.5,
        active_zero_velocity: float = 0.3,
        active_zero_pos_per: float = 0.5,
        active_zero_max_duration: float = 20.0,
        wheel_radius: float = 0.075,
        wheelbase: float = 0.42,
        track_width: float = 0.547,
        log=None,
    ):
        self.steering_can = steering_can
        self.driving_can = driving_can
        self.modules = modules or dict(DEFAULT_MODULES)
        self.steering_angle_limit_rad = abs(float(steering_angle_limit_rad))
        self.steering_speed_limit = float(steering_speed_limit)
        self.steering_current_limit = float(steering_current_limit)
        self.steering_timeout = float(steering_timeout)
        self.driving_max_speed_rpm = float(driving_max_speed_rpm)
        self.driving_profile_accel_ms = int(driving_profile_accel_ms)
        self.driving_profile_decel_ms = int(driving_profile_decel_ms)
        self.driving_can_watchdog_timeout_ms = int(driving_can_watchdog_timeout_ms)
        self.driving_can_watchdog_action = int(driving_can_watchdog_action)
        self.driving_tpdo_period_ms = int(driving_tpdo_period_ms)
        self.driving_position_resolution = int(driving_position_resolution)
        self.active_zero_torque = float(active_zero_torque)
        self.active_zero_velocity = float(active_zero_velocity)
        self.active_zero_pos_per = float(active_zero_pos_per)
        self.active_zero_max_duration = float(active_zero_max_duration)
        self.wheel_radius = float(wheel_radius)
        self.wheelbase = float(wheelbase)
        self.track_width = float(track_width)
        self.log = log

        positions = default_module_positions(self.wheelbase, self.track_width)
        limit = self.steering_angle_limit_rad
        self._kinematics = SwerveDriveKinematics(
            positions,
            steering_min=[-limit] * 4,
            steering_max=[limit] * 4,
        )

        self._steering_bus = None
        self._connected = False
        self._enabled = False
        self._um_pdo_cache: Dict[int, dict] = {}

    @property
    def max_linear_speed_m_s(self) -> float:
        """UM 最大 RPM + 轮半径换算的线速度上限 (m/s)。"""
        return (
            (self.driving_max_speed_rpm / 60.0)
            * 2.0
            * math.pi
            * self.wheel_radius
        )

    @property
    def max_angular_speed_rad_s(self) -> float:
        """由线速度上限与最远模块到中心距离估算的角速度上限 (rad/s)。"""
        positions = default_module_positions(self.wheelbase, self.track_width)
        max_r = max(math.hypot(p.x, p.y) for p in positions)
        if max_r <= 1e-6:
            return 0.0
        return self.max_linear_speed_m_s / max_r

    @property
    def motor_ids(self) -> List[int]:
        """8 个电机 ID：RS 转向 5-8 + UM 驱动 1-4。"""
        ids = []
        for name in MODULE_NAMES:
            cfg = self.modules[name]
            ids.append(cfg.steering_id)
            ids.append(cfg.driving_id)
        return ids

    def connect(self):
        """连接 RS 转向 CAN 总线（can5）。UM 通过 driving_can 按需 SDO/TPDO 通信。"""
        if self._steering_bus is None:
            self._steering_bus = can.interface.Bus(
                channel=self.steering_can,
                bustype="socketcan",
            )
        self._connected = True
        return True

    def ensure_steering_bus(self):
        """在当前线程重建 RS CAN 总线（避免 socketcan 跨线程使能失败）。"""
        if self._steering_bus is not None:
            try:
                self._steering_bus.shutdown()
            except Exception:
                pass
            self._steering_bus = None
        self._steering_bus = can.interface.Bus(
            channel=self.steering_can,
            bustype="socketcan",
        )
        self._connected = True
        return True

    def close(self):
        """关闭底盘连接（可重复调用）。"""
        if not self._connected and self._steering_bus is None:
            return
        try:
            self.disable_all()
        except Exception:
            pass
        if self._steering_bus is not None:
            try:
                self._steering_bus.shutdown()
            except Exception:
                pass
            self._steering_bus = None
        self._connected = False
        self._enabled = False
        self._um_pdo_cache.clear()

    def _require_connected(self):
        if not self._connected or self._steering_bus is None:
            raise RuntimeError("底盘未连接，请先调用 connect()")

    def _clamp_angle(self, angle_rad: float) -> float:
        lim = self.steering_angle_limit_rad
        return max(-lim, min(lim, float(angle_rad)))

    def _clamp_speed(self, speed_rpm: float) -> float:
        lim = self.driving_max_speed_rpm
        return max(-lim, min(lim, float(speed_rpm)))

    def _steering_target_rad(self, cfg: WheelModuleConfig, angle_rad: float) -> float:
        angle = self._clamp_angle(angle_rad) * cfg.steering_direction
        return angle + cfg.steering_zero_offset_rad

    def _driving_target_rpm(self, cfg: WheelModuleConfig, speed_rpm: float) -> float:
        return self._clamp_speed(speed_rpm) * cfg.driving_direction

    def _read_steering_motor_rad(self, motor_id: int) -> Optional[float]:
        """读取 RS 转向电机原始位置（rad）。"""
        if not self._connected or self._steering_bus is None:
            return None
        state, info = get_motor_status_readonly(
            self._steering_bus,
            motor_id,
            motor_model=self.STEERING_MOTOR_MODEL,
            timeout=self.steering_timeout,
            log=self.log,
        )
        if state != 0 or not info:
            return None
        return float(info.get("angle", 0.0))

    def _enable_steering(self, motor_id: int, zero_offset_rad: float = 0.0) -> int:
        """使能单个 RS 转向电机，返回 0=成功。"""
        state = set_control_mode(
            self._steering_bus,
            motor_id,
            mode="csp",
            timeout=self.steering_timeout,
            log=self.log,
        )
        if state != 0:
            return state

        state = csp_set_speed_limits(
            self._steering_bus,
            motor_id,
            speed_limit=self.steering_speed_limit,
            current_limit=self.steering_current_limit,
            motor_model=self.STEERING_MOTOR_MODEL,
            timeout=self.steering_timeout,
            log=self.log,
        )
        if state != 0:
            return state

        state = enable_motor(
            self._steering_bus,
            motor_id,
            timeout=self.steering_timeout,
            log=self.log,
        )
        if state != 0:
            return state

        # 使能后先同步当前位置，避免跳变；设角时再移动到目标
        hold_pos = self._read_steering_motor_rad(motor_id)
        if hold_pos is None:
            hold_pos = float(zero_offset_rad)
        state = csp_motion_control(
            self._steering_bus,
            motor_id,
            hold_pos,
            component_type="chassis",
            motor_model=self.STEERING_MOTOR_MODEL,
            wait_response=True,
            timeout=self.steering_timeout,
            log=self.log,
        )
        return state

    def _enable_driving(self, node_id: int) -> bool:
        """使能单个 UM 轮毂电机。"""
        if not configure_um_motor_tpdo(
            self.driving_can,
            node_id,
            period_ms=self.driving_tpdo_period_ms,
        ):
            return False

        return enable_um_motor(
            self.driving_can,
            node_id,
            profile_accel_ms=self.driving_profile_accel_ms,
            profile_decel_ms=self.driving_profile_decel_ms,
            can_watchdog_timeout_ms=self.driving_can_watchdog_timeout_ms,
            can_watchdog_action=self.driving_can_watchdog_action,
        )

    def enable_module(self, module: str) -> Dict[str, int]:
        """使能单个舵轮模块（RS + UM）。"""
        self._require_connected()
        name = module.upper()
        if name not in self.modules:
            raise ValueError(f"无效模块名: {module}, 可选: {MODULE_NAMES}")

        cfg = self.modules[name]
        results = {}

        rs_state = self._enable_steering(cfg.steering_id, cfg.steering_zero_offset_rad)
        results[f"RS{cfg.steering_id}"] = rs_state
        if rs_state != 0:
            raise RuntimeError(f"[{name}] RS({cfg.steering_id}) 使能失败, state={rs_state}")

        time.sleep(0.01)
        um_ok = self._enable_driving(cfg.driving_id)
        results[f"UM{cfg.driving_id}"] = 0 if um_ok else 1
        if not um_ok:
            raise RuntimeError(f"[{name}] UM({cfg.driving_id}) 使能失败")

        time.sleep(0.02)
        return results

    def disable_module(self, module: str):
        """失能单个舵轮模块。"""
        if not self._connected:
            return
        name = module.upper()
        if name not in self.modules:
            raise ValueError(f"无效模块名: {module}, 可选: {MODULE_NAMES}")

        cfg = self.modules[name]
        try:
            stop_um_motor(self.driving_can, cfg.driving_id)
            disable_um_motor(self.driving_can, cfg.driving_id)
        except Exception:
            pass
        if self._steering_bus is not None:
            try:
                disable_motor(
                    self._steering_bus,
                    cfg.steering_id,
                    timeout=self.steering_timeout,
                    log=self.log,
                )
            except Exception:
                pass

    def enable_all(self):
        """使能全部 4 个模块（8 个电机）。"""
        self._require_connected()
        for name in MODULE_NAMES:
            self.enable_module(name)
        self._enabled = True
        return True

    def enable_all_motors(self, verbose: bool = False) -> Dict[int, int]:
        """
        Robot 兼容接口：使能全部底盘电机。

        返回:
            {motor_id: state}，RS 使用 5-8，UM 使用 1-4；0=成功，非0=失败。
        """
        results: Dict[int, int] = {}
        try:
            self._require_connected()
            for name in MODULE_NAMES:
                cfg = self.modules[name]
                try:
                    rs_state = self.enable_steering_motor(cfg.steering_id)
                    results[cfg.steering_id] = rs_state
                    if rs_state != 0:
                        if verbose:
                            print(f"[{name}] RS({cfg.steering_id}) 使能失败")
                        continue
                    time.sleep(0.01)
                    um_ok = self.enable_driving_motor(cfg.driving_id)
                    results[cfg.driving_id] = 0 if um_ok else 1
                    if not um_ok and verbose:
                        print(f"[{name}] UM({cfg.driving_id}) 使能失败")
                    time.sleep(0.02)
                except Exception as exc:
                    results[cfg.steering_id] = 1
                    results[cfg.driving_id] = 1
                    if verbose:
                        print(f"[{name}] 使能异常: {exc}")
            self._enabled = all(
                results.get(self.modules[n].steering_id, 1) == 0
                and results.get(self.modules[n].driving_id, 1) == 0
                for n in MODULE_NAMES
            )
            return results
        except Exception:
            for name in MODULE_NAMES:
                cfg = self.modules[name]
                results.setdefault(cfg.steering_id, 1)
                results.setdefault(cfg.driving_id, 1)
            return results

    def disable_all(self):
        """失能全部模块。"""
        if not self._connected:
            return True
        for name in MODULE_NAMES:
            self.disable_module(name)
        self._enabled = False
        return True

    def disable_all_motors(self, verbose: bool = False) -> Dict[int, int]:
        """Robot 兼容接口：失能全部底盘电机。"""
        results: Dict[int, int] = {}
        for name in MODULE_NAMES:
            cfg = self.modules[name]
            try:
                stop_um_motor(self.driving_can, cfg.driving_id)
                um_ok = self.disable_driving_motor(cfg.driving_id)
                results[cfg.driving_id] = 0 if um_ok else 1
            except Exception:
                results[cfg.driving_id] = 1

            if self._steering_bus is not None:
                try:
                    rs_state = self.disable_steering_motor(cfg.steering_id)
                    results[cfg.steering_id] = rs_state
                except Exception:
                    results[cfg.steering_id] = 1

        self._enabled = False
        return results

    def _module_for_steering_id(self, motor_id: int) -> str:
        for name, cfg in self.modules.items():
            if cfg.steering_id == motor_id:
                return name
        raise ValueError(f"无效 RS 转向电机 ID: {motor_id}, 期望 {self._steering_ids()}")

    def _module_for_driving_id(self, node_id: int) -> str:
        for name, cfg in self.modules.items():
            if cfg.driving_id == node_id:
                return name
        raise ValueError(f"无效 UM 驱动电机 ID: {node_id}, 期望 {self._driving_ids()}")

    def _steering_ids(self) -> List[int]:
        return [self.modules[n].steering_id for n in MODULE_NAMES]

    def _driving_ids(self) -> List[int]:
        return [self.modules[n].driving_id for n in MODULE_NAMES]

    def enable_steering_motor(self, motor_id: int) -> int:
        """使能单个 RS 转向电机（CSP 位置模式）。"""
        self._require_connected()
        name = self._module_for_steering_id(motor_id)
        cfg = self.modules[name]
        return self._enable_steering(motor_id, cfg.steering_zero_offset_rad)

    def disable_steering_motor(self, motor_id: int) -> int:
        """失能单个 RS 转向电机。"""
        if not self._connected or self._steering_bus is None:
            return 0
        self._module_for_steering_id(motor_id)
        return disable_motor(
            self._steering_bus,
            motor_id,
            timeout=self.steering_timeout,
            log=self.log,
        )

    def enable_driving_motor(self, node_id: int) -> bool:
        """使能单个 UM 轮毂驱动电机（PV 速度模式）。"""
        self._require_connected()
        self._module_for_driving_id(node_id)
        return self._enable_driving(node_id)

    def disable_driving_motor(self, node_id: int) -> bool:
        """失能单个 UM 轮毂驱动电机。"""
        if not self._connected:
            return True
        self._module_for_driving_id(node_id)
        try:
            stop_um_motor(self.driving_can, node_id)
            return disable_um_motor(self.driving_can, node_id)
        except Exception:
            return False

    def set_steering_motor_zero_passive(
        self,
        motor_id: int,
        zero_sta: int = 1,
        tolerance_rad: float = 0.05,
    ) -> dict:
        """单个 RS 转向电机被动回零。"""
        self._require_connected()
        name = self._module_for_steering_id(motor_id)
        result = self._passive_zero_steering_motor(
            motor_id, zero_sta=zero_sta, tolerance_rad=tolerance_rad
        )
        result["module"] = name
        result["name_cn"] = MODULE_NAMES_CN.get(name, name)
        if result["success"]:
            self.modules[name].steering_zero_offset_rad = 0.0
            self._enabled = False
        return result

    def set_steering_motor_zero_active(
        self,
        motor_id: int,
        zero_pos_per: Optional[float] = None,
        control_torque: Optional[float] = None,
        control_velocity: Optional[float] = None,
        max_duration: Optional[float] = None,
        tolerance_rad: float = 0.05,
    ) -> dict:
        """单个 RS 转向电机主动回零（双限位取中点）。"""
        self._require_connected()
        name = self._module_for_steering_id(motor_id)
        results = self.set_steering_zero_active(
            modules=[name],
            zero_pos_per=zero_pos_per,
            control_torque=control_torque,
            control_velocity=control_velocity,
            max_duration=max_duration,
            tolerance_rad=tolerance_rad,
        )
        return results.get(name, {"motor_id": motor_id, "success": False, "error": "未知错误"})

    def _module_cfg(self, module: str) -> WheelModuleConfig:
        name = module.upper()
        if name not in self.modules:
            raise ValueError(f"无效模块名: {module}, 可选: {MODULE_NAMES}")
        return self.modules[name]

    def set_steering_angle(self, module: str, angle_rad: float):
        """下发 RS 转向目标角度（rad，逻辑坐标）。"""
        self._require_connected()
        cfg = self._module_cfg(module)
        target = self._steering_target_rad(cfg, angle_rad)
        state = csp_motion_control(
            self._steering_bus,
            cfg.steering_id,
            target,
            component_type="chassis",
            motor_model=self.STEERING_MOTOR_MODEL,
            wait_response=True,
            timeout=self.steering_timeout,
            log=self.log,
        )
        if state != 0:
            raise RuntimeError(f"RS({cfg.steering_id}) 角度下发失败, state={state}")

    def set_steering_angle_deg(self, module: str, angle_deg: float):
        self.set_steering_angle(module, math.radians(angle_deg))

    def read_module_steering_angle_deg(self, module: str) -> Optional[float]:
        """
        读取 RS 转向逻辑角度（度），与 set_steering_angle_deg 同一坐标系。

        返回:
            逻辑角度；离线或无反馈时返回 None。
        """
        self._require_connected()
        cfg = self._module_cfg(module)
        state, info = get_motor_status_readonly(
            self._steering_bus,
            cfg.steering_id,
            motor_model=self.STEERING_MOTOR_MODEL,
            timeout=self.steering_timeout,
            log=self.log,
        )
        if state != 0 or not info:
            return None
        motor_rad = float(info.get("angle", 0.0))
        direction = cfg.steering_direction if cfg.steering_direction else 1
        logical_rad = (motor_rad - cfg.steering_zero_offset_rad) / direction
        return math.degrees(logical_rad)

    def adjust_steering_angle_deg(self, module: str, delta_deg: float) -> float:
        """
        按步长相对调节 RS 转向角度（度）。

        先读当前反馈角度，加上 delta_deg 后下发绝对目标。
        """
        current = self.read_module_steering_angle_deg(module)
        if current is None:
            raise RuntimeError(f"RS({self._module_cfg(module).steering_id}) 无角度反馈")
        new_deg = current + float(delta_deg)
        self.set_steering_angle_deg(module, new_deg)
        return new_deg

    def read_module_driving_speed_rpm(self, module: str) -> Optional[float]:
        """读取 UM 驱动实际轮速（RPM，逻辑方向）。"""
        self._require_connected()
        cfg = self._module_cfg(module)
        pdo = read_um_motor_pdo(self.driving_can, cfg.driving_id, timeout=0.05)
        if pdo is not None:
            parsed = parse_um_motor_pdo(
                pdo,
                direction=cfg.driving_direction,
                position_resolution=self.driving_position_resolution,
            )
            if parsed.get("velocity_rpm") is not None:
                return float(parsed["velocity_rpm"])
        um_info = read_um_motor_status(self.driving_can, cfg.driving_id)
        if um_info:
            vel = um_info.get("velocity_rpm") or um_info.get("velocity_01rpm")
            if vel is not None:
                rpm = float(vel) / 10.0 if um_info.get("velocity_01rpm") else float(vel)
                return rpm * cfg.driving_direction
        return None

    def adjust_driving_speed_rpm(
        self,
        module: str,
        delta_rpm: float,
        base_rpm: Optional[float] = None,
    ) -> float:
        """
        按步长相对调节 UM 目标速度（RPM）。

        base_rpm 为当前目标；未提供时从 0 起算（PV 模式以指令目标为基准，非反馈速度）。
        """
        if base_rpm is None:
            base_rpm = 0.0
        new_rpm = self._clamp_speed(float(base_rpm) + float(delta_rpm))
        self.set_driving_speed_rpm(module, new_rpm)
        return new_rpm

    def set_driving_speed_rpm(self, module: str, speed_rpm: float):
        """仅下发 UM 驱动速度（RPM）。"""
        self._require_connected()
        cfg = self._module_cfg(module)
        speed = self._driving_target_rpm(cfg, speed_rpm)
        ok = set_um_motor_speed_rpm(
            self.driving_can,
            cfg.driving_id,
            speed,
            max_speed_rpm=self.driving_max_speed_rpm,
        )
        if not ok:
            raise RuntimeError(f"UM({cfg.driving_id}) 速度下发失败")

    def set_module_command(self, module: str, angle_rad: float, speed_rpm: float):
        """设置单个模块目标（角度 rad + 轮速 RPM）。"""
        self.set_steering_angle(module, angle_rad)
        self.set_driving_speed_rpm(module, speed_rpm)

    def set_module_command_deg(self, module: str, angle_deg: float, speed_rpm: float):
        self.set_module_command(module, math.radians(angle_deg), speed_rpm)

    def set_chassis_command(self, commands: Dict[str, Dict[str, float]]):
        """
        批量设置模块命令:
        commands = {"FL": {"angle_rad": 0.1, "speed_rpm": 30}, ...}
        也支持 angle_deg 键。
        """
        self._require_connected()
        for name, cmd in commands.items():
            if "angle_deg" in cmd:
                angle = math.radians(cmd["angle_deg"])
            else:
                angle = cmd.get("angle_rad", 0.0)
            self.set_module_command(name, angle, cmd.get("speed_rpm", 0.0))

    def _wheel_speed_ms_to_rpm(self, speed_ms: float) -> float:
        if self.wheel_radius <= 0:
            return 0.0
        wheel_rpm = (speed_ms / (2.0 * math.pi * self.wheel_radius)) * 60.0
        return wheel_rpm

    def _read_steering_angles_rad(self) -> List[float]:
        angles: List[float] = []
        for name in MODULE_NAMES:
            deg = self.read_module_steering_angle_deg(name)
            angles.append(math.radians(deg) if deg is not None else 0.0)
        return angles

    def compute_module_commands_from_velocity(
        self, vx: float, vy: float, omega: float = 0.0
    ) -> Dict[str, Dict[str, float]]:
        """逆运动学：底盘 vx/vy/omega → 各模块 angle_deg / speed_rpm。"""
        current = self._read_steering_angles_rad()
        states = self._kinematics.to_module_states(
            ChassisSpeeds(vx, vy, omega), current
        )
        max_wheel_ms = (
            (self.driving_max_speed_rpm / 60.0)
            * 2.0
            * math.pi
            * self.wheel_radius
        )
        SwerveDriveKinematics.desaturate_wheel_speeds(states, max_wheel_ms)
        out: Dict[str, Dict[str, float]] = {}
        for i, name in enumerate(MODULE_NAMES):
            st = states[i]
            out[name] = {
                "angle_deg": math.degrees(st.angle),
                "speed_rpm": self._wheel_speed_ms_to_rpm(st.speed),
            }
        return out

    def set_chassis_velocity(self, vx: float, vy: float = 0.0, omega: float = 0.0):
        """
        整车速度控制（逆运动学 + 下发 RS/UM 命令）。

        vx: 前进 m/s；vy: 左移 m/s（y 向左为正）；omega: 逆时针 rad/s。
        """
        self._require_connected()
        cmds = self.compute_module_commands_from_velocity(vx, vy, omega)
        for name in MODULE_NAMES:
            c = cmds[name]
            self.set_module_command(
                name, math.radians(c["angle_deg"]), c["speed_rpm"]
            )
        return True

    def stop_motion(self):
        """停止整车运动（四轮驱动速度归零）。"""
        return self.stop_all_driving()

    def move_forward(self, speed_m_s: float):
        return self.set_chassis_velocity(abs(float(speed_m_s)), 0.0, 0.0)

    def move_backward(self, speed_m_s: float):
        return self.set_chassis_velocity(-abs(float(speed_m_s)), 0.0, 0.0)

    def move_left(self, speed_m_s: float):
        return self.set_chassis_velocity(0.0, abs(float(speed_m_s)), 0.0)

    def move_right(self, speed_m_s: float):
        return self.set_chassis_velocity(0.0, -abs(float(speed_m_s)), 0.0)

    def rotate_in_place(self, omega_rad_s: float):
        return self.set_chassis_velocity(0.0, 0.0, float(omega_rad_s))

    def stop_all_driving(self):
        """仅停止四个 UM 驱动轮。"""
        for name in MODULE_NAMES:
            cfg = self.modules[name]
            stop_um_motor(self.driving_can, cfg.driving_id)
        return True

    def stop_module_driving(self, module: str):
        cfg = self._module_cfg(module)
        stop_um_motor(self.driving_can, cfg.driving_id)

    def go_steering_home(
        self,
        modules: Optional[Union[str, List[str]]] = None,
        angle_tolerance_deg: float = 1.0,
    ) -> Dict[str, dict]:
        """
        回零：将 RS 转向运动到已标定的逻辑零点 (0°)。

        需先完成手动/自动设零；本方法仅下发 CSP 目标角度，不写机械零点。
        """
        self._require_connected()
        target_names = self._resolve_steering_modules(modules)
        results: Dict[str, dict] = {}

        for name in target_names:
            if name not in self.modules:
                raise ValueError(f"无效模块名: {name}, 可选: {MODULE_NAMES}")

            cfg = self.modules[name]
            result = {
                "module": name,
                "name_cn": MODULE_NAMES_CN.get(name, name),
                "motor_id": cfg.steering_id,
                "mode": "go_home",
                "success": False,
            }
            try:
                self.set_steering_angle(name, 0.0)
                time.sleep(0.05)
                deg = self.read_module_steering_angle_deg(name)
                result["angle_deg"] = deg
                if deg is None:
                    result["error"] = "无角度反馈"
                elif abs(deg) <= angle_tolerance_deg:
                    result["success"] = True
                else:
                    result["error"] = f"未到达零点 (当前 {deg:+.2f}°)"
            except Exception as exc:
                result["error"] = str(exc)
            results[name] = result

        return results

    def set_all_steering_zero(self):
        """将全部转向轮转到逻辑零点 (0 rad)。"""
        self._require_connected()
        for name in MODULE_NAMES:
            self.set_steering_angle(name, 0.0)
        return True

    def all_to_zero(self):
        """别名：全部转向回零。"""
        return self.set_all_steering_zero()

    def set_steering_zero_manual(
        self,
        modules: Optional[Union[str, List[str]]] = None,
        zero_sta: int = 1,
        tolerance_rad: float = 0.05,
    ) -> Dict[str, dict]:
        """手动设零：将当前位置写为机械零点。"""
        return self.set_steering_zero_passive(
            modules=modules,
            zero_sta=zero_sta,
            tolerance_rad=tolerance_rad,
        )

    def set_steering_zero_auto(
        self,
        modules: Optional[Union[str, List[str]]] = None,
        zero_pos_per: Optional[float] = None,
        control_torque: Optional[float] = None,
        control_velocity: Optional[float] = None,
        max_duration: Optional[float] = None,
        tolerance_rad: float = 0.05,
    ) -> Dict[str, dict]:
        """自动设零：寻双限位取中点后写机械零点。"""
        return self.set_steering_zero_active(
            modules=modules,
            zero_pos_per=zero_pos_per,
            control_torque=control_torque,
            control_velocity=control_velocity,
            max_duration=max_duration,
            tolerance_rad=tolerance_rad,
        )

    def _resolve_steering_modules(
        self, modules: Optional[Union[str, List[str]]] = None
    ) -> List[str]:
        if modules is None:
            return list(MODULE_NAMES)
        if isinstance(modules, str):
            return [modules.upper()]
        return [m.upper() for m in modules]

    def _passive_zero_steering_motor(
        self,
        motor_id: int,
        zero_sta: int = 1,
        tolerance_rad: float = 0.05,
    ) -> dict:
        """
        被动回零：将 RS 转向电机当前位置写为机械零点。

        使用前需手动将转向轮转到期望零位（通常为直行位置）。
        """
        result = {
            "motor_id": motor_id,
            "mode": "manual",
            "success": False,
        }

        rs_state, rs_info = get_motor_status_readonly(
            self._steering_bus,
            motor_id,
            motor_model=self.STEERING_MOTOR_MODEL,
            timeout=self.steering_timeout,
            log=self.log,
        )
        result["online"] = rs_state == 0 and rs_info is not None
        result["before_pos"] = rs_info.get("angle") if rs_info else None
        if not result["online"]:
            result["error"] = "电机离线或无反馈"
            return result

        disable_motor(
            self._steering_bus,
            motor_id,
            timeout=self.steering_timeout,
            log=self.log,
        )
        time.sleep(0.02)

        set_zero_sta_parameter(
            self._steering_bus,
            motor_id,
            zero_sta,
            timeout=self.steering_timeout,
            log=self.log,
        )
        time.sleep(0.05)

        zero_state = set_motor_zero(
            self._steering_bus,
            motor_id,
            component_type="chassis",
            motor_model=self.STEERING_MOTOR_MODEL,
            timeout=1.0,
            log=self.log,
        )
        time.sleep(0.1)

        verify_state, verify_info = get_motor_status_readonly(
            self._steering_bus,
            motor_id,
            motor_model=self.STEERING_MOTOR_MODEL,
            timeout=self.steering_timeout,
            log=self.log,
        )
        after_pos = verify_info.get("angle") if verify_info else None
        result["after_pos"] = after_pos
        result["success"] = (
            zero_state == 0
            and verify_state == 0
            and after_pos is not None
            and abs(after_pos) <= tolerance_rad
        )
        if not result["success"]:
            result["error"] = "零点验证未通过"
        return result

    def set_steering_zero_passive(
        self,
        modules: Optional[Union[str, List[str]]] = None,
        zero_sta: int = 1,
        tolerance_rad: float = 0.05,
    ) -> Dict[str, dict]:
        """
        手动设零（RS 转向）：对指定模块将当前位置设为机械零点。

        轮毂电机 (UM) 无需零点。使用前请手动将转向轮转到期望零位。

        参数:
            modules: FL/FR/BL/BR 或列表，None 表示全部
            zero_sta: 1 = 角度量程 -π~π
            tolerance_rad: 设零后位置容差
        """
        self._require_connected()
        target_names = self._resolve_steering_modules(modules)
        results = {}

        for name in target_names:
            if name not in self.modules:
                raise ValueError(f"无效模块名: {name}, 可选: {MODULE_NAMES}")

            cfg = self.modules[name]
            motor_id = cfg.steering_id
            result = self._passive_zero_steering_motor(
                motor_id,
                zero_sta=zero_sta,
                tolerance_rad=tolerance_rad,
            )
            result["module"] = name
            result["name_cn"] = MODULE_NAMES_CN.get(name, name)
            if result["success"]:
                cfg.steering_zero_offset_rad = 0.0
            results[name] = result

        if any(r.get("success") for r in results.values()):
            self._enabled = False
        return results

    def set_steering_zero_active(
        self,
        modules: Optional[Union[str, List[str]]] = None,
        zero_pos_per: Optional[float] = None,
        control_torque: Optional[float] = None,
        control_velocity: Optional[float] = None,
        max_duration: Optional[float] = None,
        tolerance_rad: float = 0.05,
    ) -> Dict[str, dict]:
        """
        自动设零（RS 转向）：自动寻正负限位，再移动到零点位置并写入机械零点。

        流程（每个转向电机）:
            1. 切换 MIT 模式
            2. 正向运动至机械限位 → 记录位置 A
            3. 反向运动至机械限位 → 记录位置 B
            4. 计算零点 C = B + (A - B) * zero_pos_per（默认 0.5 为中点）
            5. 移动到 C 后失能，写入机械零点

        轮毂电机 (UM) 不参与此流程。

        参数:
            zero_pos_per: 零点在行程中的比例，0.5=中点
            control_torque: 寻限位控制力矩 (Nm)
            control_velocity: 寻限位速度 (rad/s)
            max_duration: 单次寻限位最大时间 (s)
        """
        self._require_connected()

        zero_pos_per = self.active_zero_pos_per if zero_pos_per is None else float(zero_pos_per)
        control_torque = self.active_zero_torque if control_torque is None else float(control_torque)
        control_velocity = self.active_zero_velocity if control_velocity is None else float(control_velocity)
        max_duration = self.active_zero_max_duration if max_duration is None else float(max_duration)

        target_names = self._resolve_steering_modules(modules)
        results = {}

        for name in target_names:
            if name not in self.modules:
                raise ValueError(f"无效模块名: {name}, 可选: {MODULE_NAMES}")

            cfg = self.modules[name]
            motor_id = cfg.steering_id
            result = {
                "module": name,
                "name_cn": MODULE_NAMES_CN.get(name, name),
                "motor_id": motor_id,
                "mode": "auto",
                "zero_pos_per": zero_pos_per,
                "success": False,
            }

            try:
                disable_motor(
                    self._steering_bus,
                    motor_id,
                    timeout=self.steering_timeout,
                    log=self.log,
                )
                time.sleep(0.05)

                mode_state = set_control_mode(
                    self._steering_bus,
                    motor_id,
                    mode="mit",
                    timeout=self.steering_timeout,
                    log=self.log,
                )
                if mode_state != 0:
                    result["error"] = f"切换 MIT 模式失败, state={mode_state}"
                    results[name] = result
                    continue

                success, zero_pos, pos_limit, neg_limit = auto_calibrate_zero(
                    self._steering_bus,
                    motor_id,
                    control_torque=control_torque,
                    control_velocity=control_velocity,
                    max_duration=max_duration,
                    zero_pos_per=zero_pos_per,
                    component_type="chassis",
                    motor_model=self.STEERING_MOTOR_MODEL,
                    verbose=False,
                    log=self.log,
                )

                result["pos_limit"] = pos_limit
                result["neg_limit"] = neg_limit
                result["computed_zero"] = zero_pos

                if not success:
                    result["error"] = "主动寻限位或设零失败"
                    results[name] = result
                    continue

                verify_state, verify_info = get_motor_status_readonly(
                    self._steering_bus,
                    motor_id,
                    motor_model=self.STEERING_MOTOR_MODEL,
                    timeout=self.steering_timeout,
                    log=self.log,
                )
                after_pos = verify_info.get("angle") if verify_info else None
                result["after_pos"] = after_pos
                result["success"] = (
                    verify_state == 0
                    and after_pos is not None
                    and abs(after_pos) <= tolerance_rad
                )
                if result["success"]:
                    cfg.steering_zero_offset_rad = 0.0
                else:
                    result["error"] = "主动回零后位置验证未通过"

            except Exception as exc:
                result["error"] = str(exc)

            results[name] = result
            time.sleep(0.2)

        if any(r.get("success") for r in results.values()):
            self._enabled = False
        return results

    def set_steering_zero_hw(
        self,
        modules: Optional[Union[str, List[str]]] = None,
        zero_sta: int = 1,
        tolerance_rad: float = 0.05,
    ) -> Dict[str, dict]:
        """兼容旧名：等同 set_steering_zero_passive（被动回零）。"""
        return self.set_steering_zero_passive(
            modules=modules,
            zero_sta=zero_sta,
            tolerance_rad=tolerance_rad,
        )

    def _refresh_um_pdo(self, timeout: float = 0.03):
        """批量读取 UM TPDO1 并更新缓存。"""
        deadline = time.time() + timeout
        pending = {self.modules[n].driving_id for n in MODULE_NAMES}

        while pending and time.time() < deadline:
            for node_id in list(pending):
                pdo_data = read_um_motor_pdo(self.driving_can, node_id, timeout=0.02)
                if pdo_data is None:
                    continue
                cfg = next(c for c in self.modules.values() if c.driving_id == node_id)
                parsed = parse_um_motor_pdo(
                    pdo_data,
                    direction=cfg.driving_direction,
                    position_resolution=self.driving_position_resolution,
                )
                self._um_pdo_cache[node_id] = parsed
                pending.discard(node_id)

    def refresh_status(self, timeout: float = 0.05):
        """快速刷新 RS 反馈 + UM TPDO。"""
        self._require_connected()
        for name in MODULE_NAMES:
            cfg = self.modules[name]
            get_motor_status_readonly(
                self._steering_bus,
                cfg.steering_id,
                motor_model=self.STEERING_MOTOR_MODEL,
                timeout=min(timeout, self.steering_timeout),
                log=self.log,
            )
        self._refresh_um_pdo(timeout=timeout)

    def scan_motors(self) -> Dict[str, List[int]]:
        """
        扫描 RS 转向 + UM 驱动在线电机（无需使能）。

        返回:
            {"steering": [5,6,...], "driving": [1,2,...]}
        """
        if not self._connected or self._steering_bus is None:
            self.connect()

        steering_online = []
        for name in MODULE_NAMES:
            motor_id = self.modules[name].steering_id
            state, info = get_motor_status_readonly(
                self._steering_bus,
                motor_id,
                motor_model=self.STEERING_MOTOR_MODEL,
                timeout=0.15,
                log=self.log,
            )
            if state == 0 and info:
                steering_online.append(motor_id)

        driving_online = scan_um_motors(
            self.driving_can,
            id_start=1,
            id_end=8,
            timeout=0.15,
            quick_scan=True,
        )
        return {"steering": steering_online, "driving": driving_online}

    def get_status(self):
        """读取 4 个模块的转向和驱动状态（含 SDO 详细 UM 状态）。"""
        self._require_connected()
        status = {}
        for name in MODULE_NAMES:
            cfg = self.modules[name]
            rs_state, rs_info = get_motor_status_readonly(
                self._steering_bus,
                cfg.steering_id,
                motor_model=self.STEERING_MOTOR_MODEL,
                timeout=self.steering_timeout,
                log=self.log,
            )
            um_info = read_um_motor_status(self.driving_can, cfg.driving_id)
            pdo = self._um_pdo_cache.get(cfg.driving_id)
            status[name] = {
                "module": name,
                "name_cn": MODULE_NAMES_CN.get(name, name),
                "steering_id": cfg.steering_id,
                "driving_id": cfg.driving_id,
                "steering_can": self.steering_can,
                "driving_can": self.driving_can,
                "steering_state": rs_state,
                "steering": rs_info or {},
                "driving": um_info or {},
                "driving_pdo": pdo or {},
            }
        return status

    def get_status_table(self) -> List[dict]:
        """返回 8 行状态表（每模块 RS + UM 各一行）。"""
        self.refresh_status()
        all_status = self.get_status()
        rows = []
        for name in MODULE_NAMES:
            st = all_status[name]
            rs = st.get("steering") or {}
            um = st.get("driving") or {}
            pdo = st.get("driving_pdo") or {}

            cfg = self.modules[name]
            rs_angle = rs.get("angle", 0.0)
            if isinstance(rs_angle, (int, float)):
                direction = cfg.steering_direction if cfg.steering_direction else 1
                logical_rad = (float(rs_angle) - cfg.steering_zero_offset_rad) / direction
                rs_position = (
                    f"{logical_rad:+.3f} rad ({math.degrees(logical_rad):+.1f}°)"
                )
            else:
                rs_position = "-"
            rows.append({
                "module": f"{name}({st['name_cn']})",
                "type": "转向(RS)",
                "can": self.steering_can,
                "id": st["steering_id"],
                "position": rs_position,
                "velocity": f"{rs.get('velocity', 0.0):+.2f} rad/s",
                "torque": f"{rs.get('torque', 0.0):+.2f} Nm",
                "temperature": f"{rs.get('temperature', 0.0):.1f}°C",
                "mode": rs.get("mode_status", "-"),
                "status": rs.get("fault_status", "-"),
            })

            speed_rpm = pdo.get("velocity_rpm")
            if speed_rpm is None and um.get("velocity_rpm") is not None:
                speed_rpm = float(um["velocity_rpm"]) * cfg.driving_direction
            speed_text = f"{speed_rpm:+.1f} RPM" if speed_rpm is not None else "-"

            um_position = "-"
            if pdo.get("position_rad") is not None:
                deg = math.degrees(float(pdo["position_rad"]))
                raw = pdo.get("position_raw")
                um_position = (
                    f"{raw} cnt ({deg:+.1f}°)" if raw is not None else f"{deg:+.1f}°"
                )
            elif um.get("position_raw") is not None:
                raw = int(um["position_raw"])
                rad = (
                    float(raw) * 2.0 * math.pi / self.driving_position_resolution
                ) * cfg.driving_direction
                um_position = f"{raw} cnt ({math.degrees(rad):+.1f}°)"

            rows.append({
                "module": f"{name}({st['name_cn']})",
                "type": "驱动(UM)",
                "can": self.driving_can,
                "id": st["driving_id"],
                "position": um_position,
                "velocity": speed_text,
                "torque": f"{(um.get('current_a') or 0.0):+.2f} A",
                "temperature": f"{(um.get('motor_temp_c') or 0.0):.1f}°C",
                "mode": "PV",
                "status": f"0x{(um.get('alarm_code') or 0):04X}" if um else "离线",
            })
        return rows

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()
