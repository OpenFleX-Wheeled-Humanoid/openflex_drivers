#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
升降台（升降滑台）上层接口

单轴 CANopen CiA402：日常运动使用轮廓位置模式；回零序列仍使用速度模式。
对齐 lift_slide_hardware_interface.cpp / lift_slide_servo_controller.py。
"""

from __future__ import annotations

import threading
import time
import socket
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Optional

from ._lib.can_utils import verify_can_interface
from ._lib.lift_canopen import (
    CMD_DISABLE_VOLTAGE,
    CMD_ENABLE_OPERATION,
    CMD_FAULT_RESET,
    CMD_SHUTDOWN,
    CMD_SWITCH_ON,
    CW_HALT,
    CW_NEW_SETPOINT,
    CW_POSITION_MOVE,
    DI_CONFIG_INDICES,
    MODE_POSITION,
    MODE_VELOCITY,
    OD_CONTROL_WORD,
    OD_DIGITAL_INPUTS,
    OD_MODE_OF_OPERATION,
    OD_MODE_OF_OPERATION_DISPLAY,
    OD_POSITION_ACTUAL,
    OD_PROFILE_ACCELERATION,
    OD_PROFILE_DECELERATION,
    OD_PROFILE_VELOCITY,
    OD_STATUS_WORD,
    OD_TARGET_POSITION,
    OD_TARGET_VELOCITY,
    OD_VELOCITY_ACTUAL,
    SW_FAULT,
    SW_OPERATION_ENABLED,
    SW_TARGET_REACHED,
    DigitalInputState,
    parse_cia402_state,
    sdo_read_i32,
    sdo_write_i32,
)
from ._lib.log_utils import log_output

CONTROL_MODE_VELOCITY = "velocity"
CONTROL_MODE_POSITION = "position"


@dataclass
class HomingFeedback:
    physical_position_m: float = 0.0
    user_position_m: float = 0.0
    velocity_mps: float = 0.0
    statusword: int = 0
    fault: bool = False
    digital_inputs_raw: int = 0
    switch_feedback_valid: bool = False
    lower_switch: bool = False
    home_switch: bool = False
    upper_switch: bool = False


class Column:
    """升降台管理类（单轴 CANopen 伺服，Node ID 默认 16）。"""

    def __init__(
        self,
        can_interface: str = "can3",
        node_id: int = 16,
        counts_per_meter: float = 2_000_000.0,
        max_velocity_mps: float = 0.10,
        homing_speed_mps: float = 0.010,
        homing_timeout_sec: float = 60.0,
        profile_acceleration: int = 50_000,
        profile_deceleration: int = 50_000,
        invert_command: bool = True,
        invert_feedback: bool = True,
        di_active_low: bool = True,
        homing_configure_di: bool = True,
        home_di_channel: int = 4,
        pot_di_channel: int = 5,
        not_di_channel: int = 6,
        di4_homing_func: int = 0x16,
        di5_pot_func: int = 0x01,
        di6_not_func: int = 0x02,
        lower_switch_position_m: float = 0.0,
        home_switch_position_m: float = 0.640,
        upper_switch_position_m: float = 0.940,
        switch_position_tolerance_m: float = 0.008,
        min_position_m: float = -0.650,
        max_position_m: float = 0.300,
        calibration_file: Optional[str] = None,
        log=None,
    ):
        self.can_interface = can_interface
        self.node_id = int(node_id)
        self.counts_per_meter = float(counts_per_meter)
        self.max_velocity_mps = float(max_velocity_mps)
        self.homing_speed_mps = float(homing_speed_mps)
        self.homing_timeout_sec = float(homing_timeout_sec)
        self.profile_acceleration = int(profile_acceleration)
        self.profile_deceleration = int(profile_deceleration)
        self.invert_command = bool(invert_command)
        self.invert_feedback = bool(invert_feedback)
        self.di_active_low = bool(di_active_low)
        self.homing_configure_di = bool(homing_configure_di)
        self.home_di_channel = int(home_di_channel)
        self.pot_di_channel = int(pot_di_channel)
        self.not_di_channel = int(not_di_channel)
        self.di4_homing_func = int(di4_homing_func)
        self.di5_pot_func = int(di5_pot_func)
        self.di6_not_func = int(di6_not_func)
        self.lower_switch_position_m = float(lower_switch_position_m)
        self.home_switch_position_m = float(home_switch_position_m)
        self.upper_switch_position_m = float(upper_switch_position_m)
        self.switch_position_tolerance_m = float(switch_position_tolerance_m)
        self.min_position_m = float(min_position_m)
        self.max_position_m = float(max_position_m)
        self.log = log

        default_cal = Path(__file__).resolve().parent / "config" / "lift_calibration.yaml"
        self.calibration_file = Path(calibration_file) if calibration_file else default_cal

        self._lock = threading.RLock()
        self._connected = False
        self.is_enabled = False
        self.homing_complete = False
        self.homing_in_progress = False
        self.homing_detail = ""
        self.position_move_in_progress = False
        self.position_offset_m = 0.0
        self._abort_homing = threading.Event()
        self._abort_motion = threading.Event()
        self._last_target_velocity_counts: Optional[int] = None
        self._velocity_rearm_needed = False
        self._position_pp_active = False
        self.control_mode = CONTROL_MODE_VELOCITY

        self._di_config_applied = {self.home_di_channel: False,
                                   self.pot_di_channel: False,
                                   self.not_di_channel: False}
        self._last_di_state: Optional[DigitalInputState] = None
        self._switch_feedback_valid = False
        self._last_limit_warn_key: Optional[str] = None
        self._status_cache: Dict = {}

        self.load_calibration()

    @property
    def motor_ids(self):
        return [self.node_id]

    @property
    def is_connected(self) -> bool:
        return self._connected

    def connect(self) -> None:
        if not verify_can_interface(self.can_interface):
            raise RuntimeError(f"CAN 接口 {self.can_interface} 未启动")
        with self._lock:
            if not self._ping():
                raise RuntimeError(
                    f"升降台 Node {self.node_id} 在 {self.can_interface} 上无响应"
                )
            self._send_nmt_start()
            self._connected = True
        log_output(
            f"升降台已连接: {self.can_interface} Node {self.node_id}",
            "SUCCESS",
            self.log,
        )

    def close(self) -> None:
        with self._lock:
            try:
                if self.is_enabled:
                    self.stop_motion()
                    self.disable()
            except Exception:
                pass
            self._connected = False
            self.is_enabled = False

    def _ping(self) -> bool:
        return sdo_read_i32(self.can_interface, self.node_id, OD_STATUS_WORD) is not None

    def scan_motor(self) -> bool:
        return self._ping()

    # -------------------- 单位换算 --------------------

    def _counts_to_m(self, counts: int) -> float:
        physical = -counts if self.invert_feedback else counts
        return physical / self.counts_per_meter

    def _m_to_counts(self, position_m: float) -> int:
        counts = int(round(position_m * self.counts_per_meter))
        return -counts if self.invert_feedback else counts

    def _velocity_mps_to_counts(self, velocity_mps: float) -> int:
        return int(round(velocity_mps * self.counts_per_meter))

    def _velocity_counts_to_mps(self, velocity_counts: int) -> float:
        if abs(velocity_counts) < 50:
            velocity_counts = 0
        physical = -velocity_counts if self.invert_feedback else velocity_counts
        return physical / self.counts_per_meter

    def _clamp_velocity(self, velocity_mps: float) -> float:
        limit = self.max_velocity_mps
        return max(-limit, min(limit, velocity_mps))

    # -------------------- CiA402 驱动 --------------------

    def _send_nmt_start(self) -> bool:
        """发送 CANopen NMT Start，使节点进入 Operational 状态。"""
        sock = None
        try:
            sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
            sock.bind((self.can_interface,))
            frame = struct.pack(
                "=IB3x8s",
                0x000,
                8,
                bytes([0x01, self.node_id & 0xFF]).ljust(8, b"\x00"),
            )
            sock.send(frame)
            time.sleep(0.05)
            return True
        except OSError as exc:
            log_output(f"升降台 NMT Start 发送失败: {exc}", "WARNING", self.log)
            return False
        finally:
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass

    def _send_rpdo1(
        self,
        controlword: int,
        target_velocity_counts: int,
        mode: int,
    ) -> bool:
        """发送 RPDO1（对齐 lift_slide_hardware_interface / lift_slide_servo_controller）。"""
        sock = None
        try:
            sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
            sock.bind((self.can_interface,))
            cob_id = 0x400 + (self.node_id & 0x7F)
            raw_vel = int(target_velocity_counts) & 0xFFFFFFFF
            payload = bytes(
                [
                    controlword & 0xFF,
                    (controlword >> 8) & 0xFF,
                    raw_vel & 0xFF,
                    (raw_vel >> 8) & 0xFF,
                    (raw_vel >> 16) & 0xFF,
                    (raw_vel >> 24) & 0xFF,
                    mode & 0xFF,
                ]
            )
            frame = struct.pack(
                "=IB3x8s",
                cob_id,
                7,
                payload.ljust(8, b"\x00"),
            )
            sock.send(frame)
            return True
        except OSError as exc:
            log_output(f"升降台 RPDO1 发送失败: {exc}", "WARNING", self.log)
            return False
        finally:
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass

    def _is_operation_enabled(self, statusword: Optional[int]) -> bool:
        if statusword is None:
            return False
        return parse_cia402_state(statusword & 0xFFFF) == "OPERATION_ENABLED"

    def reset_fault(self) -> bool:
        ch, nid = self.can_interface, self.node_id
        sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, 0x0000, 2)
        time.sleep(0.05)
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_FAULT_RESET, 2):
            return False
        time.sleep(0.05)
        sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, 0x0000, 2)
        time.sleep(0.05)
        sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
        return sw is not None and (sw & SW_FAULT) == 0

    def enable(self) -> bool:
        """使能升降台驱动（对齐 lift_slide_hardware_interface enable_cmd 流程）。"""
        with self._lock:
            ch, nid = self.can_interface, self.node_id
            self._send_nmt_start()

            sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
            if sw is not None and (sw & SW_FAULT):
                if not self.reset_fault():
                    log_output("升降台故障复位失败", "WARNING", self.log)
                time.sleep(0.05)

            if not self._configure_drive():
                sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
                state = parse_cia402_state(sw & 0xFFFF) if sw is not None else "UNKNOWN"
                log_output(
                    f"升降台驱动配置失败: state={state} statusword=0x{(sw or 0) & 0xFFFF:04X}",
                    "ERROR",
                    self.log,
                )
                self.is_enabled = False
                return False

            for retry in range(5):
                sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_DISABLE_VOLTAGE, 2)
                time.sleep(0.05)
                if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_SHUTDOWN, 2):
                    continue
                time.sleep(0.05)
                if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_SWITCH_ON, 2):
                    continue
                time.sleep(0.05)
                if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
                    continue

                for _ in range(20):
                    time.sleep(0.05)
                    sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
                    if self._is_operation_enabled(sw):
                        if not sdo_write_i32(
                            ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2
                        ):
                            break
                        self.is_enabled = True
                        self._sync_di_config_applied_flags()
                        log_output("升降台驱动已使能", "SUCCESS", self.log)
                        self._last_target_velocity_counts = None
                        self._send_velocity_direct(0.0, force=True)
                        return True

                sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
                state = parse_cia402_state(sw & 0xFFFF) if sw is not None else "UNKNOWN"
                log_output(
                    f"升降台使能重试 {retry + 1}/5: state={state} statusword=0x{(sw or 0) & 0xFFFF:04X}",
                    "WARNING",
                    self.log,
                )

            sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
            state = parse_cia402_state(sw & 0xFFFF) if sw is not None else "UNKNOWN"
            log_output(
                f"升降台使能失败: state={state} statusword=0x{(sw or 0) & 0xFFFF:04X}",
                "ERROR",
                self.log,
            )
            self.is_enabled = False
            return False

    def disable(self) -> bool:
        with self._lock:
            ok = sdo_write_i32(
                self.can_interface, self.node_id, OD_CONTROL_WORD, 0, CMD_DISABLE_VOLTAGE, 2
            )
            self.is_enabled = False
            self._last_target_velocity_counts = None
            return ok

    def quick_stop(self) -> bool:
        with self._lock:
            if self.homing_in_progress:
                self._abort_homing.set()
            ok = self.stop_motion()
            ok = self.disable() and ok
            if not self.homing_in_progress:
                self._abort_homing.clear()
            return ok

    def _configure_drive(self) -> bool:
        ch, nid = self.can_interface, self.node_id
        if not sdo_write_i32(ch, nid, OD_MODE_OF_OPERATION, 0, MODE_VELOCITY, 1):
            return False
        if not sdo_write_i32(ch, nid, OD_TARGET_VELOCITY, 0, 0, 4):
            return False
        if not sdo_write_i32(ch, nid, OD_PROFILE_ACCELERATION, 0, self.profile_acceleration, 4):
            return False
        if not sdo_write_i32(ch, nid, OD_PROFILE_DECELERATION, 0, self.profile_deceleration, 4):
            return False
        self._last_target_velocity_counts = None
        return True

    def _send_velocity_direct(
        self,
        velocity_mps: float,
        *,
        force: bool = False,
    ) -> bool:
        """速度运行指令：SDO 配置 + RPDO1 周期下发（对齐 lift_slide_hardware_interface）。"""
        command = self._clamp_velocity(velocity_mps)
        command = self._apply_motion_limits(command)
        target_counts = self._velocity_mps_to_counts(command)
        if self.invert_command:
            target_counts = -target_counts

        counts_changed = force or target_counts != self._last_target_velocity_counts
        ch, nid = self.can_interface, self.node_id

        if counts_changed:
            display = self._read_mode_display()
            if display != MODE_VELOCITY:
                if not sdo_write_i32(ch, nid, OD_MODE_OF_OPERATION, 0, MODE_VELOCITY, 1):
                    return False
            if not sdo_write_i32(ch, nid, OD_TARGET_VELOCITY, 0, target_counts, 4):
                return False
            if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
                return False

        if not self._send_rpdo1(CMD_ENABLE_OPERATION, target_counts, MODE_VELOCITY):
            log_output("升降台 RPDO 速度指令发送失败", "ERROR", self.log)
            return False

        self._last_target_velocity_counts = target_counts
        return True

    def _send_velocity_runtime(
        self,
        velocity_mps: float,
        *,
        force: bool = False,
        apply_limits: bool = True,
    ) -> bool:
        """速度运行：SDO 写 60FF + RPDO（PP 退出后两者都发，提高兼容性）。"""
        command = self._clamp_velocity(float(velocity_mps))
        if apply_limits:
            command = self._apply_motion_limits(command)
        if not self._send_velocity_sdo(command, force=force):
            return False
        target_counts = self._velocity_mps_to_counts(command)
        if self.invert_command:
            target_counts = -target_counts
        if not self._send_rpdo1(CMD_ENABLE_OPERATION, target_counts, MODE_VELOCITY):
            log_output("升降台 RPDO 速度指令发送失败", "ERROR", self.log)
            return False
        self._last_target_velocity_counts = target_counts
        return True

    def _send_velocity_sdo(
        self,
        velocity_mps: float,
        *,
        force: bool = False,
    ) -> bool:
        """速度指令（SDO 60FF/6040，对齐 lift_slide_servo_controller）。"""
        command = self._clamp_velocity(float(velocity_mps))
        target_counts = self._velocity_mps_to_counts(command)
        if self.invert_command:
            target_counts = -target_counts

        if (
            not force
            and self._last_target_velocity_counts is not None
            and target_counts == self._last_target_velocity_counts
        ):
            return True

        ch, nid = self.can_interface, self.node_id
        if self._read_mode_display() != MODE_VELOCITY:
            if not self._set_mode_of_operation(MODE_VELOCITY):
                return False
        if not sdo_write_i32(ch, nid, OD_TARGET_VELOCITY, 0, target_counts, 4):
            return False
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
            return False
        return True

    def _prime_velocity_rpdo(self, target_counts: int = 0) -> None:
        """尽力发送 RPDO 速度帧（模式切换预热，失败不阻断）。"""
        self._send_rpdo1(CMD_ENABLE_OPERATION, target_counts, MODE_VELOCITY)

    def _prepare_velocity_runtime(self, *, require_rpdo: bool = True) -> bool:
        """完整恢复速度运行态（模式切换 + SDO/RPDO 预热）。"""
        if not self._set_mode_of_operation(MODE_VELOCITY):
            return False
        if not self._configure_drive():
            return False
        ch, nid = self.can_interface, self.node_id
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
            return False
        if self._read_mode_display() != MODE_VELOCITY:
            return False
        self._last_target_velocity_counts = None
        ok = self._send_velocity_runtime(0.0, force=True)
        if not ok:
            if require_rpdo:
                return False
            log_output("升降台速度预热失败，点动时将重试", "WARNING", self.log)
            self._velocity_rearm_needed = True
            return True
        self._velocity_rearm_needed = False
        return True

    def _restore_velocity_mode_light(self) -> bool:
        """对齐底层 restore_velocity_mode（仅 SDO，供内部轻量恢复）。"""
        if not self._set_mode_of_operation(MODE_VELOCITY):
            return False
        ch, nid = self.can_interface, self.node_id
        if not sdo_write_i32(ch, nid, OD_TARGET_VELOCITY, 0, 0, 4):
            return False
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
            return False
        self._last_target_velocity_counts = None
        return True

    def _clamp_user_position(self, user_position_m: float) -> float:
        lower = self.min_position_m
        upper = self.max_position_m
        if self.homing_complete:
            lower = max(
                lower,
                self.lower_switch_position_m - self.home_switch_position_m,
            )
            upper = min(
                upper,
                self.upper_switch_position_m - self.home_switch_position_m,
            )
        return max(lower, min(upper, float(user_position_m)))

    def _read_mode_display(self) -> Optional[int]:
        raw = sdo_read_i32(
            self.can_interface, self.node_id, OD_MODE_OF_OPERATION_DISPLAY, 0
        )
        if raw is None:
            return None
        return int(raw) & 0xFF

    def _set_mode_of_operation(self, mode: int) -> bool:
        ch, nid = self.can_interface, self.node_id
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_SWITCH_ON, 2):
            return False
        time.sleep(0.03)
        if not sdo_write_i32(ch, nid, OD_MODE_OF_OPERATION, 0, mode, 1):
            return False
        time.sleep(0.03)
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
            return False
        time.sleep(0.03)
        display = self._read_mode_display()
        return display is not None and display == mode

    def get_control_mode(self) -> str:
        return self.control_mode

    def switch_to_velocity_mode(self) -> bool:
        """手动切换到速度控制模式。"""
        with self._lock:
            if not self._connected:
                log_output("升降台未连接", "ERROR", self.log)
                return False
            if not self.is_enabled:
                log_output("升降台未使能", "ERROR", self.log)
                return False
            if self.homing_in_progress or self.position_move_in_progress:
                return False

            if not self.homing_in_progress:
                self._abort_homing.clear()

            display = self._read_mode_display()
            need_switch = (
                self.control_mode != CONTROL_MODE_VELOCITY
                or display != MODE_VELOCITY
                or self._velocity_rearm_needed
                or self._position_pp_active
            )
            if not need_switch:
                return True

            self._abort_motion.set()
            after_pp = self._position_pp_active
            if after_pp:
                log_output("升降台退出 PP 在线位置状态", "INFO", self.log)
                if not self._exit_position_dispatch():
                    log_output("升降台退出 PP 在线状态失败", "ERROR", self.log)
                    self._abort_motion.clear()
                    return False
                self._position_pp_active = False

            if not self._prepare_velocity_runtime(require_rpdo=False):
                log_output("升降台切换速度模式失败", "ERROR", self.log)
                self._abort_motion.clear()
                return False

            self.control_mode = CONTROL_MODE_VELOCITY
            self._abort_motion.clear()
            log_output("升降台已切换到速度模式", "SUCCESS", self.log)
            return True

    def switch_to_position_mode(self) -> bool:
        """手动切换到位置控制模式。"""
        with self._lock:
            if not self._connected:
                log_output("升降台未连接", "ERROR", self.log)
                return False
            if not self.is_enabled:
                log_output("升降台未使能", "ERROR", self.log)
                return False
            if self.homing_in_progress or self.position_move_in_progress:
                return False

            if not self.homing_in_progress:
                self._abort_homing.clear()

            display = self._read_mode_display()
            if (
                self.control_mode == CONTROL_MODE_POSITION
                and display == MODE_POSITION
            ):
                return True

            if display == MODE_VELOCITY:
                ch, nid = self.can_interface, self.node_id
                sdo_write_i32(ch, nid, OD_TARGET_VELOCITY, 0, 0, 4)
                sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2)
                self._last_target_velocity_counts = 0
                time.sleep(0.05)

            if not self._set_mode_of_operation(MODE_POSITION):
                log_output("升降台切换位置模式失败", "ERROR", self.log)
                return False
            if not sdo_write_i32(
                self.can_interface,
                self.node_id,
                OD_CONTROL_WORD,
                0,
                CMD_ENABLE_OPERATION,
                2,
            ):
                log_output("升降台切换位置模式失败", "ERROR", self.log)
                return False
            if self._read_mode_display() != MODE_POSITION:
                log_output("升降台切换位置模式失败", "ERROR", self.log)
                return False

            self.control_mode = CONTROL_MODE_POSITION
            self._velocity_rearm_needed = True
            self._last_target_velocity_counts = None
            self._abort_motion.clear()
            log_output("升降台已切换到位置模式", "SUCCESS", self.log)
            return True

    def _ensure_velocity_mode(self) -> bool:
        if self._velocity_rearm_needed:
            if not self._rearm_velocity_mode():
                return False
            self._velocity_rearm_needed = False

        display = self._read_mode_display()
        if display != MODE_VELOCITY:
            if not self._set_mode_of_operation(MODE_VELOCITY):
                return False
        if not self._configure_drive():
            return False

        ch, nid = self.can_interface, self.node_id
        sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
        if self._is_operation_enabled(sw):
            return True
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
            return False
        time.sleep(0.05)
        sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
        return self._is_operation_enabled(sw)

    def _ensure_position_mode(self) -> bool:
        display = self._read_mode_display()
        if display == MODE_POSITION:
            return True
        return self._set_mode_of_operation(MODE_POSITION)

    def jog_velocity(self, velocity_mps: float) -> bool:
        """
        速度模式点动（对齐 lift_velocity_controller / jog_command）。

        velocity_mps > 0 上移，< 0 下移，≈0 停止。
        """
        with self._lock:
            if not self._connected:
                log_output("升降台未连接", "ERROR", self.log)
                return False
            if not self.is_enabled and not self.enable():
                return False
            if self.homing_in_progress or self.position_move_in_progress:
                return False
            if self.control_mode != CONTROL_MODE_VELOCITY:
                log_output("升降台当前为位置模式，请先切换到速度模式", "WARNING", self.log)
                return False

            if (
                self._velocity_rearm_needed
                or self._read_mode_display() != MODE_VELOCITY
            ):
                if not self._prepare_velocity_runtime(require_rpdo=True):
                    log_output("升降台速度模式未就绪，点动失败", "ERROR", self.log)
                    return False

            self.refresh_status()
            command = self._clamp_velocity(float(velocity_mps))
            limited = self._apply_motion_limits(command)
            if abs(command) > 1e-9 and abs(limited) < 1e-9:
                return False
            return self._send_velocity_runtime(limited, force=True, apply_limits=False)

    def set_velocity_mps(self, velocity_mps: float) -> bool:
        with self._lock:
            if not self.is_enabled:
                return False
            return self._send_velocity_direct(velocity_mps)

    def stop_motion(self) -> bool:
        with self._lock:
            self._abort_motion.set()
            mode = self._read_mode_display()
            if mode == MODE_POSITION:
                ok = self._halt_position_motion()
            else:
                ok = self._send_velocity_runtime(0.0, force=True)
            self._abort_motion.clear()
            return ok

    def _halt_position_motion(self) -> bool:
        ch, nid = self.can_interface, self.node_id
        ok = sdo_write_i32(
            ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION | CW_HALT, 2
        )
        time.sleep(0.02)
        return ok

    def _clear_halt(self) -> bool:
        ch, nid = self.can_interface, self.node_id
        ok = sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2)
        time.sleep(0.02)
        return ok

    def _exit_position_dispatch(self) -> bool:
        """退出 PP 位置在线更新状态（0x103F 触发后必须执行）。"""
        ch, nid = self.can_interface, self.node_id
        if not sdo_write_i32(
            ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION | CW_HALT, 2
        ):
            return False
        time.sleep(0.05)
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2):
            return False
        time.sleep(0.05)
        pos = sdo_read_i32(ch, nid, OD_POSITION_ACTUAL)
        if pos is None:
            return False
        if not sdo_write_i32(ch, nid, OD_TARGET_POSITION, 0, int(pos), 4):
            return False
        cw_base = CMD_ENABLE_OPERATION
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, cw_base & ~CW_NEW_SETPOINT, 2):
            return False
        time.sleep(0.01)
        if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, cw_base, 2):
            return False
        time.sleep(0.05)
        return True

    def _rearm_velocity_mode(self) -> bool:
        """位置运动结束后恢复速度模式（供回零等内部流程使用）。"""
        if self._position_pp_active:
            if not self._exit_position_dispatch():
                return False
            self._position_pp_active = False
        return self._prepare_velocity_runtime(require_rpdo=True)

    def _restore_velocity_mode(self) -> bool:
        ok = self._rearm_velocity_mode()
        if ok:
            self._velocity_rearm_needed = False
        return ok

    def _position_tolerance_counts(self) -> int:
        return max(2000, int(0.002 * self.counts_per_meter))

    def _position_counts_at_target(
        self, target_counts: int, tolerance_counts: Optional[int] = None
    ) -> bool:
        tol = tolerance_counts if tolerance_counts is not None else self._position_tolerance_counts()
        pos = sdo_read_i32(self.can_interface, self.node_id, OD_POSITION_ACTUAL)
        if pos is None:
            return False
        return abs(int(pos) - int(target_counts)) <= tol

    def _position_move_timeout_sec(self, delta_m: float, speed_mps: float) -> float:
        travel_time = abs(delta_m) / max(abs(speed_mps), 0.001)
        return min(self.homing_timeout_sec, max(5.0, travel_time + 2.0))

    def _wait_target_reached(
        self,
        target_physical_m: float,
        timeout_sec: Optional[float] = None,
    ) -> bool:
        target_counts = self._m_to_counts(target_physical_m)
        tolerance = self._position_tolerance_counts()
        deadline = time.monotonic() + (timeout_sec or self.homing_timeout_sec)
        while time.monotonic() < deadline:
            if self._abort_motion.is_set() or self._abort_homing.is_set():
                return False
            sw = sdo_read_i32(self.can_interface, self.node_id, OD_STATUS_WORD)
            if sw is None:
                time.sleep(0.02)
                continue
            if (sw & SW_FAULT) != 0:
                return False
            if self._position_counts_at_target(target_counts, tolerance):
                vel = sdo_read_i32(self.can_interface, self.node_id, OD_VELOCITY_ACTUAL)
                vel_mps = abs(self._velocity_counts_to_mps(int(vel or 0)))
                if (sw & SW_TARGET_REACHED) != 0 or vel_mps < 0.001:
                    return True
            time.sleep(0.02)
        return False

    def _execute_position_move_physical(
        self,
        target_physical_m: float,
        speed_mps: float,
    ) -> bool:
        """CiA402 轮廓位置模式移动到物理坐标（对齐 lift_slide_hardware_interface）。"""
        ch, nid = self.can_interface, self.node_id
        target_counts = self._m_to_counts(target_physical_m)
        profile_vel = self._velocity_mps_to_counts(abs(speed_mps))
        if profile_vel < 1:
            profile_vel = 1

        fb = self.read_homing_feedback()
        current_physical = fb.physical_position_m if fb else target_physical_m
        move_timeout = self._position_move_timeout_sec(
            target_physical_m - current_physical, speed_mps
        )
        tolerance = self._position_tolerance_counts()

        ok = False
        try:
            if self._position_counts_at_target(target_counts, tolerance):
                ok = True
                return True

            if self._read_mode_display() != MODE_POSITION:
                log_output("驱动未处于位置模式，请先切换到位置模式", "ERROR", self.log)
                return False

            sdo_write_i32(
                ch, nid, OD_PROFILE_ACCELERATION, 0, self.profile_acceleration, 4
            )
            sdo_write_i32(
                ch, nid, OD_PROFILE_DECELERATION, 0, self.profile_deceleration, 4
            )
            if not sdo_write_i32(ch, nid, OD_PROFILE_VELOCITY, 0, profile_vel, 4):
                log_output("升降台设置轮廓速度失败", "ERROR", self.log)
                return False
            if not sdo_write_i32(ch, nid, OD_TARGET_POSITION, 0, target_counts, 4):
                log_output("升降台写入目标位置失败", "ERROR", self.log)
                return False

            if not sdo_write_i32(ch, nid, OD_CONTROL_WORD, 0, CW_POSITION_MOVE, 2):
                log_output("升降台触发位置运动失败", "ERROR", self.log)
                return False
            self._position_pp_active = True

            if not self._wait_target_reached(target_physical_m, timeout_sec=move_timeout):
                if self._abort_motion.is_set() or self._abort_homing.is_set():
                    log_output("升降台位置运动已中止", "WARNING", self.log)
                else:
                    log_output("升降台位置运动超时或未到位", "ERROR", self.log)
                return False

            ok = True
            return True
        finally:
            self._abort_motion.clear()
            if self._position_pp_active:
                self._velocity_rearm_needed = True

    def move_to_user_position(
        self,
        user_position_m: float,
        speed_mps: Optional[float] = None,
    ) -> bool:
        """移动到用户坐标系下的绝对位置（米）。"""
        if not self._connected:
            log_output("升降台未连接", "ERROR", self.log)
            return False
        if not self.is_enabled and not self.enable():
            return False
        if self.control_mode != CONTROL_MODE_POSITION:
            log_output("升降台当前为速度模式，请先切换到位置模式", "WARNING", self.log)
            return False

        target_user = self._clamp_user_position(user_position_m)
        speed = self._clamp_velocity(
            speed_mps if speed_mps is not None else self.max_velocity_mps * 0.5
        )
        target_physical = target_user + self.position_offset_m

        with self._lock:
            if self.homing_in_progress or self.position_move_in_progress:
                return False
            self.position_move_in_progress = True
            self._abort_motion.clear()
            if not self.homing_in_progress:
                self._abort_homing.clear()

        try:
            ok = self._execute_position_move_physical(target_physical, speed)
            if ok:
                log_output(
                    f"升降台已移动到 {target_user:.4f} m",
                    "SUCCESS",
                    self.log,
                )
            return ok
        finally:
            self.position_move_in_progress = False
            self.refresh_status()

    def move_relative_m(
        self,
        delta_m: float,
        speed_mps: Optional[float] = None,
    ) -> bool:
        """相对当前用户位置移动指定距离（米）。"""
        fb = self.read_homing_feedback()
        if fb is None:
            log_output("升降台相对移动失败: 无法读取当前位置", "ERROR", self.log)
            return False
        current = fb.user_position_m
        return self.move_to_user_position(current + float(delta_m), speed_mps=speed_mps)

    def move_up(self, speed_mps: Optional[float] = None) -> bool:
        """相对上移一小步（默认 10 mm）。"""
        step = 0.01
        speed = speed_mps if speed_mps is not None else self.max_velocity_mps * 0.5
        return self.move_relative_m(step, speed_mps=speed)

    def move_down(self, speed_mps: Optional[float] = None) -> bool:
        """相对下移一小步（默认 10 mm）。"""
        step = 0.01
        speed = speed_mps if speed_mps is not None else self.max_velocity_mps * 0.5
        return self.move_relative_m(-step, speed_mps=speed)

    # -------------------- 限位与反馈 --------------------

    def _switch_active(self, channel: int, di: DigitalInputState) -> bool:
        """对齐 lift_slide_hardware_interface::switch_channel_active。"""
        if self.homing_configure_di and self._di_config_applied.get(channel):
            if channel == self.home_di_channel:
                return di.cia_home
            if channel == self.pot_di_channel:
                return di.cia_pot
            if channel == self.not_di_channel:
                return di.cia_not
        return di.physical_di_channel_active(channel, self.di_active_low)

    def _sync_di_config_applied_flags(self) -> None:
        """读取驱动器 DI 映射，决定限位用 CiA 功能位还是物理 DI 位。"""
        if not self.homing_configure_di:
            return
        expected = {
            self.home_di_channel: self.di4_homing_func,
            self.pot_di_channel: self.di5_pot_func,
            self.not_di_channel: self.di6_not_func,
        }
        ch, nid = self.can_interface, self.node_id
        for channel, func in expected.items():
            idx = DI_CONFIG_INDICES[channel]
            current = sdo_read_i32(ch, nid, idx)
            self._di_config_applied[channel] = (
                current is not None and int(current) == int(func)
            )

    def _log_limit_block(self, key: str, message: str) -> None:
        if self._last_limit_warn_key == key:
            return
        self._last_limit_warn_key = key
        log_output(message, "WARNING", self.log)

    def _clear_limit_warn_if_moving(self, velocity_mps: float) -> None:
        if abs(float(velocity_mps)) > 1e-9:
            self._last_limit_warn_key = None

    def _estimate_switches(self, physical_m: float) -> tuple[bool, bool, bool]:
        tol = max(0.001, self.switch_position_tolerance_m)
        lower = physical_m <= (self.lower_switch_position_m + tol)
        home = abs(physical_m - self.home_switch_position_m) <= tol
        upper = physical_m >= (self.upper_switch_position_m - tol)
        return lower, home, upper

    def _apply_motion_limits(self, velocity_mps: float) -> float:
        raw = float(velocity_mps)
        self._clear_limit_warn_if_moving(raw)

        if self._switch_feedback_valid and self._last_di_state is not None:
            if raw > 0 and self._switch_active(self.not_di_channel, self._last_di_state):
                if abs(raw) > 1e-9:
                    pos = self._status_cache.get("position_m", 0.0)
                    self._log_limit_block(
                        "upper_di",
                        f"升降台速度被上限位抑制（当前位置 {pos:.3f} m）",
                    )
                return 0.0
            if raw < 0 and self._switch_active(self.pot_di_channel, self._last_di_state):
                if abs(raw) > 1e-9:
                    pos = self._status_cache.get("position_m", 0.0)
                    self._log_limit_block(
                        "lower_di",
                        f"升降台速度被下限位抑制（当前位置 {pos:.3f} m）",
                    )
                return 0.0

        if self.homing_complete:
            pos = self._status_cache.get("position_m", 0.0)
            lower = self.lower_switch_position_m - self.home_switch_position_m
            upper = self.upper_switch_position_m - self.home_switch_position_m
            if pos <= lower and raw < 0:
                if abs(raw) > 1e-9:
                    self._log_limit_block(
                        "lower_soft",
                        f"升降台速度被软下限抑制（当前位置 {pos:.3f} m）",
                    )
                return 0.0
            if pos >= upper and raw > 0:
                if abs(raw) > 1e-9:
                    self._log_limit_block(
                        "upper_soft",
                        f"升降台速度被软上限抑制（当前位置 {pos:.3f} m）",
                    )
                return 0.0
        return raw

    def read_homing_feedback(self) -> Optional[HomingFeedback]:
        ch, nid = self.can_interface, self.node_id
        pos_counts = sdo_read_i32(ch, nid, OD_POSITION_ACTUAL)
        vel_counts = sdo_read_i32(ch, nid, OD_VELOCITY_ACTUAL)
        sw = sdo_read_i32(ch, nid, OD_STATUS_WORD)
        if pos_counts is None or vel_counts is None or sw is None:
            return None

        fb = HomingFeedback()
        fb.physical_position_m = self._counts_to_m(pos_counts)
        fb.user_position_m = fb.physical_position_m - self.position_offset_m
        fb.velocity_mps = self._velocity_counts_to_mps(vel_counts)
        fb.statusword = sw & 0xFFFF
        fb.fault = (fb.statusword & SW_FAULT) != 0

        di_raw = sdo_read_i32(ch, nid, OD_DIGITAL_INPUTS)
        if di_raw is not None:
            di = DigitalInputState.from_raw(di_raw, self.di_active_low)
            self._last_di_state = di
            self._switch_feedback_valid = True
            fb.digital_inputs_raw = di.raw
            fb.switch_feedback_valid = True
            fb.lower_switch = self._switch_active(self.pot_di_channel, di)
            fb.home_switch = self._switch_active(self.home_di_channel, di)
            fb.upper_switch = self._switch_active(self.not_di_channel, di)
        else:
            fb.switch_feedback_valid = False
            est = self._estimate_switches(fb.physical_position_m)
            fb.lower_switch, fb.home_switch, fb.upper_switch = est
        return fb

    def refresh_status(self) -> bool:
        fb = self.read_homing_feedback()
        if fb is None:
            return False
        self._status_cache = {
            "can_interface": self.can_interface,
            "node_id": self.node_id,
            "position_m": fb.user_position_m,
            "physical_position_m": fb.physical_position_m,
            "velocity_mps": fb.velocity_mps,
            "statusword": fb.statusword,
            "cia402_state": parse_cia402_state(fb.statusword),
            "fault": fb.fault,
            "enabled": self.is_enabled,
            "homing_complete": self.homing_complete,
            "homing_in_progress": self.homing_in_progress,
            "position_move_in_progress": self.position_move_in_progress,
            "control_mode": self.control_mode,
            "homing_detail": self.homing_detail,
            "home_switch": fb.home_switch,
            "lower_switch": fb.lower_switch,
            "upper_switch": fb.upper_switch,
            "digital_inputs_raw": fb.digital_inputs_raw,
        }
        return True

    def get_status(self) -> Dict:
        return dict(self._status_cache)

    # -------------------- DI 映射（回零） --------------------

    def _sdo_write_retry(self, index: int, value: int, name: str, retries: int = 3) -> bool:
        for attempt in range(retries):
            if sdo_write_i32(self.can_interface, self.node_id, index, 0, value, 4):
                return True
            time.sleep(0.1)
        log_output(f"升降台 SDO 写入失败: {name} 0x{index:04X}", "WARNING", self.log)
        return False

    def configure_homing_di_mapping(self) -> bool:
        if not self.homing_configure_di:
            return True

        mapped = {self.home_di_channel, self.pot_di_channel, self.not_di_channel}
        for channel in range(1, 7):
            if channel in mapped:
                continue
            idx = DI_CONFIG_INDICES[channel]
            current = sdo_read_i32(self.can_interface, self.node_id, idx)
            if current and current != 0:
                self._sdo_write_retry(idx, 0, f"DI{channel}_CLEAR")

        func_map = {
            self.home_di_channel: (self.di4_homing_func, "HOME"),
            self.pot_di_channel: (self.di5_pot_func, "POT"),
            self.not_di_channel: (self.di6_not_func, "NOT"),
        }
        ok_all = True
        for channel, (func, label) in func_map.items():
            idx = DI_CONFIG_INDICES[channel]
            ok = self._sdo_write_retry(idx, func, f"DI{channel}={label}")
            ok_all = ok_all and ok
            time.sleep(0.1)
        self._sync_di_config_applied_flags()
        for channel in func_map:
            if not self._di_config_applied.get(channel):
                ok_all = False

        sw = sdo_read_i32(self.can_interface, self.node_id, OD_STATUS_WORD)
        if sw is not None and (sw & SW_FAULT):
            self.reset_fault()
            time.sleep(0.2)
            self.enable()
        return ok_all

    # -------------------- 校准持久化 --------------------

    def save_calibration(self) -> bool:
        try:
            self.calibration_file.parent.mkdir(parents=True, exist_ok=True)
            with self.calibration_file.open("w", encoding="utf-8") as f:
                f.write("# Lift slide zero-point calibration (auto-generated)\n")
                f.write(f"position_offset_m: {self.position_offset_m:.8f}\n")
                f.write("homing_complete: true\n")
            return True
        except OSError as exc:
            log_output(f"保存升降台校准失败: {exc}", "WARNING", self.log)
            return False

    def load_calibration(self) -> bool:
        if not self.calibration_file.exists():
            return False
        try:
            offset = None
            homed = False
            for line in self.calibration_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("#") or not line:
                    continue
                if line.startswith("position_offset_m:"):
                    offset = float(line.split(":", 1)[1].strip())
                if line.startswith("homing_complete:"):
                    homed = "true" in line.split(":", 1)[1].lower()
            if offset is not None and homed:
                self.position_offset_m = offset
                self.homing_complete = True
                return True
        except (OSError, ValueError) as exc:
            log_output(f"加载升降台校准失败: {exc}", "WARNING", self.log)
        return False

    # -------------------- 被动 / 主动回零 --------------------

    def set_passive_zero(self) -> bool:
        """
        被动回零：将当前位置设为软件零点（不移动）。

        使用前请将升降台手动移动到期望零位。
        """
        with self._lock:
            fb = self.read_homing_feedback()
            if fb is None:
                log_output("升降台被动回零失败: 无法读取位置", "ERROR", self.log)
                return False
            if fb.fault:
                log_output("升降台被动回零失败: 驱动器故障", "ERROR", self.log)
                return False

            self.stop_motion()
            self.position_offset_m = fb.physical_position_m
            self.homing_complete = True
            self.homing_detail = "passive_zero"
            self.save_calibration()
            log_output(
                f"升降台被动回零完成: physical={fb.physical_position_m:.4f}m",
                "SUCCESS",
                self.log,
            )
            self.refresh_status()
            return True

    def _move_until_switch(
        self,
        direction: str,
        switch_attr: str,
        speed_mps: float,
        timeout_sec: Optional[float] = None,
    ) -> Optional[float]:
        """沿指定方向运动直到限位开关触发，返回触发时的 physical_position_m。"""
        timeout = timeout_sec or self.homing_timeout_sec
        start = time.monotonic()
        streak = 0
        released = False

        if not self._send_velocity_direct(speed_mps):
            return None

        while not self._homing_aborted():
            time.sleep(0.02)
            fb = self.read_homing_feedback()
            if fb is None:
                continue
            if fb.fault:
                return None
            if not fb.switch_feedback_valid:
                return None

            active = getattr(fb, switch_attr, False)
            if active:
                if not released:
                    continue
                streak += 1
                if streak >= 2:
                    self.stop_motion()
                    time.sleep(0.15)
                    fb2 = self.read_homing_feedback()
                    return fb2.physical_position_m if fb2 else fb.physical_position_m
            else:
                released = True
                streak = 0

            if time.monotonic() - start > timeout:
                return None
        return None

    def _move_to_physical_position(self, target_physical_m: float, speed_mps: float) -> bool:
        """通过速度闭环移动到目标物理位置。"""
        tol = max(0.001, self.switch_position_tolerance_m)
        start = time.monotonic()
        self._last_target_velocity_counts = None

        while not self._homing_aborted():
            fb = self.read_homing_feedback()
            if fb is None or fb.fault:
                return False
            err = target_physical_m - fb.physical_position_m
            if abs(err) <= tol:
                self.stop_motion()
                return True
            cmd = speed_mps if err > 0 else -speed_mps
            cmd = self._apply_motion_limits(cmd)
            if cmd == 0.0:
                return False
            if not self._send_velocity_direct(cmd):
                return False
            if time.monotonic() - start > self.homing_timeout_sec:
                return False
            time.sleep(0.02)
        return False

    def set_active_zero(self, zero_pos_per: float = 0.5) -> bool:
        """
        主动回零：寻上下限位（NOT / POT），取中点设为软件零点。

        流程:
            1. 向上寻 NOT（上限）→ 记录位置 A
            2. 向下寻 POT（下限）→ 记录位置 B
            3. 中点 C = B + (A - B) * zero_pos_per
            4. 移动到 C 并写入零点
        """
        with self._lock:
            if self.homing_in_progress:
                return False
            self.homing_in_progress = True
            self.homing_detail = "active_zero"
            self._abort_homing.clear()

        try:
            if not self.is_enabled and not self.enable():
                return self._homing_fail("使能失败", restore=False)
            if not self.configure_homing_di_mapping():
                return self._homing_fail("DI 映射配置失败")
            if not self._configure_drive():
                return self._homing_fail("速度模式配置失败")
            sdo_write_i32(
                self.can_interface, self.node_id, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2
            )

            fb = self.read_homing_feedback()
            if fb is None or not fb.switch_feedback_valid:
                return self._homing_fail("数字输入反馈不可用")

            speed = max(0.001, min(abs(self.homing_speed_mps), self.max_velocity_mps))

            self.homing_detail = "active_seek_upper"
            pos_upper = self._move_until_switch("up", "upper_switch", speed)
            if pos_upper is None:
                return self._homing_fail("向上寻上限位失败")
            if self._homing_aborted():
                return self._homing_fail("用户中止")

            self.stop_motion()
            time.sleep(0.2)
            self._last_target_velocity_counts = None

            self.homing_detail = "active_seek_lower"
            pos_lower = self._move_until_switch("down", "lower_switch", -speed)
            if pos_lower is None:
                return self._homing_fail("向下寻下限位失败")
            if self._homing_aborted():
                return self._homing_fail("用户中止")

            midpoint = pos_lower + (pos_upper - pos_lower) * float(zero_pos_per)
            self.homing_detail = "active_move_midpoint"
            if not self._move_to_physical_position(midpoint, speed):
                return self._homing_fail("移动到行程中点失败")

            fb = self.read_homing_feedback()
            if fb is None:
                return self._homing_fail("最终反馈读取失败")

            self.position_offset_m = fb.physical_position_m
            self.homing_complete = True
            self.homing_detail = "active_zero_complete"
            self.save_calibration()
            log_output(
                f"升降台主动回零完成: 上限={pos_upper:.4f}m 下限={pos_lower:.4f}m "
                f"中点={midpoint:.4f}m offset={self.position_offset_m:.4f}m",
                "SUCCESS",
                self.log,
            )
            return True
        finally:
            self.homing_in_progress = False
            self._abort_homing.clear()
            self.refresh_status()

    # -------------------- 回零序列 --------------------

    def abort_homing(self) -> None:
        if self.homing_in_progress:
            self._abort_homing.set()

    def _homing_aborted(self) -> bool:
        return self._abort_homing.is_set()

    def _homing_fail(self, reason: str, restore: bool = True) -> bool:
        log_output(f"升降台零点/回零失败: {reason}", "ERROR", self.log)
        self.stop_motion()
        self.homing_in_progress = False
        self.homing_detail = reason
        if restore and self.is_enabled:
            self._configure_drive()
        return False

    def start_homing(self) -> bool:
        """寻 HOME 开关并设置软件零点（对齐 start_homing_sequence）。"""
        with self._lock:
            if self.homing_in_progress:
                return False
            self.homing_in_progress = True
            self.homing_detail = "configuring"
            self._abort_homing.clear()

        try:
            if not self.is_enabled and not self.enable():
                return self._homing_fail("使能失败", restore=False)

            if not self.configure_homing_di_mapping():
                return self._homing_fail("DI 映射配置失败")
            if not self._configure_drive():
                return self._homing_fail("速度模式配置失败")
            sdo_write_i32(self.can_interface, self.node_id, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2)

            fb = self.read_homing_feedback()
            if fb is None:
                return self._homing_fail("初始反馈读取失败")
            if not fb.switch_feedback_valid:
                return self._homing_fail("数字输入反馈不可用")

            speed = max(0.001, min(abs(self.homing_speed_mps), self.max_velocity_mps))
            start_time = time.monotonic()
            home_found = fb.home_switch

            if not home_found:
                search_down = fb.upper_switch
                if not search_down:
                    self.homing_detail = "moving_up_to_home"
                    if not self._send_velocity_direct(speed):
                        return self._homing_fail("向上寻 HOME 启动失败")
                    home_released = not fb.home_switch
                    streak = 0
                    while not self._homing_aborted():
                        time.sleep(0.02)
                        fb = self.read_homing_feedback()
                        if fb is None:
                            continue
                        if fb.fault:
                            return self._homing_fail("向上寻 HOME 期间故障")
                        if not fb.switch_feedback_valid:
                            return self._homing_fail("数字输入反馈丢失")
                        if fb.home_switch:
                            if not home_released:
                                continue
                            streak += 1
                            if streak >= 2:
                                home_found = True
                                break
                        else:
                            home_released = True
                            streak = 0
                        if fb.upper_switch:
                            search_down = True
                            break
                        if time.monotonic() - start_time > self.homing_timeout_sec:
                            return self._homing_fail("向上寻 HOME 超时")

                if self._homing_aborted():
                    return self._homing_fail("用户中止", restore=True)

                if not home_found and search_down:
                    self.stop_motion()
                    time.sleep(0.2)
                    self._last_target_velocity_counts = None
                    sw = sdo_read_i32(self.can_interface, self.node_id, OD_STATUS_WORD)
                    if sw is not None and (sw & 0x006F) != SW_OPERATION_ENABLED:
                        self.enable()
                        sdo_write_i32(self.can_interface, self.node_id, OD_MODE_OF_OPERATION, 0, MODE_VELOCITY, 1)
                        sdo_write_i32(self.can_interface, self.node_id, OD_CONTROL_WORD, 0, CMD_ENABLE_OPERATION, 2)
                        time.sleep(0.1)

                    self.homing_detail = "moving_down_to_home"
                    if not self._send_velocity_direct(-speed):
                        return self._homing_fail("向下寻 HOME 启动失败")
                    home_released = not fb.home_switch
                    streak = 0
                    while not self._homing_aborted():
                        time.sleep(0.02)
                        fb = self.read_homing_feedback()
                        if fb is None:
                            continue
                        if fb.fault:
                            return self._homing_fail("向下寻 HOME 期间故障")
                        if not fb.switch_feedback_valid:
                            return self._homing_fail("数字输入反馈丢失")
                        if fb.home_switch:
                            if not home_released:
                                continue
                            streak += 1
                            if streak >= 2:
                                home_found = True
                                break
                        else:
                            home_released = True
                            streak = 0
                        if fb.lower_switch:
                            return self._homing_fail("向下寻 HOME 触及下限仍未找到 HOME")
                        if time.monotonic() - start_time > self.homing_timeout_sec:
                            return self._homing_fail("向下寻 HOME 超时")

                if not home_found:
                    return self._homing_fail("未检测到 HOME 开关")

            self.stop_motion()
            time.sleep(0.2)
            fb = self.read_homing_feedback()
            if fb is None:
                return self._homing_fail("最终反馈读取失败")

            self.position_offset_m = fb.physical_position_m
            self.homing_complete = True
            self._last_target_velocity_counts = None
            self._configure_drive()
            self.is_enabled = True
            self.save_calibration()
            self.homing_detail = "complete"
            log_output(
                f"升降台零点已设置: physical={fb.physical_position_m:.4f}m offset={self.position_offset_m:.4f}m",
                "SUCCESS",
                self.log,
            )
            return True
        finally:
            self.homing_in_progress = False
            self._abort_homing.clear()
            self.refresh_status()

    def return_home(self) -> bool:
        """移动到软件零位（用户坐标 0 m）。"""
        if not self.homing_complete:
            log_output("请先设置零点再执行回零", "WARNING", self.log)
            return False
        return self.move_to_user_position(0.0, speed_mps=self.homing_speed_mps)
