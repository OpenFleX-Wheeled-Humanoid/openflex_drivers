#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   robot.py
@Time    :   2025/12/16 16:39:44
@Author  :   Wei Lindong
@Version :   2.0
@Desc    :   OpenArmX 机器人控制接口 (头部、双臂、升降台、底盘)
'''

from typing import Optional, List, Dict, Union
from .arm import Arm
from .chassis import Chassis
from .column import Column
from .head import Head
from .exceptions import (
    CANInitializationError,
    InvalidMotorIDError,
    InvalidModeError
)
from ._lib.log_utils import log_output
import time


class Robot:
    """
    OpenArmX 机器人控制类

    管理机器人的所有部件：头部、双臂、升降台、底盘

    属性:
        head: 头部控制对象 (待实现)
        left_arm (Arm): 左臂控制对象
        right_arm (Arm): 右臂控制对象
        column: 升降台控制对象 (待实现)
        chassis: 底盘控制对象 (Chassis)

    示例:
        >>> robot = Robot(
        >>>     left_arm_can='can1',
        >>>     right_arm_can='can0'
        >>> )
        >>> # 查看双臂状态
        >>> robot.show_arms_status()
    """

    def __init__(self,
                 right_arm_can: str = 'can0',
                 left_arm_can: str = 'can1',
                 head_can: Optional[str] = None,
                 head: Optional["Head"] = None,
                 column_can: Optional[str] = None,
                 column: Optional["Column"] = None,
                 steering_can: Optional[str] = None,
                 driving_can: Optional[str] = None,
                 chassis_can: Optional[str] = None,
                 chassis: Optional["Chassis"] = None,
                 motor_ids: Optional[List[int]] = None,
                 auto_enable_can: bool = True,
                 bitrate: int = 1000000,
                 password: Optional[str] = None,
                 log=None,
                 **kwargs):
        """
        初始化 OpenArmX 机器人

        参数:
            right_arm_can (str): 右臂 CAN 通道 (默认: 'can0')
            left_arm_can (str): 左臂 CAN 通道 (默认: 'can1')
            head_can (str, optional): 头部 CAN 通道 (待实现)
            column_can (str, optional): 升降台 CAN 通道 (默认 can3)
            column (Column, optional): 外部已创建的 Column 实例
            steering_can (str, optional): 底盘 RS 转向 CAN 通道 (默认 can5)
            driving_can (str, optional): 底盘 UM 驱动 CAN 通道 (默认 can4)
            chassis_can (str, optional): 已废弃，请使用 steering_can / driving_can
            chassis (Chassis, optional): 外部已创建的 Chassis 实例（避免重复实例化）
            motor_ids (List[int], optional): 电机ID列表 (默认: [1,2,3,4,5,6,7,8])
            auto_enable_can (bool): 是否自动启用 CAN 接口 (默认: True)
            bitrate (int): CAN 波特率 (默认: 1000000)
            password (str, optional): sudo密码，用于自动启用CAN接口
            log (callable, optional): 日志函数
            **kwargs: 传递给各部件的其他参数

        异常:
            CANInitializationError: CAN 总线初始化失败
        """
        self.log = log

        # ==================== 双臂初始化 ====================
        self.right_arm = Arm(
            can_channel=right_arm_can,
            side='right',
            motor_ids=motor_ids,
            auto_enable_can=auto_enable_can,
            bitrate=bitrate,
            password=password,
            log=log,
            **kwargs
        )

        self.left_arm = Arm(
            can_channel=left_arm_can,
            side='left',
            motor_ids=motor_ids,
            auto_enable_can=auto_enable_can,
            bitrate=bitrate,
            password=password,
            log=log,
            **kwargs
        )

        # ==================== 头部初始化 ====================
        self.head = head
        if self.head is None and head_can:
            self.head = Head(can_channel=head_can, auto_enable_can=auto_enable_can, log=log, **kwargs)
            log_output(
                f"头部接口已创建: {head_can} 电机 ID={self.head.motor_ids}",
                "SUCCESS",
                self.log,
            )
        elif head is not None and head_can:
            log_output("已使用外部传入的 Head 实例，忽略 head_can 参数", "INFO", self.log)

        # ==================== 升降台初始化 ====================
        self.column = column
        if self.column is None and column_can:
            self.column = Column(can_interface=column_can, log=log)
            log_output(
                f"升降台接口已创建: {column_can} Node {self.column.node_id}",
                "SUCCESS",
                self.log,
            )
        elif column is not None and column_can:
            log_output("已使用外部传入的 Column 实例，忽略 column_can 参数", "INFO", self.log)

        # ==================== 底盘初始化 ====================
        self.chassis = chassis
        if self.chassis is None:
            _steering = steering_can or chassis_can
            _driving = driving_can or ("can4" if chassis_can else None)
            if _steering and _driving:
                self.chassis = Chassis(
                    steering_can=_steering,
                    driving_can=_driving,
                    log=log,
                )
                log_output(
                    f"底盘接口已创建: 转向={_steering} 驱动={_driving}",
                    "SUCCESS",
                    self.log,
                )
            elif _steering or _driving:
                log_output("底盘需要同时配置 steering_can 与 driving_can", "WARNING", self.log)
        elif steering_can or driving_can or chassis_can:
            log_output("已使用外部传入的 Chassis 实例，忽略 steering_can/driving_can 参数", "INFO", self.log)

    def __enter__(self):
        """支持 with 语句"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出时自动关闭"""
        self.shutdown()

    def shutdown(self):
        """关闭所有部件的连接"""
        # 关闭双臂
        if self.right_arm:
            try:
                self.right_arm.close()
            except:
                pass

        if self.left_arm:
            try:
                self.left_arm.close()
            except:
                pass

        # 关闭头部 (待实现)
        if self.head:
            try:
                self.head.close()
            except:
                pass

        # 关闭升降台 (待实现)
        if self.column:
            try:
                self.column.close()
            except:
                pass

        # 关闭底盘 (待实现)
        if self.chassis:
            try:
                self.chassis.close()
            except:
                pass

    # ==================== 双臂状态查询接口 ====================

    def get_arms_status(self) -> Dict[str, Dict]:
        """
        获取双臂的所有电机状态

        返回:
            dict: {
                'left': {motor_id: status_info, ...},
                'right': {motor_id: status_info, ...}
            }

            status_info 包含:
                - angle (float): 角度 (弧度)
                - velocity (float): 速度 (弧度/秒)
                - torque (float): 力矩 (牛米)
                - temperature (float): 温度 (摄氏度)
                - mode_status (str): 模式状态
                - fault_status (str): 故障状态

        示例:
            >>> status = robot.get_arms_status()
            >>> print(status['right'][1]['angle'])  # 右臂电机1的角度
            >>> print(status['left'][5]['temperature'])  # 左臂电机5的温度
        """
        return {
            'right': self.right_arm.get_motor_status(),
            'left': self.left_arm.get_motor_status()
        }

    def get_right_arm_status(self, motor_id: Optional[int] = None) -> Dict:
        """
        获取右臂状态

        参数:
            motor_id (int, optional): 指定电机ID，如果为None则返回所有电机状态

        返回:
            dict: 单个电机状态或所有电机状态字典

        示例:
            >>> # 获取右臂所有电机状态
            >>> all_status = robot.get_right_arm_status()
            >>>
            >>> # 获取右臂电机5的状态
            >>> motor5_status = robot.get_right_arm_status(motor_id=5)
            >>> print(motor5_status['angle'])
        """
        if motor_id:
            return self.right_arm.get_motor_status(motor_id)
        return self.right_arm.get_motor_status()

    def get_left_arm_status(self, motor_id: Optional[int] = None) -> Dict:
        """
        获取左臂状态

        参数:
            motor_id (int, optional): 指定电机ID，如果为None则返回所有电机状态

        返回:
            dict: 单个电机状态或所有电机状态字典

        示例:
            >>> # 获取左臂所有电机状态
            >>> all_status = robot.get_left_arm_status()
            >>>
            >>> # 获取左臂电机3的状态
            >>> motor3_status = robot.get_left_arm_status(motor_id=3)
            >>> print(motor3_status['velocity'])
        """
        if motor_id:
            return self.left_arm.get_motor_status(motor_id)
        return self.left_arm.get_motor_status()

    def show_arms_status(self):
        """
        显示双臂机器人的整体状态（统一表格）

        将左右臂的所有电机状态整合到一个表格中展示

        示例:
            >>> robot.show_arms_status()
            ================================================================
            机器人双臂状态
            ================================================================
            臂   | ID | 角度(rad) | 速度(rad/s) | 力矩(Nm) |  温度    | 模式              | 状态
            ----------------------------------------------------------------
            右臂 |  1 |     0.123 |       0.000 |    0.000 |  25.0°C | 🟢 Motor模式       | ✓ 正常
            ...
        """
        # 打印表头
        log_output("="*130, "INFO", self.log)
        log_output("机器人双臂状态", "INFO", self.log)
        log_output("="*130, "INFO", self.log)
        log_output("臂   | ID | 角度(rad) | 速度(rad/s) | 力矩(Nm) |  温度    | 模式              | 状态", "INFO", self.log)
        log_output("-"*130, "INFO", self.log)

        # 显示右臂所有电机
        for motor_id in self.right_arm.motor_ids:
            try:
                info = self.right_arm.get_motor_status(motor_id)
                if info:
                    self._print_motor_status("右臂", motor_id, info)
                else:
                    log_output(f"右臂 | {motor_id:2d} | ✗ 无响应", "WARNING", self.log)
                time.sleep(0.01)
            except Exception as e:
                log_output(f"右臂 | {motor_id:2d} | ⚠ 异常 - {str(e)}", "ERROR", self.log)

        # 分隔线
        log_output("-"*130, "INFO", self.log)

        # 显示左臂所有电机
        for motor_id in self.left_arm.motor_ids:
            try:
                info = self.left_arm.get_motor_status(motor_id)
                if info:
                    self._print_motor_status("左臂", motor_id, info)
                else:
                    log_output(f"左臂 | {motor_id:2d} | ✗ 无响应", "WARNING", self.log)
                time.sleep(0.01)
            except Exception as e:
                log_output(f"左臂 | {motor_id:2d} | ⚠ 异常 - {str(e)}", "ERROR", self.log)

        log_output("="*130, "INFO", self.log)

    def _print_motor_status(self, arm_name: str, motor_id: int, info: Dict):
        """
        打印单个电机状态（表格格式）

        参数:
            arm_name (str): 臂名称（"左臂"或"右臂"）
            motor_id (int): 电机ID
            info (dict): 电机状态信息
        """
        angle = info.get('angle', 0.0)
        velocity = info.get('velocity', 0.0)
        torque = info.get('torque', 0.0)
        temperature = info.get('temperature', 0.0)
        mode_status = info.get('mode_status', '未知')
        fault_status = info.get('fault_status', '未知')

        # 根据模式状态选择图标（兼容英文和中文）
        if 'Motor mode' in mode_status or 'Motor模式' in mode_status or '运行' in mode_status:
            mode_icon = "🟢"
        elif 'Reset mode' in mode_status or 'Reset模式' in mode_status or '复位' in mode_status:
            mode_icon = "🔴"
        elif 'Cali mode' in mode_status or 'Cali模式' in mode_status or '标定' in mode_status:
            mode_icon = "🟡"
        else:
            mode_icon = "⚪"

        # 根据故障状态选择图标（兼容英文和中文）
        if fault_status == "正常" or fault_status == "Normal":
            fault_icon = "✓"
        else:
            fault_icon = "✗"

        log_output(
            f"{arm_name} | {motor_id:2d} | {angle:9.3f} | {velocity:11.3f} | "
            f"{torque:8.3f} | {temperature:6.1f}°C | {mode_icon} {mode_status:15s} | {fault_icon} {fault_status}",
            "INFO", self.log
        )

    def show_right_arm_status(self):
        """
        显示右臂状态

        示例:
            >>> robot.show_right_arm_status()
        """
        self.right_arm.show_motor_status()

    def show_left_arm_status(self):
        """
        显示左臂状态

        示例:
            >>> robot.show_left_arm_status()
        """
        self.left_arm.show_motor_status()

    # ==================== 电机使能/失能接口 ====================

    def enable_right_arm(self, verbose: bool = False) -> Dict[int, int]:
        """
        使能右臂所有电机

        参数:
            verbose (bool): 是否打印详细信息

        返回:
            Dict[int, int]: {motor_id: state} 每个电机的状态

        示例:
            >>> robot.enable_right_arm()
            >>> # 使能右臂所有电机
        """
        log_output("使能右臂所有电机...", "INFO", self.log)
        result = self.right_arm.enable_arm_motors(verbose=verbose)
        log_output(f"右臂使能完成: {len(result)} 个电机", "SUCCESS", self.log)
        return result

    def disable_right_arm(self, verbose: bool = False) -> Dict[int, int]:
        """
        失能右臂所有电机

        参数:
            verbose (bool): 是否打印详细信息

        返回:
            Dict[int, int]: {motor_id: state} 每个电机的状态

        示例:
            >>> robot.disable_right_arm()
            >>> # 失能右臂所有电机
        """
        log_output("失能右臂所有电机...", "INFO", self.log)
        result = self.right_arm.disable_arm_motors(verbose=verbose)
        log_output(f"右臂失能完成: {len(result)} 个电机", "SUCCESS", self.log)
        return result

    def enable_left_arm(self, verbose: bool = False) -> Dict[int, int]:
        """
        使能左臂所有电机

        参数:
            verbose (bool): 是否打印详细信息

        返回:
            Dict[int, int]: {motor_id: state} 每个电机的状态

        示例:
            >>> robot.enable_left_arm()
            >>> # 使能左臂所有电机
        """
        log_output("使能左臂所有电机...", "INFO", self.log)
        result = self.left_arm.enable_arm_motors(verbose=verbose)
        log_output(f"左臂使能完成: {len(result)} 个电机", "SUCCESS", self.log)
        return result

    def disable_left_arm(self, verbose: bool = False) -> Dict[int, int]:
        """
        失能左臂所有电机

        参数:
            verbose (bool): 是否打印详细信息

        返回:
            Dict[int, int]: {motor_id: state} 每个电机的状态

        示例:
            >>> robot.disable_left_arm()
            >>> # 失能左臂所有电机
        """
        log_output("失能左臂所有电机...", "INFO", self.log)
        result = self.left_arm.disable_arm_motors(verbose=verbose)
        log_output(f"左臂失能完成: {len(result)} 个电机", "SUCCESS", self.log)
        return result

    def enable_all_components(self, verbose: bool = False) -> Dict[str, Dict[int, int]]:
        """
        使能机器人所有部件的电机（头部、双臂、升降台、底盘）

        参数:
            verbose (bool): 是否打印详细信息

        返回:
            Dict[str, Dict[int, int]]: {
                'right_arm': {motor_id: state, ...},
                'left_arm': {motor_id: state, ...},
                'head': {motor_id: state, ...},      # 待实现
                'column': {motor_id: state, ...},    # 待实现
                'chassis': {motor_id: state, ...}    # 待实现
            }

        示例:
            >>> robot.enable_all_components()
            >>> # 使能机器人所有电机
        """
        log_output("="*80, "INFO", self.log)
        log_output("开始使能机器人所有部件...", "INFO", self.log)
        log_output("="*80, "INFO", self.log)

        results = {}

        # 使能右臂
        try:
            results['right_arm'] = self.enable_right_arm(verbose=verbose)
        except Exception as e:
            log_output(f"右臂使能失败: {str(e)}", "ERROR", self.log)
            results['right_arm'] = {}

        # 使能左臂
        try:
            results['left_arm'] = self.enable_left_arm(verbose=verbose)
        except Exception as e:
            log_output(f"左臂使能失败: {str(e)}", "ERROR", self.log)
            results['left_arm'] = {}

        # 使能头部 (待实现)
        if self.head:
            try:
                log_output("使能头部所有电机...", "INFO", self.log)
                results['head'] = self.head.enable(verbose=verbose)
                log_output(f"头部使能完成: {len(results['head'])} 个电机", "SUCCESS", self.log)
            except Exception as e:
                log_output(f"头部使能失败: {str(e)}", "ERROR", self.log)
                results['head'] = {}
        else:
            results['head'] = {}

        # 使能升降台
        if self.column:
            try:
                log_output("使能升降台...", "INFO", self.log)
                ok = self.column.enable()
                results['column'] = {self.column.node_id: 0 if ok else 1}
                if ok:
                    log_output("升降台使能完成", "SUCCESS", self.log)
                else:
                    log_output("升降台使能失败", "WARNING", self.log)
            except Exception as e:
                log_output(f"升降台使能失败: {str(e)}", "ERROR", self.log)
                results['column'] = {self.column.node_id: 1}
        else:
            results['column'] = {}

        # 使能底盘
        if self.chassis:
            try:
                log_output("使能底盘所有电机...", "INFO", self.log)
                results['chassis'] = self.chassis.enable_all_motors(verbose=verbose)
                log_output(f"底盘使能完成: {len(results['chassis'])} 个电机", "SUCCESS", self.log)
            except Exception as e:
                log_output(f"底盘使能失败: {str(e)}", "ERROR", self.log)
                results['chassis'] = {}
        else:
            results['chassis'] = {}

        # 统计总数
        total_motors = sum(len(v) for v in results.values())
        log_output("="*80, "INFO", self.log)
        log_output(f"机器人所有部件使能完成: 共 {total_motors} 个电机", "SUCCESS", self.log)
        log_output("="*80, "INFO", self.log)

        return results

    def disable_all_components(self, verbose: bool = False) -> Dict[str, Dict[int, int]]:
        """
        失能机器人所有部件的电机（头部、双臂、升降台、底盘）

        参数:
            verbose (bool): 是否打印详细信息

        返回:
            Dict[str, Dict[int, int]]: {
                'right_arm': {motor_id: state, ...},
                'left_arm': {motor_id: state, ...},
                'head': {motor_id: state, ...},      # 待实现
                'column': {motor_id: state, ...},    # 待实现
                'chassis': {motor_id: state, ...}    # 待实现
            }

        示例:
            >>> robot.disable_all_components()
            >>> # 失能机器人所有电机
        """
        log_output("="*80, "INFO", self.log)
        log_output("开始失能机器人所有部件...", "INFO", self.log)
        log_output("="*80, "INFO", self.log)

        results = {}

        # 失能右臂
        try:
            results['right_arm'] = self.disable_right_arm(verbose=verbose)
        except Exception as e:
            log_output(f"右臂失能失败: {str(e)}", "ERROR", self.log)
            results['right_arm'] = {}

        # 失能左臂
        try:
            results['left_arm'] = self.disable_left_arm(verbose=verbose)
        except Exception as e:
            log_output(f"左臂失能失败: {str(e)}", "ERROR", self.log)
            results['left_arm'] = {}

        # 失能头部 (待实现)
        if self.head:
            try:
                log_output("失能头部所有电机...", "INFO", self.log)
                results['head'] = self.head.disable(verbose=verbose)
                log_output(f"头部失能完成: {len(results['head'])} 个电机", "SUCCESS", self.log)
            except Exception as e:
                log_output(f"头部失能失败: {str(e)}", "ERROR", self.log)
                results['head'] = {}
        else:
            results['head'] = {}

        # 失能升降台
        if self.column:
            try:
                log_output("失能升降台...", "INFO", self.log)
                ok = self.column.disable()
                results['column'] = {self.column.node_id: 0 if ok else 1}
                if ok:
                    log_output("升降台失能完成", "SUCCESS", self.log)
                else:
                    log_output("升降台失能失败", "WARNING", self.log)
            except Exception as e:
                log_output(f"升降台失能失败: {str(e)}", "ERROR", self.log)
                results['column'] = {self.column.node_id: 1}
        else:
            results['column'] = {}

        # 失能底盘
        if self.chassis:
            try:
                log_output("失能底盘所有电机...", "INFO", self.log)
                results['chassis'] = self.chassis.disable_all_motors(verbose=verbose)
                log_output(f"底盘失能完成: {len(results['chassis'])} 个电机", "SUCCESS", self.log)
            except Exception as e:
                log_output(f"底盘失能失败: {str(e)}", "ERROR", self.log)
                results['chassis'] = {}
        else:
            results['chassis'] = {}

        # 统计总数
        total_motors = sum(len(v) for v in results.values())
        log_output("="*80, "INFO", self.log)
        log_output(f"机器人所有部件失能完成: 共 {total_motors} 个电机", "SUCCESS", self.log)
        log_output("="*80, "INFO", self.log)

        return results

    # ==================== 零点设置接口 ====================

    def set_zero_right_arm(self, timeout: float = 1.0, verbose: bool = False) -> int:
        """
        设置右臂所有电机当前位置为零点

        参数:
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 失败的电机数量，0表示全部成功

        示例:
            >>> failed = robot.set_zero_right_arm()
            >>> if failed == 0:
            >>>     print("右臂所有电机零点设置成功")
        """
        log_output("设置右臂所有电机零点...", "INFO", self.log)
        failed_count = self.right_arm.set_zero(timeout=timeout, verbose=verbose)
        if failed_count == 0:
            if verbose:
                log_output(f"右臂零点设置完成: {len(self.right_arm.motor_ids)} 个电机全部成功", "SUCCESS", self.log)
        else:
            if verbose:
                log_output(f"右臂零点设置完成: {failed_count} 个电机失败", "WARNING", self.log)
        return failed_count

    def set_zero_left_arm(self, timeout: float = 1.0, verbose: bool = False) -> int:
        """
        设置左臂所有电机当前位置为零点

        参数:
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 失败的电机数量，0表示全部成功

        示例:
            >>> failed = robot.set_zero_left_arm()
            >>> if failed == 0:
            >>>     print("左臂所有电机零点设置成功")
        """
        log_output("设置左臂所有电机零点...", "INFO", self.log)
        failed_count = self.left_arm.set_zero(timeout=timeout, verbose=verbose)
        if failed_count == 0:
            if verbose:
                log_output(f"左臂零点设置完成: {len(self.left_arm.motor_ids)} 个电机全部成功", "SUCCESS", self.log)
        else:
            if verbose:
                log_output(f"左臂零点设置完成: {failed_count} 个电机失败", "ERROR", self.log)
        return failed_count

    def set_zero_all_components(self, timeout: float = 1.0, verbose: bool = False) -> Dict[str, int]:
        """
        设置机器人所有部件的电机当前位置为零点（头部、双臂、升降台、底盘）

        参数:
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            Dict[str, int]: {
                'right_arm': failed_count,
                'left_arm': failed_count,
                'head': failed_count,      # 待实现
                'column': failed_count,    # 待实现
                'chassis': failed_count    # 待实现
            }

        示例:
            >>> results = robot.set_zero_all_components()
            >>> total_failed = sum(results.values())
            >>> if total_failed == 0:
            >>>     print("所有电机零点设置成功")
        """
        log_output("="*80, "INFO", self.log)
        log_output("开始设置机器人所有部件零点...", "INFO", self.log)
        log_output("="*80, "INFO", self.log)

        results = {}

        # 设置右臂零点
        try:
            results['right_arm'] = self.set_zero_right_arm(timeout=timeout, verbose=verbose)
        except Exception as e:
            log_output(f"右臂零点设置失败: {str(e)}", "ERROR", self.log)
            results['right_arm'] = len(self.right_arm.motor_ids)

        # 设置左臂零点
        try:
            results['left_arm'] = self.set_zero_left_arm(timeout=timeout, verbose=verbose)
        except Exception as e:
            log_output(f"左臂零点设置失败: {str(e)}", "ERROR", self.log)
            results['left_arm'] = len(self.left_arm.motor_ids)

        # 设置头部零点 (待实现)
        if self.head:
            try:
                log_output("设置头部所有电机零点...", "INFO", self.log)
                failed_count = self.head.set_zero(timeout=timeout, verbose=verbose)
                results['head'] = failed_count
                if failed_count == 0:
                    log_output(f"头部零点设置完成: {len(self.head.motor_ids)} 个电机全部成功", "SUCCESS", self.log)
                else:
                    log_output(f"头部零点设置完成: {failed_count} 个电机失败", "WARNING", self.log)
            except Exception as e:
                log_output(f"头部零点设置失败: {str(e)}", "ERROR", self.log)
                results['head'] = 0  # 假设头部有0个电机
        else:
            results['head'] = 0

        # 设置升降台零点
        if self.column:
            try:
                log_output("升降台设置零点（寻 HOME）...", "INFO", self.log)
                ok = self.column.start_homing()
                results['column'] = 0 if ok else 1
                if ok:
                    log_output("升降台零点设置成功", "SUCCESS", self.log)
                else:
                    log_output("升降台零点设置失败", "WARNING", self.log)
            except Exception as e:
                log_output(f"升降台零点设置失败: {str(e)}", "ERROR", self.log)
                results['column'] = 1
        else:
            results['column'] = 0

        # 设置底盘 RS 转向机械零点
        if self.chassis:
            try:
                if not self.chassis.is_connected:
                    self.chassis.connect()
                log_output("设置底盘 RS 转向机械零点...", "INFO", self.log)
                zero_results = self.chassis.set_steering_zero_passive()
                failed_count = sum(1 for r in zero_results.values() if not r.get("success"))
                results['chassis'] = failed_count
                if failed_count == 0:
                    log_output(f"底盘零点设置完成: {len(zero_results)} 个转向电机全部成功", "SUCCESS", self.log)
                else:
                    log_output(f"底盘零点设置完成: {failed_count} 个转向电机失败", "WARNING", self.log)
            except Exception as e:
                log_output(f"底盘零点设置失败: {str(e)}", "ERROR", self.log)
                results['chassis'] = len(self.chassis.motor_ids)
        else:
            results['chassis'] = 0

        # 统计总数
        total_failed = sum(results.values())
        total_motors = (len(self.right_arm.motor_ids) + len(self.left_arm.motor_ids))
        if self.head:
            total_motors += len(self.head.motor_ids)
        if self.column:
            total_motors += len(self.column.motor_ids)
        if self.chassis:
            total_motors += len(self.chassis.motor_ids)

        log_output("="*80, "INFO", self.log)
        if total_failed == 0:
            log_output(f"机器人所有部件零点设置完成: 共 {total_motors} 个电机全部成功", "SUCCESS", self.log)
        else:
            log_output(f"机器人所有部件零点设置完成: {total_failed} 个电机失败，{total_motors - total_failed} 个成功", "WARNING", self.log)
        log_output("="*80, "INFO", self.log)

        return results

    # ==================== MIT 模式回零接口 ====================

    def go_home_mit_right_arm(self, kp: Optional[Union[float, List[float]]] = None,
                              kd: Optional[Union[float, List[float]]] = None,
                              duration: float = 2.0,
                              control_freq: float = 50.0,
                              verbose: bool = False) -> Dict[int, int]:
        """
        使用 MIT 模式将右臂所有电机平滑移动到零位

        参数:
            kp (float or List[float], optional): 位置增益,如果不指定则使用右臂当前设置的百分比计算的值
            kd (float or List[float], optional): 速度增益,如果不指定则使用右臂当前设置的百分比计算的值
            duration (float): 运动持续时间(秒)
            control_freq (float): 控制频率(Hz)
            verbose (bool): 是否打印详细信息

        返回:
            Dict[int, int]: {motor_id: state} 每个电机的状态码,0=成功, 1=失败

        示例:
            >>> # 使用默认的kp和kd百分比
            >>> robot.right_arm.set_kp_kd_percent(15.0, 15.0)
            >>> results = robot.go_home_mit_right_arm()
            >>>
            >>> # 使用自定义的kp和kd值
            >>> results = robot.go_home_mit_right_arm(kp=100.0, kd=2.0)
        """
        log_output("右臂开始 MIT 模式回零...", "INFO", self.log)

        try:
            results = self.right_arm.go_home_mit(
                kp=kp, kd=kd,
                duration=duration,
                control_freq=control_freq,
                verbose=verbose
            )

            failed_count = sum(1 for state in results.values() if state != 0)
            if failed_count == 0:
                if verbose:
                    log_output(f"右臂回零完成: {len(results)} 个电机全部成功", "SUCCESS", self.log)
            else:
                if verbose:
                    log_output(f"右臂回零完成: {failed_count} 个电机失败", "WARNING", self.log)

            return results

        except Exception as e:
            if verbose:
                log_output(f"右臂回零失败: {str(e)}", "ERROR", self.log)
            return {mid: 1 for mid in self.right_arm.motor_ids}

    def go_home_mit_left_arm(self, kp: Optional[Union[float, List[float]]] = None,
                             kd: Optional[Union[float, List[float]]] = None,
                             duration: float = 2.0,
                             control_freq: float = 50.0,
                             verbose: bool = False) -> Dict[int, int]:
        """
        使用 MIT 模式将左臂所有电机平滑移动到零位

        参数:
            kp (float or List[float], optional): 位置增益,如果不指定则使用左臂当前设置的百分比计算的值
            kd (float or List[float], optional): 速度增益,如果不指定则使用左臂当前设置的百分比计算的值
            duration (float): 运动持续时间(秒)
            control_freq (float): 控制频率(Hz)
            verbose (bool): 是否打印详细信息

        返回:
            Dict[int, int]: {motor_id: state} 每个电机的状态码,0=成功, 1=失败

        示例:
            >>> # 使用默认的kp和kd百分比
            >>> robot.left_arm.set_kp_kd_percent(15.0, 15.0)
            >>> results = robot.go_home_mit_left_arm()
            >>>
            >>> # 使用自定义的kp和kd值
            >>> results = robot.go_home_mit_left_arm(kp=100.0, kd=2.0)
        """
        log_output("左臂开始 MIT 模式回零...", "INFO", self.log)

        try:
            results = self.left_arm.go_home_mit(
                kp=kp, kd=kd,
                duration=duration,
                control_freq=control_freq,
                verbose=verbose
            )

            failed_count = sum(1 for state in results.values() if state != 0)
            if failed_count == 0:
                if verbose:
                    log_output(f"左臂回零完成: {len(results)} 个电机全部成功", "SUCCESS", self.log)
            else:
                if verbose:
                    log_output(f"左臂回零完成: {failed_count} 个电机失败", "WARNING", self.log)

            return results

        except Exception as e:
            if verbose:
                log_output(f"左臂回零失败: {str(e)}", "ERROR", self.log)
            return {mid: 1 for mid in self.left_arm.motor_ids}

    def move_to_mit_right_arm(self, motor_id: Optional[int] = None,
                              position: Union[float, List[float]] = 0.0,
                              velocity: Union[float, List[float]] = 0.0,
                              torque: Union[float, List[float]] = 0.0,
                              kp: Optional[Union[float, List[float]]] = None,
                              kd: Optional[Union[float, List[float]]] = None,
                              wait_response: bool = False,
                              timeout: float = 1.0,
                              verbose: bool = False) -> Union[int, Dict[int, int]]:
        """
        右臂 MIT 模式运动控制

        参数:
            motor_id (int, optional): 电机 ID，如果为 None 则控制所有电机
            position (float or List[float]): 目标位置（弧度）
            velocity (float or List[float]): 目标速度（rad/s）
            torque (float or List[float]): 前馈扭矩（Nm）
            kp (float or List[float], optional): 位置增益
            kd (float or List[float], optional): 速度增益
            wait_response (bool): 是否等待响应
            timeout (float): 超时时间（秒）
            verbose (bool): 是否打印详细信息

        返回:
            int or Dict[int, int]: 单个电机返回状态码，多个电机返回 {motor_id: state}
        """
        return self.right_arm.move_to_mit(
            motor_id=motor_id,
            position=position,
            velocity=velocity,
            torque=torque,
            kp=kp,
            kd=kd,
            wait_response=wait_response,
            timeout=timeout,
            verbose=verbose
        )

    def move_to_mit_left_arm(self, motor_id: Optional[int] = None,
                             position: Union[float, List[float]] = 0.0,
                             velocity: Union[float, List[float]] = 0.0,
                             torque: Union[float, List[float]] = 0.0,
                             kp: Optional[Union[float, List[float]]] = None,
                             kd: Optional[Union[float, List[float]]] = None,
                             wait_response: bool = False,
                             timeout: float = 1.0,
                             verbose: bool = False) -> Union[int, Dict[int, int]]:
        """
        左臂 MIT 模式运动控制

        参数:
            motor_id (int, optional): 电机 ID，如果为 None 则控制所有电机
            position (float or List[float]): 目标位置（弧度）
            velocity (float or List[float]): 目标速度（rad/s）
            torque (float or List[float]): 前馈扭矩（Nm）
            kp (float or List[float], optional): 位置增益
            kd (float or List[float], optional): 速度增益
            wait_response (bool): 是否等待响应
            timeout (float): 超时时间（秒）
            verbose (bool): 是否打印详细信息

        返回:
            int or Dict[int, int]: 单个电机返回状态码，多个电机返回 {motor_id: state}
        """
        return self.left_arm.move_to_mit(
            motor_id=motor_id,
            position=position,
            velocity=velocity,
            torque=torque,
            kp=kp,
            kd=kd,
            wait_response=wait_response,
            timeout=timeout,
            verbose=verbose
        )

    def go_home_mit_all_components(self, kp: Optional[Union[float, List[float]]] = None,
                                   kd: Optional[Union[float, List[float]]] = None,
                                   duration: float = 2.0,
                                   control_freq: float = 50.0,
                                   verbose: bool = False) -> Dict[str, Dict[int, int]]:
        """
        使用 MIT 模式将机器人所有部件的电机平滑移动到零位(头部,双臂,升降台,底盘)

        参数:
            kp (float or List[float], optional): 位置增益,如果不指定则使用各部件当前设置的百分比计算的值
            kd (float or List[float], optional): 速度增益,如果不指定则使用各部件当前设置的百分比计算的值
            duration (float): 运动持续时间(秒)
            control_freq (float): 控制频率(Hz)
            verbose (bool): 是否打印详细信息

        返回:
            Dict[str, Dict[int, int]]: {
                'right_arm': {motor_id: state},
                'left_arm': {motor_id: state},
                'head': {motor_id: state},      # 待实现
                'column': {motor_id: state},    # 待实现
                'chassis': {motor_id: state}    # 待实现
            }

        示例:
            >>> # 使用默认的kp和kd百分比
            >>> robot.right_arm.set_kp_kd_percent(15.0, 15.0)
            >>> robot.left_arm.set_kp_kd_percent(15.0, 15.0)
            >>> results = robot.go_home_mit_all_components()
            >>>
            >>> # 使用自定义的kp和kd值
            >>> results = robot.go_home_mit_all_components(kp=100.0, kd=2.0)
        """
        log_output("="*80, "INFO", self.log)
        log_output("开始机器人所有部件 MIT 模式回零...", "INFO", self.log)
        log_output("="*80, "INFO", self.log)

        results = {}

        # 右臂回零
        try:
            results['right_arm'] = self.go_home_mit_right_arm(
                kp=kp, kd=kd,
                duration=duration,
                control_freq=control_freq,
                verbose=verbose
            )
        except Exception as e:
            if verbose:
                log_output(f"右臂回零失败: {str(e)}", "ERROR", self.log)
            results['right_arm'] = {mid: 1 for mid in self.right_arm.motor_ids}

        # 左臂回零
        try:
            results['left_arm'] = self.go_home_mit_left_arm(
                kp=kp, kd=kd,
                duration=duration,
                control_freq=control_freq,
                verbose=verbose
            )
        except Exception as e:
            if verbose:
                log_output(f"左臂回零失败: {str(e)}", "ERROR", self.log)
            results['left_arm'] = {mid: 1 for mid in self.left_arm.motor_ids}

        # 头部回零 (待实现)
        if self.head:
            try:
                log_output("头部开始 MIT 模式回零...", "INFO", self.log)
                head_results = self.head.go_home(
                    kp=kp, kd=kd,
                    duration=duration,
                    control_freq=control_freq,
                    verbose=verbose
                )
                results['head'] = head_results

                failed_count = sum(1 for state in head_results.values() if state != 0)
                if failed_count == 0:
                    log_output(f"头部回零完成: {len(head_results)} 个电机全部成功", "SUCCESS", self.log)
                else:
                    log_output(f"头部回零完成: {failed_count} 个电机失败", "WARNING", self.log)
            except Exception as e:
                log_output(f"头部回零失败: {str(e)}", "ERROR", self.log)
                results['head'] = {}
        else:
            results['head'] = {}

        # 升降台回零
        if self.column:
            try:
                log_output("升降台回零...", "INFO", self.log)
                ok = self.column.return_home()
                column_results = {self.column.node_id: 0 if ok else 1}
                results['column'] = column_results
                if ok:
                    log_output("升降台回零完成", "SUCCESS", self.log)
                else:
                    log_output("升降台回零失败", "WARNING", self.log)
            except Exception as e:
                log_output(f"升降台回零失败: {str(e)}", "ERROR", self.log)
                results['column'] = {self.column.node_id: 1}
        else:
            results['column'] = {}

        # 底盘转向逻辑回零（CSP 转 0 rad）
        if self.chassis:
            try:
                if not self.chassis.is_connected:
                    self.chassis.connect()
                log_output("底盘转向回零...", "INFO", self.log)
                self.chassis.set_all_steering_zero()
                chassis_results = {
                    self.chassis.modules[n].steering_id: 0 for n in ("FL", "FR", "BL", "BR")
                }
                results['chassis'] = chassis_results
                log_output(f"底盘转向回零完成: {len(chassis_results)} 个电机", "SUCCESS", self.log)
            except Exception as e:
                log_output(f"底盘回零失败: {str(e)}", "ERROR", self.log)
                results['chassis'] = {
                    self.chassis.modules[n].steering_id: 1 for n in ("FL", "FR", "BL", "BR")
                } if self.chassis else {}
        else:
            results['chassis'] = {}

        # 统计总数
        total_failed = 0
        total_motors = 0
        for component_results in results.values():
            total_motors += len(component_results)
            total_failed += sum(1 for state in component_results.values() if state != 0)

        log_output("="*80, "INFO", self.log)
        if total_failed == 0:
            log_output(f"机器人所有部件回零完成: 共 {total_motors} 个电机全部成功", "SUCCESS", self.log)
        else:
            log_output(f"机器人所有部件回零完成: {total_failed} 个电机失败,{total_motors - total_failed} 个成功", "WARNING", self.log)
        log_output("="*80, "INFO", self.log)

        return results

    def test_motors_one_by_one(self,
                               right_positions: Optional[List[float]] = None,
                               left_positions: Optional[List[float]] = None,
                               kp: Union[float, List[float]] = 10.0,
                               kd: Union[float, List[float]] = 1.0,
                               duration: float = 0.5,
                               verbose: bool = True) -> Dict[str, Dict[int, int]]:
        """
        逐个测试双臂电机运动 (MIT模式) - 先测试右臂，再测试左臂

        每个电机会移动到指定位置后再回零，逐个进行测试。

        参数:
            right_positions (List[float], optional): 右臂各关节目标位置 [pos1, pos2, ...pos8]
                                                     如果为None，则使用默认值 [0.2]*8
            left_positions (List[float], optional): 左臂各关节目标位置 [pos1, pos2, ...pos8]
                                                    如果为None，则使用默认值 [0.2]*8
            kp (float or List[float]): 位置增益，可以是单个值（所有电机使用相同值）
                                       或列表（每个电机使用对应值）
            kd (float or List[float]): 速度增益，可以是单个值（所有电机使用相同值）
                                       或列表（每个电机使用对应值）
            duration (float): 每次运动的持续时间(秒) (默认: 1.0)
            verbose (bool): 是否打印详细信息

        返回:
            Dict[str, Dict[int, int]]: {
                'right_arm': {motor_id: state, ...},
                'left_arm': {motor_id: state, ...}
            }
            state: 0=成功, 1=失败

        示例:
            >>> # 测试双臂，所有电机使用相同参数
            >>> robot.test_motors_one_by_one(
            >>>     right_positions=[0.2]*8,
            >>>     left_positions=[0.2]*8,
            >>>     kp=10.0, kd=1.0
            >>> )
            >>>
            >>> # 只测试右臂
            >>> robot.test_motors_one_by_one(
            >>>     right_positions=[0.2]*8,
            >>>     kp=10.0, kd=1.0
            >>> )
            >>>
            >>> # 每个电机使用不同的参数
            >>> robot.test_motors_one_by_one(
            >>>     right_positions=[0.1, 0.2, 0.3, 0.4, 0.1, 0.1, 0.1, 0.1],
            >>>     left_positions=[0.1, 0.2, 0.3, 0.4, 0.1, 0.1, 0.1, 0.1],
            >>>     kp=[5.0, 6.0, 7.0, 8.0, 5.0, 5.0, 5.0, 5.0],
            >>>     kd=[0.5, 0.6, 0.7, 0.8, 0.5, 0.5, 0.5, 0.5]
            >>> )
        """
        results = {
            'right_arm': {},
            'left_arm': {}
        }

        if verbose:
            log_output("\n" + "="*80, "INFO", self.log)
            log_output("开始逐个测试机器人双臂电机", "INFO", self.log)
            log_output("="*80, "INFO", self.log)

        # 先测试右臂
        if right_positions is not None:
            if verbose:
                log_output("\n>>> 开始测试右臂", "INFO", self.log)
            try:
                results['right_arm'] = self.right_arm.test_motors_one_by_one(
                    positions=right_positions,
                    kp=kp,
                    kd=kd,
                    duration=duration,
                    verbose=verbose
                )
            except KeyboardInterrupt:
                log_output("\n⚠ 用户中断测试", "WARNING", self.log)
                raise
            except Exception as e:
                if verbose:
                    log_output(f"右臂测试失败: {str(e)}", "ERROR", self.log)
                results['right_arm'] = {mid: 1 for mid in self.right_arm.motor_ids}

        # 再测试左臂
        if left_positions is not None:
            if verbose:
                log_output("\n>>> 开始测试左臂", "INFO", self.log)
            try:
                results['left_arm'] = self.left_arm.test_motors_one_by_one(
                    positions=left_positions,
                    kp=kp,
                    kd=kd,
                    duration=duration,
                    verbose=verbose
                )
            except KeyboardInterrupt:
                log_output("\n⚠ 用户中断测试", "WARNING", self.log)
                raise
            except Exception as e:
                if verbose:
                    log_output(f"左臂测试失败: {str(e)}", "ERROR", self.log)
                results['left_arm'] = {mid: 1 for mid in self.left_arm.motor_ids}

        # 统计总结果
        if verbose:
            total_motors = 0
            total_success = 0
            total_failed = 0

            for arm_name, arm_results in results.items():
                if arm_results:
                    total_motors += len(arm_results)
                    total_success += sum(1 for state in arm_results.values() if state == 0)
                    total_failed += sum(1 for state in arm_results.values() if state != 0)

            log_output("\n" + "="*80, "INFO", self.log)
            if total_failed == 0 and total_motors > 0:
                log_output(f"双臂测试完成: {total_success}/{total_motors} 个电机全部成功 ✓", "SUCCESS", self.log)
            elif total_motors > 0:
                log_output(f"双臂测试完成: {total_success} 个成功, {total_failed} 个失败", "WARNING", self.log)
            log_output("="*80 + "\n", "INFO", self.log)

        return results
