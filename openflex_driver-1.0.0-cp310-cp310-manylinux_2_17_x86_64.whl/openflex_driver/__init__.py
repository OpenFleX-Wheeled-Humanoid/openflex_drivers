#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   __init__.py
@Time    :   2025/12/16
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   OpenArmX Driver - Python SDK for OpenArmX robotic arm control
'''

# ==================== 主接口 ====================
from .arm import Arm
from .robot import Robot
from .head import (
    Head,
    JOINT_YAW,
    JOINT_PITCH,
    DEFAULT_MOTOR_IDS,
    JOINT_NAMES,
    DEFAULT_JOINT_LIMIT_RAD,
    DEFAULT_YAW_ACTIVE_ZERO_POS_PER,
    DEFAULT_PITCH_ACTIVE_ZERO_POS_PER,
)
from .column import (
    Column,
    HomingFeedback,
    CONTROL_MODE_VELOCITY,
    CONTROL_MODE_POSITION,
)
from .chassis import (
    Chassis,
    WheelModuleConfig,
    DEFAULT_MODULES,
    MODULE_NAMES,
    MODULE_NAMES_CN,
)
from .motor_inventory import (
    MotorSpec,
    HEAD_MOTORS,
    CHASSIS_STEERING_MOTORS,
    CHASSIS_DRIVING_MOTORS,
    COLUMN_MOTORS,
    position_motors,
    velocity_motors,
)

# ==================== 异常系统 ====================
from .exceptions import (
    # 基础异常
    OpenArmXError,

    # CAN 通信异常
    CANError,
    CANInitializationError,
    CANTimeoutError,
    CANTransmissionError,

    # 电机异常
    MotorError,
    MotorNotEnabledError,
    MotorFaultError,
    MotorTimeoutError,
    MotorCalibrationError,

    # 配置异常
    ConfigurationError,
    InvalidMotorIDError,
    InvalidModeError,
    InvalidParameterError,
    ConfigFileError,

    # 限制异常
    LimitExceededError,
    PositionLimitError,
    VelocityLimitError,
    TorqueLimitError,
    KpLimitError,
    KdLimitError,

    # 连接异常
    ConnectionError,
    ConnectionLostError,
)

# ==================== CAN 通信层 ====================
# CAN 帧收发和数据转换
from ._lib.can_comm import (
    # 数据类型转换
    float_to_uint16,
    uint16_to_float,
    float_to_P4hex,
    P4hex_to_float,

    # CAN 帧收发
    send_extended_frame_main,
    send_extended_frame_no_wait,
    send_extended_frame_with_retry,
)

# CAN 接口管理工具
from ._lib.can_utils import (
    get_available_can_interfaces,
    get_all_can_interfaces,
    check_can_interface_type,
    verify_can_interface,
    load_can_driver,
    enable_can_interface,
    disable_can_interface,
    enable_all_can_interfaces,
    disable_all_can_interfaces,
    pair_can_channels,
    CAN_DRIVER_KCAN,
    CAN_DRIVER_PEAK_USB,
    SUPPORTED_CAN_DRIVERS,
)

#    VR遥操作接口函数
from ._lib.teleop_core import(
    WeightedMovingFilter,
    OpenArmXIKSolver,
    RelativePose,
    PoseInput,
    RelativeTeleopInputFrame,
    AbsoluteTeleopInputFrame,
    TeleopConfig, 
    TeleopInputFrame, 
    TeleopStepResult,
    TeleopCoreStepResult,
    PinocchioTeleopCore,
    OpenArmTeleopController)

# 底盘舵轮运动学
from ._lib.swerve_kinematics import (
    ChassisSpeeds,
    SwerveModuleState,
    ModulePosition,
    SwerveDriveKinematics,
    normalize_angle,
    default_module_positions,
)

# ==================== 电机管理层 ====================
# 电机管理接口
from ._lib.motor_manager import (
    # 数据解析
    parse_motor_feedback,
    parse_control_mode_and_status,

    # 状态查询
    get_motor_status_readonly,
    get_motor_basic_telemetry,

    # 使能控制
    enable_motor,
    disable_motor,
    enable_all_motors,
    disable_all_motors,

    # 模式设置
    set_control_mode,

    # 参数读写
    read_motor_parameter,

    # 零点管理
    set_motor_zero,
    set_zero_sta_parameter,

    # CAN ID 设置
    set_motor_canid,
)

# 电机控制接口
from ._lib.motor_control import (
    # MIT 模式控制
    mit_motion_control,
    mit_motion_control_simple,
    mit_velocity_control,
    mit_torque_control,
    mit_move_to_zero,
    mit_move_to_zero_all,

    # CSP 模式控制
    csp_motion_control,
    csp_set_speed_limits,
    csp_move_to_flowwork,
)

# 自动标定接口
from ._lib.auto_calibration import (
    # 限位检测器
    LimitDetector,

    # 自动标定函数
    auto_calibrate_zero,
    move_to_limit,
    move_to_position_smooth,
)

# UM 轮毂电机接口
from ._lib.um_motor_manager import (
    # 基础 SDO 通信
    sdo_read_um,
    sdo_write_um,

    # TPDO 配置和解析
    configure_um_motor_tpdo,
    read_um_motor_pdo,
    parse_um_motor_pdo,

    # 状态读取
    read_um_motor_status,
    read_um_motor_position,
    read_um_motor_velocity,
    read_um_motor_temperature,

    # 扫描和 ID 设置
    scan_um_motors,
    verify_um_motor,
    set_um_motor_id,

    # 运动控制
    enable_um_motor,
    disable_um_motor,
    set_um_motor_speed_rpm,
    set_um_motor_speed_rads,
    stop_um_motor,
    clear_um_motor_alarm,
    set_um_motor_profile_params,
)

# 升降台 CANopen 通信层
from ._lib.lift_canopen import (
    DigitalInputState,
    parse_cia402_state,
    sdo_read_i32,
    sdo_write_i32,
)

# ==================== 配置和工具 ====================
# 配置加载器
from ._lib.motor_config_loader import MotorConfigLoader

# 日志工具
from ._lib.log_utils import (
    log_output,
    log_info,
    log_success,
    log_warning,
    log_error,
)

__version__ = '1.0.0'
__author__ = 'Wei Lindong'

__all__ = [
    # ==================== 主接口 ====================
    'Arm',
    'Robot',
    'Head',
    'Column',
    'HomingFeedback',
    'Chassis',
    'WheelModuleConfig',
    'DEFAULT_MODULES',
    'MODULE_NAMES',
    'MODULE_NAMES_CN',
    'JOINT_YAW',
    'JOINT_PITCH',
    'DEFAULT_MOTOR_IDS',
    'JOINT_NAMES',
    'DEFAULT_JOINT_LIMIT_RAD',
    'DEFAULT_YAW_ACTIVE_ZERO_POS_PER',
    'DEFAULT_PITCH_ACTIVE_ZERO_POS_PER',
    'CONTROL_MODE_VELOCITY',
    'CONTROL_MODE_POSITION',
    'MotorSpec',
    'HEAD_MOTORS',
    'CHASSIS_STEERING_MOTORS',
    'CHASSIS_DRIVING_MOTORS',
    'COLUMN_MOTORS',
    'position_motors',
    'velocity_motors',

    # ==================== 异常系统 ====================
    # 基础异常
    'OpenArmXError',

    # CAN 通信异常
    'CANError',
    'CANInitializationError',
    'CANTimeoutError',
    'CANTransmissionError',

    # 电机异常
    'MotorError',
    'MotorNotEnabledError',
    'MotorFaultError',
    'MotorTimeoutError',
    'MotorCalibrationError',

    # 配置异常
    'ConfigurationError',
    'InvalidMotorIDError',
    'InvalidModeError',
    'InvalidParameterError',
    'ConfigFileError',

    # 限制异常
    'LimitExceededError',
    'PositionLimitError',
    'VelocityLimitError',
    'TorqueLimitError',
    'KpLimitError',
    'KdLimitError',

    # 连接异常
    'ConnectionError',
    'ConnectionLostError',

    # ==================== CAN 通信层 ====================
    # 数据类型转换
    'float_to_uint16',
    'uint16_to_float',
    'float_to_P4hex',
    'P4hex_to_float',

    # # CAN 帧收发
    # 'send_extended_frame_main',
    # 'send_extended_frame_no_wait',
    # 'send_extended_frame_with_retry',

    # CAN 接口管理
    'get_available_can_interfaces',
    'get_all_can_interfaces',
    'check_can_interface_type',
    'verify_can_interface',
    'load_can_driver',
    'enable_can_interface',
    'disable_can_interface',
    'enable_all_can_interfaces',
    'disable_all_can_interfaces',
    'pair_can_channels',
    'CAN_DRIVER_KCAN',
    'CAN_DRIVER_PEAK_USB',
    'SUPPORTED_CAN_DRIVERS',
    
    #VR遥操作接口函数
    'RelativePose',
    'PoseInput',
    'TeleopConfig',
    'TeleopInputFrame',
    'RelativeTeleopInputFrame',
    'AbsoluteTeleopInputFrame',
    'TeleopStepResult',
    'TeleopCoreStepResult',
    'WeightedMovingFilter',
    'OpenArmXIKSolver',
    'PinocchioTeleopCore',
    'OpenArmTeleopController',

    # ==================== 底盘运动学 ====================
    'ChassisSpeeds',
    'SwerveModuleState',
    'ModulePosition',
    'SwerveDriveKinematics',
    'normalize_angle',
    'default_module_positions',

    # ==================== 电机管理层 ====================
    # 数据解析
    'parse_motor_feedback',
    'parse_control_mode_and_status',

    # 状态查询
    'get_motor_status_readonly',
    'get_motor_basic_telemetry',

    # 使能控制
    'enable_motor',
    'disable_motor',
    'enable_all_motors',
    'disable_all_motors',

    # 模式设置
    'set_control_mode',

    # 参数读写
    'read_motor_parameter',

    # 零点管理
    'set_motor_zero',
    'set_zero_sta_parameter',

    # CAN ID 设置
    'set_motor_canid',

    # ==================== 电机控制层 ====================
    # MIT 模式控制
    'mit_motion_control',
    'mit_motion_control_simple',
    'mit_velocity_control',
    'mit_torque_control',
    'mit_move_to_zero',
    'mit_move_to_zero_all',

    # CSP 模式控制
    'csp_motion_control',
    'csp_set_speed_limits',
    'csp_move_to_flowwork',

    # ==================== 自动标定层 ====================
    # 限位检测器
    'LimitDetector',

    # 自动标定函数
    'auto_calibrate_zero',
    'move_to_limit',
    'move_to_position_smooth',

    # ==================== UM 轮毂电机层 ====================
    # 基础 SDO 通信
    'sdo_read_um',
    'sdo_write_um',

    # TPDO 配置和解析
    'configure_um_motor_tpdo',
    'read_um_motor_pdo',
    'parse_um_motor_pdo',

    # 状态读取
    'read_um_motor_status',
    'read_um_motor_position',
    'read_um_motor_velocity',
    'read_um_motor_temperature',

    # 扫描和 ID 设置
    'scan_um_motors',
    'verify_um_motor',
    'set_um_motor_id',

    # 运动控制
    'enable_um_motor',
    'disable_um_motor',
    'set_um_motor_speed_rpm',
    'set_um_motor_speed_rads',
    'stop_um_motor',
    'clear_um_motor_alarm',
    'set_um_motor_profile_params',

    # ==================== 升降台 CANopen 层 ====================
    'DigitalInputState',
    'parse_cia402_state',
    'sdo_read_i32',
    'sdo_write_i32',

    # ==================== 配置和工具 ====================
    # 配置加载器
    'MotorConfigLoader',

    # 日志工具
    'log_output',
    'log_info',
    'log_success',
    'log_warning',
    'log_error',
]
