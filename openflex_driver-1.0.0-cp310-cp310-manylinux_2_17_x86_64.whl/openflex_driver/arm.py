#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   arm.py
@Time    :   2025/12/16
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   OpenArmX 机械臂控制类 - 主要对外接口
'''

import can
import time
from typing import Optional, List, Dict, Union, Tuple

# 导入异常类
from .exceptions import (
    CANInitializationError,
    InvalidMotorIDError,
    InvalidModeError,
)

# 导入内部模块
from ._lib.motor_manager import (
    enable_motor,
    disable_motor,
    enable_all_motors,
    disable_all_motors,
    set_control_mode,
    get_motor_status_readonly,
    get_motor_basic_telemetry,
    set_motor_zero,
    set_zero_sta_parameter,
    read_motor_parameter
)

from ._lib.motor_control import (
    mit_motion_control,
    mit_motion_control_simple,
    mit_move_to_zero,
    mit_move_to_zero_all,
    mit_velocity_control,
    mit_torque_control,
    csp_motion_control,
    csp_set_speed_limits,
    csp_move_to_flowwork
)

from ._lib.motor_config_loader import MotorConfigLoader
from ._lib.log_utils import log_output
from ._lib.can_utils import (
    verify_can_interface,
    enable_can_interface
)

class Arm:
    """
    OpenArmX 机械臂控制类

    这是 openarmx_driver 包的主要对外接口,用于控制基于 Robstride 电机的机械臂.
    每条机械臂有8个电机,通过 CAN 总线进行通信.

    电机配置映射:
        - 电机 1-2: RS04 型号 (大扭矩关节)
        - 电机 3-4: RS03 型号 (中扭矩关节)
        - 电机 5-8: RS00 型号 (小扭矩关节/夹爪)

    参数:
        can_channel (str): CAN 通道名称,如 'can0', 'can1' 等
        side (str, optional): 机械臂方向
            - 'left': 左臂(默认所有电机方向反转)
            - 'right': 右臂(默认所有电机方向正常)
            - None: 不使用方向配置(所有电机方向正常)
        bustype (str): CAN 总线类型,默认 'socketcan'
        bitrate (int): CAN 总线波特率,默认 1000000 (1Mbps)

    示例:
        >>> # 创建右臂实例
        >>> right_arm = Arm('can0', side='right')
        >>>
        >>> # 创建左臂实例(电机方向自动反转)
        >>> left_arm = Arm('can1', side='left')
        >>>
        >>> # 使能所有电机
        >>> right_arm.enable_all()
        >>>
        >>> # 设置为 MIT 模式并移动电机
        >>> right_arm.set_mode('mit')
        >>> right_arm.move_to_mit(motor_id=5, position=1.0, kp=20, kd=2)
        >>>
        >>> # 获取电机状态
        >>> status = right_arm.get_motor_status(motor_id=5)
        >>> print(f"角度: {status['angle']}, 速度: {status['velocity']}")
        >>>
        >>> # 停止所有电机
        >>> right_arm.disable_all()
        >>>
        >>> # 关闭连接
        >>> right_arm.close()
    """

    def __init__(self,
                 can_channel: str,
                 side: Optional[str] = None,
                 bustype: str = 'socketcan',
                 bitrate: int = 1000000,
                 auto_enable_can: bool = True,
                 driver: str = 'kcan',
                 password: Optional[str] = None,
                 motor_ids=None,
                 component_type: str = 'arm',
                 log=None):
        """
        初始化机械臂控制器

        参数:
            can_channel (str): CAN 通道名称,如 'can0', 'can1'
            side (str, optional): 机械臂方向 ('left', 'right', None)
            bustype (str): CAN 总线类型,默认 'socketcan'
            bitrate (int): CAN 总线波特率,默认 1000000
            auto_enable_can (bool): 是否自动检测并启用 CAN 接口,默认 True
            driver (str): CAN 驱动模块名称 ('kcan' 或 'peak_usb'),默认 'kcan'
            password (str, optional): sudo密码,用于自动启用CAN接口,默认 None(手动输入密码)
            log: 日志函数
        """
        self.can_channel = can_channel
        self.side = side
        self.component_type = component_type
        self.bustype = bustype
        self.bitrate = bitrate
        if motor_ids is None:
            self.motor_ids = [1, 2] if component_type == 'head' else list(range(1, 9))
        else:
            self.motor_ids = list(motor_ids)
        self.log = log

        # 检测并启用 CAN 接口
        if auto_enable_can:
            self._check_and_enable_can(can_channel, bitrate, driver, password)

        # 初始化 CAN 总线
        try:
            self.bus = can.Bus(
                channel=can_channel,
                bustype=bustype,
                bitrate=bitrate
            )
            # 导入翻译函数
            from utils.i18n import t
            side_info = t("arm_side_info_right") if side == "right" else t("arm_side_info_left") if side == "left" else ""
            log_output(t("arm_init_can_bus_initialized", channel=can_channel, side_info=side_info), "SUCCESS", self.log)
        except Exception as e:
            raise CANInitializationError(
                f"CAN bus {can_channel} init failed: {e}\n"
                f"Check:\n"
                f"  1. Interface exists (ip link show {can_channel})\n"
                f"  2. Interface is up (sudo ip link set {can_channel} up type can bitrate {bitrate})\n"
                f"  3. Sufficient permissions\n"
                f"  4. Driver loaded (lsmod | grep can)"
            )

        # 加载电机配置
        self.config_loader = MotorConfigLoader()

        # 设置方向系数
        self._setup_direction_multipliers()

        # 初始化每个电机的kp和kd最大值
        self._motor_kp_max = {}
        self._motor_kd_max = {}
        for mid in self.motor_ids:
            config = self.config_loader.get_motor_config(
                motor_id=mid, component_type=self.component_type, side=self.side)
            if config:
                self._motor_kp_max[mid] = config.get('kp', {}).get('max', 500.0)
                self._motor_kd_max[mid] = config.get('kd', {}).get('max', 5.0)
            else:
                self._motor_kp_max[mid] = 500.0
                self._motor_kd_max[mid] = 5.0

        # 初始化kp和kd百分比和实际值
        self._kp_percent = 0.2  # 默认10%
        self._kd_percent = 1.0  # 默认10%
        self._motor_kp = {}  # 每个电机的实际kp值
        self._motor_kd = {}  # 每个电机的实际kd值
        self._update_kp_kd_values()

        # 当前控制模式记录 (用于用户参考)
        self._current_mode: Dict[int, str] = {}

        # 导入翻译函数
        from utils.i18n import t
        log_output(t("arm_init_arm_initialized", motor_ids=self.motor_ids), level="SUCCESS", log=log)

    def _check_and_enable_can(self, interface: str, bitrate: int = 1000000, driver: str = 'kcan', password: Optional[str] = None):
        """
        检测并启用 CAN 接口

        参数:
            interface (str): CAN 接口名称
            bitrate (int): 波特率
            driver (str): CAN 驱动模块名称 ('kcan' 或 'peak_usb')
            password (str, optional): sudo密码,默认 None(手动输入密码)

        异常:
            CANInitializationError: 启用失败
        """
        # 检查接口是否已经启用
        if verify_can_interface(interface):
            log_output(f"✓ {interface} already up", "SUCCESS", self.log)
            return

        # 尝试启用接口
        log_output(f"⚠ {interface} not up, attempting to bring up...", "WARNING", self.log)
        success = enable_can_interface(interface, bitrate=bitrate, driver=driver, verbose=False, password=password)

        if not success:
            raise CANInitializationError(
                f"Failed to bring up {interface}. Run manually:\n"
                f"  sudo ip link set {interface} up type can bitrate {bitrate}"
            )

        log_output(f"✓ {interface} brought up successfully", "SUCCESS", self.log)

    def _setup_direction_multipliers(self):
        """
        根据 side 参数从配置文件加载电机方向系数
        """
        # 根据 side 参数从配置文件加载方向系数
        if self.component_type == 'head':
            from utils.i18n import t
            self.direction_multipliers = self.config_loader.get_direction_multipliers(
                component_type='head',
                motor_ids=self.motor_ids,
            )
            log_output("[Head] 已从配置加载方向系数", "INFO", self.log)
            reversed_motors = [mid for mid, mult in self.direction_multipliers.items() if mult < 0]
            if reversed_motors:
                log_output(t("arm_init_reversed_motors", motors=reversed_motors), "INFO", self.log)
        elif self.side in ['left', 'right']:
            self.direction_multipliers = self.config_loader.get_direction_multipliers(
                component_type=self.component_type,
                side=self.side,
                motor_ids=self.motor_ids
            )
            # 导入翻译函数
            from utils.i18n import t
            side_translated = t("arm_side_right") if self.side == "right" else t("arm_side_left")
            log_output(t("arm_init_loading_direction", side=side_translated), "INFO", self.log)
            reversed_motors = [mid for mid, mult in self.direction_multipliers.items() if mult < 0]
            if reversed_motors:
                log_output(t("arm_init_reversed_motors", motors=reversed_motors), "INFO", self.log)
            else:
                log_output(f"[Arm] All motor directions normal", "INFO", self.log)
        else:
            # 未指定方向:所有电机方向正常
            self.direction_multipliers = {i: 1.0 for i in self.motor_ids}

    def _validate_motor_id(self, motor_id: int):
        """
        验证电机ID是否有效

        参数:
            motor_id (int): 电机ID

        抛出:
            InvalidMotorIDError: 如果电机ID无效
        """
        if motor_id not in self.motor_ids:
            raise InvalidMotorIDError(
                motor_id,
                valid_range=(min(self.motor_ids), max(self.motor_ids))
            )

    def _apply_direction(self, motor_id: int, value: float) -> float:
        """
        应用方向系数到数值

        参数:
            motor_id (int): 电机ID
            value (float): 原始数值(位置,速度或扭矩)

        返回:
            float: 应用方向系数后的数值
        """
        multiplier = self.direction_multipliers.get(motor_id, 1.0)
        return value * multiplier

    def _reverse_direction(self, motor_id: int, value: float) -> float:
        """
        反向应用方向系数(用于读取反馈值)

        参数:
            motor_id (int): 电机ID
            value (float): 反馈数值(位置,速度或扭矩)

        返回:
            float: 反向应用方向系数后的数值
        """
        multiplier = self.direction_multipliers.get(motor_id, 1.0)
        return value * multiplier

    def _update_kp_kd_values(self):
        """根据当前百分比更新所有电机的kp和kd实际值"""
        for mid in self.motor_ids:
            self._motor_kp[mid] = self._motor_kp_max[mid] * (self._kp_percent / 100.0)
            self._motor_kd[mid] = self._motor_kd_max[mid] * (self._kd_percent / 100.0)

    def set_kp_kd_percent(self, kp_percent: float, kd_percent: float, verbose: bool = False):
        """
        设置kp和kd的百分比,自动计算每个电机的实际值

        参数:
            kp_percent (float): kp百分比 (0-100)
            kd_percent (float): kd百分比 (0-100)
            verbose (bool): 是否打印详细信息

        示例:
            >>> arm.set_kp_kd_percent(15.0, 15.0)  # 设置为15%
        """
        # 限制百分比范围
        kp_percent = max(0.0, min(100.0, kp_percent))
        kd_percent = max(0.0, min(100.0, kd_percent))

        self._kp_percent = kp_percent
        self._kd_percent = kd_percent
        self._update_kp_kd_values()

        if verbose:
            log_output(f"设置 kp={kp_percent}%, kd={kd_percent}%", "INFO", self.log)
            for mid in self.motor_ids:
                log_output(f"  电机ID {mid}: kp={self._motor_kp[mid]:.1f} (max={self._motor_kp_max[mid]:.1f}), "
                          f"kd={self._motor_kd[mid]:.2f} (max={self._motor_kd_max[mid]:.2f})",
                          "INFO", self.log)

    def _reverse_direction(self, motor_id: int, value: float) -> float:
        """
        反向应用方向系数(用于读取反馈值)

        参数:
            motor_id (int): 电机ID
            value (float): 反馈数值

        返回:
            float: 反向应用方向系数后的数值
        """
        multiplier = self.direction_multipliers.get(motor_id, 1.0)
        return value * multiplier  # 乘法是对称的,所以反向也是乘以相同系数

    # ==================== 基础控制方法 ====================

    def enable_arm_motors(self, motor_id: Optional[int] = None, timeout: float = 1.0, verbose: bool = False) -> Union[int, Dict[int, int]]:
        """
        使能电机

        参数:
            motor_id (int, optional): 电机ID (1-8), 如果为 None 则使能所有电机
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 当指定 motor_id 时, 返回 0=成功, 1=失败
            Dict[int, int]: 当 motor_id 为 None 时, 返回 {motor_id: state}

        抛出:
            InvalidMotorIDError: 如果电机ID无效

        示例:
            >>> # 使能单个电机
            >>> state = arm.enable_arm_motors(motor_id=5)
            >>> if state == 0:
            >>>     print("电机5使能成功")
            >>>
            >>> # 使能所有电机
            >>> results = arm.enable_arm_motors()
            >>> for mid, state in results.items():
            >>>     print(f"电机{mid}: {'成功' if state == 0 else '失败'}")
        """
        if motor_id is not None:
            # 使能单个电机
            self._validate_motor_id(motor_id)
            return enable_motor(self.bus, motor_id, timeout=timeout, verbose=verbose)
        else:
            # 使能所有电机
            return enable_all_motors(self.bus, motor_ids=self.motor_ids, verbose=verbose)

    def disable_arm_motors(self, motor_id: Optional[int] = None, timeout: float = 1.0, verbose: bool = False) -> Union[int, Dict[int, int]]:
        """
        失能电机

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则失能所有电机
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 当指定 motor_id 时,返回 0=成功, 1=失败
            Dict[int, int]: 当 motor_id 为 None 时,返回 {motor_id: state}

        抛出:
            InvalidMotorIDError: 如果电机ID无效

        示例:
            >>> # 失能单个电机
            >>> state = arm.disable_arm_motors(motor_id=5)
            >>> if state == 0:
            >>>     print("电机5失能成功")
            >>>
            >>> # 失能所有电机
            >>> results = arm.disable_arm_motors()
            >>> for mid, state in results.items():
            >>>     print(f"电机{mid}: {'成功' if state == 0 else '失败'}")
        """
        if motor_id is not None:
            # 失能单个电机
            self._validate_motor_id(motor_id)
            return disable_motor(self.bus, motor_id, timeout=timeout, verbose=verbose)
        else:
            # 失能所有电机
            return disable_all_motors(self.bus, motor_ids=self.motor_ids, verbose=verbose)

    # ==================== 模式设置 ====================

    def set_mode(self, mode: Union[str, int],
                 motor_id: Optional[int] = None,
                 timeout: float = 1.0,
                 verbose: bool = False) -> int:
        """
        设置电机控制模式

        参数:
            mode (str|int): 控制模式
                - 'mit' / 0: MIT 运控模式
                - 'csp' / 5: CSP 位置模式
                - 'pp' / 1: PP 位置模式
                - 'speed' / 2: 速度模式
                - 'current' / 3: 电流模式
            motor_id (int, optional): 电机ID,如果为 None 则设置所有电机
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 0=成功, 非0=失败(单个电机)或失败次数(所有电机)

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            InvalidModeError: 如果控制模式无效
        """
        # 验证模式
        valid_modes = ['mit', 'pp', 'speed', 'current', 'csp', 0, 1, 2, 3, 5]
        if mode not in valid_modes:
            raise InvalidModeError(mode, valid_modes=['mit', 'pp', 'speed', 'current', 'csp'])

        if motor_id is not None:
            # 验证电机ID
            self._validate_motor_id(motor_id)

            # 设置单个电机
            state = set_control_mode(self.bus, motor_id, mode=mode,
                                    timeout=timeout, verbose=verbose)
            if state == 0:
                self._current_mode[motor_id] = str(mode)
            return state
        else:
            # 设置所有电机
            failed_count = 0
            for mid in self.motor_ids:
                state = set_control_mode(self.bus, mid, mode=mode,
                                        timeout=timeout, verbose=verbose)
                if state == 0:
                    self._current_mode[mid] = str(mode)
                else:
                    failed_count += 1
                time.sleep(0.01)
            return failed_count

    # ==================== 状态查询 ====================

    def get_motor_status(self, motor_id: Optional[int] = None,
                   timeout: float = 1.0,
                   verbose: bool = False) -> Union[Optional[Dict], Dict[int, Optional[Dict]]]:
        """
        获取电机状态

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则获取所有电机状态
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            Dict 或 None: 当指定 motor_id 时,返回单个电机状态字典或 None
            Dict[int, Dict]: 当 motor_id 为 None 时,返回 {motor_id: status_dict}

        示例:
            >>> # 获取单个电机状态
            >>> status = arm.get_motor_status(motor_id=5)
            >>> print(status['angle'])
            >>>
            >>> # 获取所有电机状态
            >>> all_status = arm.get_motor_status()
            >>> print(all_status[5]['angle'])
        """
        if motor_id is not None:
            # 获取单个电机状态
            state, info = get_motor_status_readonly(
                self.bus, motor_id,
                component_type=self.component_type,
                side=self.side,
                timeout=timeout, verbose=verbose
            )

            # 应用反向方向系数到反馈值
            if state == 0 and info is not None:
                if 'angle' in info:
                    info['angle'] = self._reverse_direction(motor_id, info['angle'])
                if 'velocity' in info:
                    info['velocity'] = self._reverse_direction(motor_id, info['velocity'])
                if 'torque' in info:
                    info['torque'] = self._reverse_direction(motor_id, info['torque'])

            return info if state == 0 else None
        else:
            # 获取所有电机状态
            results = {}
            for mid in self.motor_ids:
                results[mid] = self.get_motor_status(motor_id=mid, timeout=timeout, verbose=verbose)
                time.sleep(0.01)
            return results

    def show_motor_status(self, motor_id: Optional[int] = None,
                         show_header: bool = True) -> None:
        """
        显示电机状态(格式化输出)

        参数:
            motor_id (int, optional): 电机ID,如果为None则显示所有电机
            show_header (bool): 是否显示表头

        示例:
            >>> arm.show_motor_status(3)  # 显示单个电机
            >>> arm.show_motor_status()    # 显示所有电机
        """
        # 打印表头
        if show_header:
            log_output("="*120, "INFO", self.log)
            log_output("Motor Status", "INFO", self.log)
            log_output("="*120, "INFO", self.log)
            log_output("ID | Angle(rad) | Velocity(rad/s) | Torque(Nm) | Temp     | Mode              | Status", "INFO", self.log)
            log_output("-"*120, "INFO", self.log)

        # 获取状态信息
        if motor_id is not None:
            # 显示单个电机
            try:
                info = self.get_motor_status(motor_id)
                if info:
                    self._print_single_motor_status(motor_id, info)
                else:
                    log_output(f"ID:{motor_id:2d} | ✗ No response - motor disconnected or powered off", "ERROR", self.log)
            except Exception as e:
                log_output(f"ID:{motor_id:2d} | ⚠ Error - {str(e)}", "ERROR", self.log)
        else:
            # 显示所有电机
            for mid in self.motor_ids:
                try:
                    info = self.get_motor_status(mid)
                    if info:
                        self._print_single_motor_status(mid, info)
                    else:
                        log_output(f"ID:{mid:2d} | ✗ No response", "WARNING", self.log)
                    time.sleep(0.01)
                except Exception as e:
                    log_output(f"ID:{mid:2d} | ⚠ Error - {str(e)}", "WARNING", self.log)

        if show_header:
            log_output("="*120, "INFO", self.log)

    def _print_single_motor_status(self, motor_id: int, info: dict) -> None:
        """
        打印单个电机的状态信息(内部辅助函数)

        参数:
            motor_id (int): 电机ID
            info (dict): 状态信息字典
        """
        # 根据模式状态选择图标
        mode_status = info.get('mode_status', 'Unknown')
        if 'Motor mode' in mode_status:
            mode_icon = "🟢"
        elif 'Reset mode' in mode_status:
            mode_icon = "🔴"
        elif 'Cali mode' in mode_status:
            mode_icon = "🟡"
        else:
            mode_icon = "⚪"

        # 根据故障状态选择图标
        fault_status = info.get('fault_status', 'Unknown')
        if fault_status == "Normal":
            fault_icon = "✓"
        else:
            fault_icon = "⚠"

        # 格式化输出
        log_output(f"ID:{motor_id:2d} | "
                   f"{info.get('angle', 0.0):9.3f} | "
                   f"{info.get('velocity', 0.0):11.3f} | "
                   f"{info.get('torque', 0.0):8.3f} | "
                   f"{info.get('temperature', 0.0):5.1f}°C | "
                   f"{mode_icon} {mode_status:15s} | "
                   f"{fault_icon} {fault_status}",
                   "INFO", self.log)

    # ==================== MIT 模式控制 ====================

    def move_to_mit(self, motor_id: Optional[int] = None,
                    position: Union[float, List[float]] = 0.0,
                    velocity: Union[float, List[float]] = 0.0,
                    torque: Union[float, List[float]] = 0.0,
                    kp: Optional[Union[float, List[float]]] = None,
                    kd: Optional[Union[float, List[float]]] = None,
                    wait_response: bool = False,
                    timeout: float = 1.0,
                    verbose: bool = False) -> Union[int, Dict[int, int]]:
        """
        MIT 模式运动控制

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则控制所有电机
            position (float or List[float]): 目标位置 (弧度),多电机时必须是8个元素的列表
            velocity (float or List[float]): 目标速度 (弧度/秒),多电机时必须是8个元素的列表
            torque (float or List[float]): 前馈扭矩 (牛米),多电机时必须是8个元素的列表
            kp (float or List[float], optional): 位置增益,如果不指定则使用当前设置的百分比计算的值,多电机时必须是8个元素的列表
            kd (float or List[float], optional): 速度增益,如果不指定则使用当前设置的百分比计算的值,多电机时必须是8个元素的列表
            wait_response (bool): 是否等待响应
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 当指定 motor_id 时,返回 0=成功, 1=失败
            Dict[int, int]: 当 motor_id 为 None 时,返回 {motor_id: state}

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            ValueError: 如果多电机时参数不是列表或列表长度不是8

        示例:
            >>> # 单个电机控制,使用默认kp和kd
            >>> arm.set_kp_kd_percent(15.0, 15.0)
            >>> arm.move_to_mit(motor_id=1, position=1.0)
            >>>
            >>> # 单个电机控制,使用自定义kp和kd
            >>> arm.move_to_mit(motor_id=1, position=1.0, kp=100.0, kd=2.0)
            >>>
            >>> # 所有电机控制,使用默认kp和kd
            >>> arm.move_to_mit(position=[0.5, 1.0, 1.5, 2.0, 0.0, 0.0, 0.0, 0.0])
            >>>
            >>> # 所有电机控制,使用自定义kp和kd
            >>> arm.move_to_mit(
            >>>     position=[0.5, 1.0, 1.5, 2.0, 0.0, 0.0, 0.0, 0.0],
            >>>     kp=[100, 200, 150, 150, 50, 50, 50, 50],
            >>>     kd=[2.0, 3.0, 2.5, 2.5, 1.0, 1.0, 1.0, 1.0]
            >>> )
        """
        if motor_id is not None:
            # 单个电机控制
            self._validate_motor_id(motor_id)

            # 如果没有指定kp和kd,使用当前设置的值
            if kp is None:
                kp = self._motor_kp[motor_id]
            if kd is None:
                kd = self._motor_kd[motor_id]

            # 应用方向系数
            position_cmd = self._apply_direction(motor_id, position)
            velocity_cmd = self._apply_direction(motor_id, velocity)
            torque_cmd = self._apply_direction(motor_id, torque)

            state, _, _ = mit_motion_control(
                self.bus, motor_id,
                position=position_cmd, velocity=velocity_cmd, torque=torque_cmd,
                kp=kp, kd=kd,
                component_type=self.component_type,
                side=self.side,
                wait_response=wait_response,
                timeout=timeout, verbose=verbose
            )
            return state
        else:
            # 所有电机控制
            # 验证参数必须是列表且长度为8
            if not isinstance(position, list) or len(position) != 8:
                raise ValueError("多电机控制时,position必须是8个元素的列表")
            if not isinstance(velocity, list) or len(velocity) != 8:
                raise ValueError("多电机控制时,velocity必须是8个元素的列表")
            if not isinstance(torque, list) or len(torque) != 8:
                raise ValueError("多电机控制时,torque必须是8个元素的列表")

            # 如果没有指定kp和kd,使用当前设置的值
            if kp is None:
                kp = [self._motor_kp[mid] for mid in self.motor_ids]
            else:
                if not isinstance(kp, list) or len(kp) != 8:
                    raise ValueError("多电机控制时,kp必须是8个元素的列表")

            if kd is None:
                kd = [self._motor_kd[mid] for mid in self.motor_ids]
            else:
                if not isinstance(kd, list) or len(kd) != 8:
                    raise ValueError("多电机控制时,kd必须是8个元素的列表")

            # 控制所有电机
            results = {}
            for i, mid in enumerate(self.motor_ids):
                # 应用方向系数
                position_cmd = self._apply_direction(mid, position[i])
                velocity_cmd = self._apply_direction(mid, velocity[i])
                torque_cmd = self._apply_direction(mid, torque[i])

                state, _, _ = mit_motion_control(
                    self.bus, mid,
                    position=position_cmd, velocity=velocity_cmd, torque=torque_cmd,
                    kp=kp[i], kd=kd[i],
                    component_type=self.component_type,
                    side=self.side,
                    wait_response=wait_response,
                    timeout=timeout, verbose=False  # 多电机时不打印详细信息
                )
                results[mid] = state

            if verbose:
                success_count = sum(1 for state in results.values() if state == 0)
                log_output(f"MIT控制完成: {success_count}/{len(results)} 个电机成功", "INFO", self.log)

            return results

    def go_home_mit(self, motor_id: Optional[int] = None,
                    kp: Optional[Union[float, List[float]]] = None,
                    kd: Optional[Union[float, List[float]]] = None,
                    duration: float = 2.0,
                    control_freq: float = 50.0,
                    verbose: bool = False) -> Union[int, Dict[int, int]]:
        """
        使用 MIT 模式将电机移动到零位

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则所有电机归零
            kp (float or List[float], optional): 位置增益,如果不指定则使用当前设置的百分比计算的值
            kd (float or List[float], optional): 速度增益,如果不指定则使用当前设置的百分比计算的值
            duration (float): 运动持续时间(秒) (默认: 2.0)
            control_freq (float): 控制频率(Hz) (默认: 50.0)
            verbose (bool): 是否打印详细信息

        返回:
            int: 当指定 motor_id 时,返回 0=成功, 1=失败
            Dict[int, int]: 当 motor_id 为 None 时,返回 {motor_id: state}

        示例:
            >>> # 使用默认的kp和kd百分比
            >>> arm.set_kp_kd_percent(15.0, 15.0)
            >>> arm.go_home_mit()
            >>>
            >>> # 使用自定义的kp和kd值
            >>> arm.go_home_mit(kp=100.0, kd=2.0)
            >>>
            >>> # 为每个电机指定不同的kp和kd
            >>> arm.go_home_mit(kp=[100, 200, 150, 150, 50, 50, 50, 50],
            >>>                 kd=[2.0, 3.0, 2.5, 2.5, 1.0, 1.0, 1.0, 1.0])
        """
        # 如果没有指定kp和kd,使用当前设置的值
        if kp is None and kd is None:
            if motor_id is not None:
                # 单个电机归零
                kp = self._motor_kp[motor_id]
                kd = self._motor_kd[motor_id]
            else:
                # 所有电机同时归零 - 构建kp和kd列表
                kp = [self._motor_kp[mid] for mid in self.motor_ids]
                kd = [self._motor_kd[mid] for mid in self.motor_ids]
        elif kp is None:
            # 只指定了kd,kp使用默认值
            if motor_id is not None:
                kp = self._motor_kp[motor_id]
            else:
                kp = [self._motor_kp[mid] for mid in self.motor_ids]
        elif kd is None:
            # 只指定了kp,kd使用默认值
            if motor_id is not None:
                kd = self._motor_kd[motor_id]
            else:
                kd = [self._motor_kd[mid] for mid in self.motor_ids]

        # 步骤1: 使能电机
        self.enable_arm_motors(motor_id)

        # 步骤2: 执行回零
        try:
            if motor_id is not None:
                # 单个电机归零
                result = mit_move_to_zero(
                    self.bus, motor_id,
                    kp=kp, kd=kd,
                    component_type=self.component_type,
                    side=self.side,
                    duration=duration,
                    control_freq=control_freq,
                    verbose=verbose,
                    log=self.log
                )
            else:
                # 所有电机同时归零
                result = mit_move_to_zero_all(
                    self.bus,
                    motor_ids=self.motor_ids,
                    kp=kp, kd=kd,
                    component_type=self.component_type,
                    side=self.side,
                    duration=duration,
                    control_freq=control_freq,
                    verbose=verbose,
                    log=self.log
                )
        finally:
            # 步骤3: 失能电机（无论成功还是失败都要执行）
            self.disable_arm_motors(motor_id)

        return result

    def test_motors_one_by_one(self,
                               positions: Optional[List[float]] = None,
                               kp: Union[float, List[float]] = 10.0,
                               kd: Union[float, List[float]] = 1.0,
                               duration: float = 0.5,
                               verbose: bool = True) -> Dict[int, int]:
        """
        逐个测试电机运动 (MIT模式) - 每个电机移动到指定位置后再回零

        参数:
            positions (List[float], optional): 各关节目标位置 [pos1, pos2, ...pos8]
                                              如果为None，则使用默认值 [0.2]*8
            kp (float or List[float]): 位置增益，可以是单个值（所有电机使用相同值）
                                       或列表（每个电机使用对应值）
            kd (float or List[float]): 速度增益，可以是单个值（所有电机使用相同值）
                                       或列表（每个电机使用对应值）
            duration (float): 每次运动的持续时间(秒) (默认: 1.0)
            verbose (bool): 是否打印详细信息

        返回:
            Dict[int, int]: {motor_id: state} 每个电机的测试结果，0=成功, 1=失败

        示例:
            >>> # 所有电机使用相同的位置和增益
            >>> arm.test_motors_one_by_one(
            >>>     positions=[0.2]*8,
            >>>     kp=10.0, kd=1.0
            >>> )
            >>>
            >>> # 每个电机使用不同的位置和增益
            >>> arm.test_motors_one_by_one(
            >>>     positions=[0.1, 0.2, 0.3, 0.4, 0.1, 0.1, 0.1, 0.1],
            >>>     kp=[5.0, 6.0, 7.0, 8.0, 5.0, 5.0, 5.0, 5.0],
            >>>     kd=[0.5, 0.6, 0.7, 0.8, 0.5, 0.5, 0.5, 0.5]
            >>> )
        """

        # 如果没有指定位置，使用默认值
        if positions is None:
            positions = [0.2] * 8

        # 确保positions长度为8
        if len(positions) != 8:
            raise ValueError(f"positions 长度必须为8，但得到了 {len(positions)}")

        results = {}

        if verbose:
            side_name = "右臂" if self.side == "right" else "左臂" if self.side == "left" else "机械臂"
            log_output(f"\n{'='*60}", "INFO", self.log)
            log_output(f"开始逐个测试 {side_name} 电机", "INFO", self.log)
            log_output(f"{'='*60}", "INFO", self.log)

        # 使能所有电机
        self.enable_arm_motors()

        for i, motor_id in enumerate(self.motor_ids):
            # 获取当前电机的kp和kd值
            kp_val = kp[i] if isinstance(kp, list) else kp
            kd_val = kd[i] if isinstance(kd, list) else kd
            target_pos = positions[i]

            if verbose:
                log_output(
                    f"\n[电机 {motor_id}] 测试开始 (目标位置: {target_pos:.3f} rad, kp={kp_val}, kd={kd_val})",
                    "INFO", self.log
                )

            try:
                # 步骤1: 移动到目标位置
                if verbose:
                    log_output(f"[电机 {motor_id}] 移动到目标位置 {target_pos:.3f} rad...", "INFO", self.log)

                move_state = self.move_to_mit(
                    motor_id=motor_id,
                    position=target_pos,
                    kp=kp_val,
                    kd=kd_val,
                    wait_response=False,
                    verbose=False
                )

                if move_state != 0:
                    if verbose:
                        log_output(f"[电机 {motor_id}] 移动到目标位置失败", "ERROR", self.log)
                    results[motor_id] = 1
                    self.disable_arm_motors(motor_id)
                    continue

                # 等待运动完成
                time.sleep(duration)

                # 步骤3: 回零
                if verbose:
                    log_output(f"[电机 {motor_id}] 回零中...", "INFO", self.log)

                zero_state = self.move_to_mit(
                    motor_id=motor_id,
                    position=0.0,
                    kp=kp_val,
                    kd=kd_val,
                    wait_response=True,
                    verbose=False
                )

                if zero_state != 0:
                    if verbose:
                        log_output(f"[电机 {motor_id}] 回零失败", "ERROR", self.log)
                    results[motor_id] = 1
                    self.disable_arm_motors(motor_id)
                    continue

                # 等待回零完成
                time.sleep(duration)

                # 步骤4: 失能电机
                self.disable_arm_motors(motor_id)

                if verbose:
                    log_output(f"[电机 {motor_id}] 测试完成 ✓", "SUCCESS", self.log)

                results[motor_id] = 0

            except KeyboardInterrupt:
                if verbose:
                    log_output(f"\n[电机 {motor_id}] 用户中断测试", "WARNING", self.log)
                # 确保失能电机
                try:
                    self.disable_arm_motors(motor_id)
                except:
                    pass
                results[motor_id] = 1
                raise

            except Exception as e:
                if verbose:
                    log_output(f"[电机 {motor_id}] 测试失败: {str(e)}", "ERROR", self.log)
                # 确保失能电机
                try:
                    self.disable_arm_motors(motor_id)
                except:
                    pass
                results[motor_id] = 1

        # 统计结果
        if verbose:
            success_count = sum(1 for state in results.values() if state == 0)
            failed_count = len(results) - success_count
            log_output(f"\n{'='*60}", "INFO", self.log)
            if failed_count == 0:
                log_output(f"{side_name} 测试完成: {success_count}/{len(results)} 个电机全部成功 ✓", "SUCCESS", self.log)
            else:
                log_output(f"{side_name} 测试完成: {success_count} 个成功, {failed_count} 个失败", "WARNING", self.log)
            log_output(f"{'='*60}\n", "INFO", self.log)

        return results

    # ==================== CSP 模式控制 ====================

    def move_joint_csp(self, motor_id: int,
                      position: float,
                      wait_response: bool = False,
                      timeout: float = 0.2,
                      verbose: bool = False) -> int:
        """
        CSP 模式位置控制

        参数:
            motor_id (int): 电机ID (1-8)
            position (float): 目标位置 (弧度)
            wait_response (bool): 是否等待响应
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 0=成功, 1=失败
        """
        # 应用方向系数
        position_cmd = self._apply_direction(motor_id, position)

        return csp_motion_control(
            self.bus, motor_id, position_cmd,
            component_type=self.component_type,
            side=self.side,
            wait_response=wait_response,
            timeout=timeout, verbose=verbose
        )

    def set_csp_limits(self, motor_id: Optional[int] = None,
                      speed_limit: Optional[float] = None,
                      current_limit: Optional[float] = None,
                      timeout: float = 0.2,
                      verbose: bool = False) -> int:
        """
        设置 CSP 模式的速度/电流限制

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则设置所有电机
            speed_limit (float, optional): 速度限制 (弧度/秒)
            current_limit (float, optional): 电流限制 (牛米)
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 0=成功, 非0=失败(单个电机)或失败次数(所有电机)

        示例:
            >>> # 设置单个电机的速度限制
            >>> arm.set_csp_limits(motor_id=5, speed_limit=10.0)
            >>>
            >>> # 设置所有电机的速度限制
            >>> arm.set_csp_limits(speed_limit=10.0)
        """
        if motor_id is not None:
            # 验证电机ID
            self._validate_motor_id(motor_id)

            # 设置单个电机
            return csp_set_speed_limits(
                self.bus, motor_id,
                speed_limit=speed_limit,
                current_limit=current_limit,
                component_type=self.component_type,
                side=self.side,
                timeout=timeout, verbose=verbose
            )
        else:
            # 设置所有电机
            failed_count = 0
            for mid in self.motor_ids:
                state = csp_set_speed_limits(
                    self.bus, mid,
                    speed_limit=speed_limit,
                    current_limit=current_limit,
                    component_type=self.component_type,
                    side=self.side,
                    timeout=timeout, verbose=verbose
                )
                if state != 0:
                    failed_count += 1
                time.sleep(0.01)
            return failed_count

    def move_to_csp(self, motor_id: int,
                   position: float,
                   speed_limit: Optional[float] = None,
                   current_limit: Optional[float] = None,
                   timeout: float = 1.0,
                   verbose: bool = False) -> int:
        """
        CSP 完整工作流程:设置模式,限制并移动到目标位置

        参数:
            motor_id (int): 电机ID (1-8)
            position (float): 目标位置 (弧度)
            speed_limit (float, optional): 速度限制 (弧度/秒)
            current_limit (float, optional): 电流限制 (牛米)
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 0=成功, 1=失败
        """
        # 应用方向系数
        position_cmd = self._apply_direction(motor_id, position)

        return csp_move_to_flowwork(
            self.bus, motor_id, position_cmd,
            speed_limit=speed_limit,
            current_limit=current_limit,
            component_type=self.component_type,
            side=self.side,
            timeout=timeout, verbose=verbose
        )

    # ==================== 零点设置 ====================

    def set_zero(self, motor_id: Optional[int] = None,
                timeout: float = 1.0,
                verbose: bool = False) -> int:
        """
        设置电机当前位置为零点

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则设置所有电机
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            int: 0=成功, 非0=失败(单个电机)或失败次数(所有电机)

        示例:
            >>> # 设置单个电机零点
            >>> arm.set_zero(motor_id=5)
            >>>
            >>> # 设置所有电机零点
            >>> arm.set_zero()
        """
        if motor_id is not None:
            # 验证电机ID
            self._validate_motor_id(motor_id)

            # 设置单个电机
            return set_motor_zero(self.bus, motor_id, component_type=self.component_type, side=self.side, timeout=timeout, verbose=verbose, log=self.log)
        else:
            # 设置所有电机
            failed_count = 0
            for mid in self.motor_ids:
                state = set_motor_zero(self.bus, mid, component_type=self.component_type, side=self.side, timeout=timeout, verbose=verbose, log=self.log)
                if state != 0:
                    failed_count += 1
                time.sleep(0.1)
            return failed_count

    # ==================== 参数读取 ====================

    def read_parameter(self, motor_id: Optional[int] = None,
                      param_index: Optional[int] = None,
                      timeout: float = 1.0,
                      verbose: bool = False) -> Union[Tuple[int, any], Dict[int, Tuple[int, any]]]:
        """
        读取电机参数

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则读取所有电机
            param_index (int): 参数索引 (如 0x7019)
            timeout (float): 超时时间(秒)
            verbose (bool): 是否打印详细信息

        返回:
            Tuple[int, any] 或 Dict[int, Tuple[int, any]]:
                单个电机: (state, value) state=0表示成功
                所有电机: {motor_id: (state, value)}

        示例:
            >>> # 读取单个电机参数
            >>> state, value = arm.read_parameter(motor_id=5, param_index=0x7019)
            >>>
            >>> # 读取所有电机参数
            >>> results = arm.read_parameter(param_index=0x7019)
        """
        if param_index is None:
            raise ValueError("param_index must not be None")

        if motor_id is not None:
            # 验证电机ID
            self._validate_motor_id(motor_id)

            # 读取单个电机
            return read_motor_parameter(
                self.bus, motor_id, param_index,
                timeout=timeout, verbose=verbose
            )
        else:
            # 读取所有电机
            results = {}
            for mid in self.motor_ids:
                results[mid] = read_motor_parameter(
                    self.bus, mid, param_index,
                    timeout=timeout, verbose=verbose
                )
                time.sleep(0.01)
            return results

    # ==================== 配置查询 ====================

    def get_motor_config(self, motor_id: Optional[int] = None) -> Union[Optional[Dict], Dict[int, Optional[Dict]]]:
        """
        获取电机配置参数

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则获取所有电机配置

        返回:
            Dict 或 Dict[int, Dict]:
                单个电机: 电机配置字典
                所有电机: {motor_id: 配置字典}

        示例:
            >>> # 获取单个电机配置
            >>> config = arm.get_motor_config(motor_id=5)
            >>>
            >>> # 获取所有电机配置
            >>> configs = arm.get_motor_config()
        """
        if motor_id is not None:
            # 验证电机ID
            self._validate_motor_id(motor_id)

            # 获取单个电机配置
            return self.config_loader.get_motor_config(motor_id, component_type=self.component_type, side=self.side)
        else:
            # 获取所有电机配置
            results = {}
            for mid in self.motor_ids:
                results[mid] = self.config_loader.get_motor_config(mid, component_type=self.component_type, side=self.side)
            return results

    def get_motor_limits(self, motor_id: Optional[int] = None) -> Union[Dict, Dict[int, Dict]]:
        """
        获取电机所有限制参数

        参数:
            motor_id (int, optional): 电机ID (1-8),如果为 None 则获取所有电机限制

        返回:
            Dict 或 Dict[int, Dict]:
                单个电机: 包含 P_MIN, P_MAX, T_MIN, T_MAX 等限制参数
                所有电机: {motor_id: 限制参数字典}

        示例:
            >>> # 获取单个电机限制
            >>> limits = arm.get_motor_limits(motor_id=5)
            >>>
            >>> # 获取所有电机限制
            >>> all_limits = arm.get_motor_limits()
        """
        if motor_id is not None:
            # 验证电机ID
            self._validate_motor_id(motor_id)

            # 获取单个电机限制
            return self.config_loader.get_all_limits(motor_id, component_type=self.component_type, side=self.side)
        else:
            # 获取所有电机限制
            results = {}
            for mid in self.motor_ids:
                results[mid] = self.config_loader.get_all_limits(mid, component_type=self.component_type, side=self.side)
            return results

    # ==================== 资源管理 ====================

    def close(self):
        """关闭 CAN 总线连接"""
        if hasattr(self, 'bus') and self.bus is not None:
            self.bus.shutdown()
            log_output(f"[Arm] CAN bus {self.can_channel} closed", "SUCCESS", self.log)

    def __enter__(self):
        """支持 with 语句"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """支持 with 语句自动关闭"""
        self.close()

    def __repr__(self):
        side_str = f", side='{self.side}'" if self.side else ""
        return f"Arm(can_channel='{self.can_channel}'{side_str}, motor_ids={self.motor_ids})"
