#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
头部控制接口

2 × RS00（yaw=CAN ID 1, pitch=CAN ID 2），Robstride MIT/CSP，默认 can2。
对齐 openarmx_head_hardware / HeadJointSliderPanel。
"""

from __future__ import annotations

import math
import threading
import time
from typing import Dict, List, Optional, Union

from ._lib.auto_calibration import move_to_limit, move_to_position_smooth
from ._lib.can_utils import verify_can_interface
from ._lib.log_utils import log_output
from ._lib.motor_control import mit_motion_control_simple
from ._lib.motor_manager import (
    disable_motor,
    enable_motor,
    get_motor_status_readonly,
    set_control_mode,
    set_motor_zero,
    set_zero_sta_parameter,
)
from .arm import Arm
from .exceptions import InvalidMotorIDError

JOINT_YAW = 1
JOINT_PITCH = 2
DEFAULT_MOTOR_IDS = [JOINT_YAW, JOINT_PITCH]
JOINT_NAMES = {JOINT_YAW: "yaw", JOINT_PITCH: "pitch"}
DEFAULT_JOINT_LIMIT_RAD = math.pi / 2.0
DEFAULT_YAW_ACTIVE_ZERO_POS_PER = 0.5
DEFAULT_PITCH_ACTIVE_ZERO_POS_PER = 0.75
NETWORK_DOWN_MARKERS = ("网络已关闭", "Network is down", "Failed to transmit")


class Head(Arm):
    """头部 2 自由度 RS 电机控制（复用 Arm MIT/使能/零点 API）。"""

    def __init__(
        self,
        can_channel: str = "can2",
        motor_ids: Optional[List[int]] = None,
        auto_enable_can: bool = True,
        log=None,
        active_zero_torque: float = 1.5,
        active_zero_velocity: float = 0.3,
        active_zero_pos_per: Optional[float] = None,
        active_zero_pos_per_yaw: float = DEFAULT_YAW_ACTIVE_ZERO_POS_PER,
        active_zero_pos_per_pitch: float = DEFAULT_PITCH_ACTIVE_ZERO_POS_PER,
        active_zero_max_duration: float = 20.0,
        joint_limit_rad: float = DEFAULT_JOINT_LIMIT_RAD,
        **kwargs,
    ):
        self._can_lock = threading.RLock()
        self._last_enable_errors: Dict[int, str] = {}
        super().__init__(
            can_channel=can_channel,
            side=None,
            motor_ids=motor_ids or DEFAULT_MOTOR_IDS,
            component_type="head",
            auto_enable_can=auto_enable_can,
            log=log,
            **kwargs,
        )
        self.is_enabled = False
        self.active_zero_torque = float(active_zero_torque)
        self.active_zero_velocity = float(active_zero_velocity)
        pitch_per = (
            float(active_zero_pos_per)
            if active_zero_pos_per is not None
            else float(active_zero_pos_per_pitch)
        )
        self.active_zero_pos_per_yaw = float(active_zero_pos_per_yaw)
        self.active_zero_pos_per_pitch = pitch_per
        self.active_zero_max_duration = float(active_zero_max_duration)
        self.joint_limit_rad = abs(float(joint_limit_rad))
        self._zero_offset_rad: Dict[int, float] = {mid: 0.0 for mid in self.motor_ids}
        if not auto_enable_can:
            self._release_bus_until_connect()
        log_output(
            f"头部接口已创建: {can_channel} 电机 ID={self.motor_ids}",
            "SUCCESS",
            self.log,
        )

    def _release_bus_until_connect(self) -> None:
        """延迟创建 CAN 总线，直到 connect() 在主线程调用。"""
        if hasattr(self, "bus") and self.bus is not None:
            try:
                self.bus.shutdown()
            except Exception:
                pass
            self.bus = None

    def get_zero_offset(self, motor_id: int) -> float:
        self._validate_head_motor(motor_id)
        return self._zero_offset_rad.get(motor_id, 0.0)

    def set_zero_offset(self, motor_id: int, offset_rad: float) -> None:
        self._validate_head_motor(motor_id)
        self._zero_offset_rad[motor_id] = float(offset_rad)

    def clear_zero_offset(self, motor_id: int) -> None:
        self.set_zero_offset(motor_id, 0.0)

    def to_logical_angle(self, motor_id: int, motor_angle: float) -> float:
        return float(motor_angle) - self.get_zero_offset(motor_id)

    def to_motor_angle(self, motor_id: int, logical_angle: float) -> float:
        return float(logical_angle) + self.get_zero_offset(motor_id)

    def _validate_head_motor(self, motor_id: int) -> None:
        if motor_id not in self.motor_ids:
            raise InvalidMotorIDError(
                motor_id,
                valid_range=(min(self.motor_ids), max(self.motor_ids)),
            )

    def _motor_ids(self, motor_id: Optional[int]) -> List[int]:
        if motor_id is not None:
            self._validate_head_motor(motor_id)
            return [motor_id]
        return list(self.motor_ids)

    def _get_motor_status_readonly(
        self,
        motor_id: int,
        timeout: float = 1.0,
        verbose: bool = False,
    ):
        return get_motor_status_readonly(
            self.bus,
            motor_id,
            component_type=self.component_type,
            side=self.side,
            timeout=timeout,
            verbose=verbose,
            log=self.log,
        )

    def _is_network_down_error(self, exc: Exception) -> bool:
        message = str(exc)
        return any(marker in message for marker in NETWORK_DOWN_MARKERS)

    def _shutdown_bus_locked(self) -> None:
        if hasattr(self, "bus") and self.bus is not None:
            try:
                self.bus.shutdown()
            except Exception:
                pass
            self.bus = None

    def _open_bus_locked(self) -> None:
        import can

        self._shutdown_bus_locked()
        self.bus = can.Bus(
            channel=self.can_channel,
            bustype=self.bustype,
            bitrate=self.bitrate,
        )

    def _ensure_bus_ready_locked(self, reopen: bool = False) -> None:
        if not verify_can_interface(self.can_channel):
            raise RuntimeError(f"CAN 接口 {self.can_channel} 未启动或网络已关闭")
        if reopen or not hasattr(self, "bus") or self.bus is None:
            self._open_bus_locked()

    @property
    def is_connected(self) -> bool:
        return verify_can_interface(self.can_channel)

    def connect(self) -> None:
        """建立头部 CAN 通信（需系统 CAN 接口已 UP）。"""
        with self._can_lock:
            self._ensure_bus_ready_locked(reopen=True)
            log_output(f"头部 CAN 已连接: {self.can_channel}", "SUCCESS", self.log)

    def disconnect(self) -> None:
        """断开头部 CAN 连接。"""
        with self._can_lock:
            if self.is_enabled:
                try:
                    self.disable(verbose=False)
                except Exception:
                    pass
            self.is_enabled = False
            if hasattr(self, "bus") and self.bus is not None:
                try:
                    self.bus.shutdown()
                except Exception:
                    pass
                self.bus = None
            log_output(f"头部 CAN 已断开: {self.can_channel}", "INFO", self.log)

    def enable_motor_by_id(self, motor_id: int, verbose: bool = False) -> int:
        """使能单个头部电机并切换 MIT 模式。返回 0=成功。"""
        with self._can_lock:
            self._validate_head_motor(motor_id)
            self._last_enable_errors.pop(motor_id, None)
            try:
                return self._enable_motor_by_id_once_locked(motor_id, verbose=verbose)
            except Exception as exc:
                if not self._is_network_down_error(exc):
                    self._last_enable_errors[motor_id] = str(exc)
                    raise

                self._last_enable_errors[motor_id] = f"{exc}; 已重建 CAN 连接后重试"
                self._ensure_bus_ready_locked(reopen=True)
                return self._enable_motor_by_id_once_locked(motor_id, verbose=verbose)

    def _enable_motor_by_id_once_locked(self, motor_id: int, verbose: bool = False) -> int:
        self._ensure_bus_ready_locked()

        mode_state = self.set_mode("mit", motor_id=motor_id, verbose=verbose)
        if mode_state != 0:
            self._last_enable_errors[motor_id] = f"切换 MIT 模式失败, state={mode_state}"
            return mode_state

        time.sleep(0.05)
        enable_state = self.enable_arm_motors(motor_id=motor_id, verbose=verbose)
        if enable_state != 0:
            self._last_enable_errors[motor_id] = f"发送使能命令失败, state={enable_state}"
        return enable_state

    def disable_motor_by_id(self, motor_id: int, verbose: bool = False) -> int:
        """失能单个头部电机。返回 0=成功。"""
        with self._can_lock:
            self._validate_head_motor(motor_id)
            return self.disable_arm_motors(motor_id=motor_id, verbose=verbose)

    def enable(self, verbose: bool = False) -> dict:
        with self._can_lock:
            self._last_enable_errors = {}
            self._ensure_bus_ready_locked(reopen=True)
            results: Dict[int, int] = {}
            for mid in self.motor_ids:
                try:
                    results[mid] = self.enable_motor_by_id(mid, verbose=verbose)
                except Exception as exc:
                    self._last_enable_errors[mid] = str(exc)
                    results[mid] = 1
                time.sleep(0.02)
            self.is_enabled = all(v == 0 for v in results.values()) if results else False
            return results

    def disable(self, verbose: bool = False) -> dict:
        with self._can_lock:
            results: Dict[int, int] = {}
            for mid in self.motor_ids:
                results[mid] = self.disable_motor_by_id(mid, verbose=verbose)
                time.sleep(0.02)
            self.is_enabled = False
            return results

    def set_zero_passive(
        self,
        motor_id: Optional[int] = None,
        zero_sta: int = 1,
        tolerance_rad: float = 0.05,
        timeout: float = 1.0,
        verbose: bool = False,
    ) -> Union[dict, int]:
        """
        被动回零：将当前位置写为机械零点（需手动对准期望零位）。

        优先写入机械零点；若硬件验证未通过则回退为软件零点偏移，保证当前姿态
        可作为逻辑零位供界面显示与回零使用。

        返回:
            单电机: int (0=成功)
            全部: {motor_id: 0|1}
        """
        with self._can_lock:
            single = motor_id is not None
            results: Dict[int, int] = {}

            for mid in self._motor_ids(motor_id):
                before_pos: Optional[float] = None
                rs_state, rs_info = self._get_motor_status_readonly(
                    mid, timeout=timeout
                )
                if rs_state != 0 or not rs_info:
                    results[mid] = 1
                    continue
                before_pos = rs_info.get("angle")
                if before_pos is not None:
                    before_pos = float(before_pos)

                disable_motor(self.bus, mid, timeout=timeout, log=self.log)
                time.sleep(0.02)
                set_zero_sta_parameter(
                    self.bus, mid, zero_sta, timeout=timeout, log=self.log
                )
                time.sleep(0.05)
                zero_state = set_motor_zero(
                    self.bus,
                    mid,
                    component_type=self.component_type,
                    side=self.side,
                    timeout=timeout,
                    verbose=verbose,
                    log=self.log,
                )
                time.sleep(0.1)

                after_pos: Optional[float] = None
                verify_state = 1
                for _ in range(3):
                    verify_state, verify_info = self._get_motor_status_readonly(
                        mid, timeout=timeout
                    )
                    after_pos = verify_info.get("angle") if verify_info else None
                    if (
                        verify_state == 0
                        and after_pos is not None
                        and abs(float(after_pos)) <= tolerance_rad
                    ):
                        break
                    time.sleep(0.05)

                hardware_ok = (
                    zero_state == 0
                    and verify_state == 0
                    and after_pos is not None
                    and abs(float(after_pos)) <= tolerance_rad
                )
                if hardware_ok:
                    self.clear_zero_offset(mid)
                    results[mid] = 0
                elif before_pos is not None:
                    self.set_zero_offset(mid, before_pos)
                    results[mid] = 0
                else:
                    results[mid] = 1

            if any(v == 0 for v in results.values()):
                self.is_enabled = False

            if single:
                return results[motor_id]
            return results

    @staticmethod
    def _compute_active_zero_position(
        pos_limit: float,
        neg_limit: float,
        zero_pos_per: float,
    ) -> float:
        """
        按行程比例计算自动零点位置。

        zero_pos_per=0.5 为偏航中点；0.75 表示从负限位向正限位方向 75% 处。
        """
        per = max(0.0, min(1.0, float(zero_pos_per)))
        pos_limit = float(pos_limit)
        neg_limit = float(neg_limit)
        return neg_limit + (pos_limit - neg_limit) * per

    def _active_zero_pos_per_for(self, motor_id: int) -> float:
        if motor_id == JOINT_YAW:
            return self.active_zero_pos_per_yaw
        if motor_id == JOINT_PITCH:
            return self.active_zero_pos_per_pitch
        return self.active_zero_pos_per_yaw

    def _verify_active_zero_hardware(
        self,
        motor_id: int,
        tolerance_rad: float,
        retries: int = 5,
    ) -> tuple[bool, Optional[float]]:
        """读取电机反馈，确认机械零点是否已在容差内（用于避免底层验证误报）。"""
        after_pos: Optional[float] = None
        for attempt in range(max(1, retries)):
            verify_state, verify_info = self._get_motor_status_readonly(motor_id)
            raw = verify_info.get("angle") if verify_info else None
            if raw is not None:
                after_pos = float(raw)
            if (
                verify_state == 0
                and after_pos is not None
                and abs(after_pos) <= tolerance_rad
            ):
                return True, after_pos
            if attempt + 1 < retries:
                time.sleep(0.1)
        return False, after_pos

    def _auto_calibrate_zero_joint(
        self,
        motor_id: int,
        zero_pos_per: float,
        control_torque: float,
        control_velocity: float,
        max_duration: float,
        verbose: bool = False,
    ) -> tuple[bool, Optional[float], Optional[float], Optional[float]]:
        """
        头部单关节自动设零：寻正负限位，再移动到行程比例零点并写入机械零点。
        """
        calib_kwargs = dict(
            control_torque=control_torque,
            control_velocity=control_velocity,
            max_duration=max_duration,
            component_type=self.component_type,
            side=self.side,
            verbose=verbose,
            log=self.log,
        )
        try:
            enable_motor(self.bus, motor_id=motor_id, verbose=verbose, log=self.log)
            time.sleep(0.5)

            pos_limit = move_to_limit(
                self.bus, motor_id, direction=1, **calib_kwargs
            )
            if pos_limit is None:
                return False, None, None, None
            time.sleep(1.0)

            neg_limit = move_to_limit(
                self.bus, motor_id, direction=-1, **calib_kwargs
            )
            if neg_limit is None:
                return False, None, pos_limit, None

            zero_position = self._compute_active_zero_position(
                pos_limit, neg_limit, zero_pos_per
            )
            if verbose:
                log_output(
                    f"头部电机 {motor_id}: 正限位={pos_limit:.4f} rad, "
                    f"负限位={neg_limit:.4f} rad, "
                    f"零点(比例={zero_pos_per:.2f})={zero_position:.4f} rad",
                    "INFO",
                    self.log,
                )

            move_to_position_smooth(
                self.bus,
                motor_id,
                zero_position,
                component_type=self.component_type,
                side=self.side,
                verbose=verbose,
                log=self.log,
            )
            time.sleep(0.5)

            disable_motor(self.bus, motor_id, verbose=verbose, log=self.log)
            time.sleep(0.5)

            zero_state = set_motor_zero(
                self.bus,
                motor_id,
                component_type=self.component_type,
                side=self.side,
                verbose=verbose,
                log=self.log,
            )
            if zero_state != 0:
                return False, zero_position, pos_limit, neg_limit
            time.sleep(0.5)
            return True, zero_position, pos_limit, neg_limit
        except Exception as exc:
            if verbose:
                log_output(f"头部自动设零失败: {exc}", "ERROR", self.log)
            return False, None, None, None

    def set_zero_active(
        self,
        motor_id: Optional[int] = None,
        zero_pos_per: Optional[float] = None,
        control_torque: Optional[float] = None,
        control_velocity: Optional[float] = None,
        max_duration: Optional[float] = None,
        tolerance_rad: float = 0.05,
        verbose: bool = False,
    ) -> Dict[int, dict]:
        """
        主动设零：寻正负机械限位，再按关节配置的比例写入零点。

        - 偏航：默认取行程中点 (zero_pos_per=0.5)
        - 俯仰：默认取行程 75% 处 (zero_pos_per=0.75，可在配置中调整)
        """
        with self._can_lock:
            control_torque = self.active_zero_torque if control_torque is None else float(control_torque)
            control_velocity = self.active_zero_velocity if control_velocity is None else float(control_velocity)
            max_duration = self.active_zero_max_duration if max_duration is None else float(max_duration)

            results: Dict[int, dict] = {}
            for mid in self._motor_ids(motor_id):
                joint_zero_per = (
                    float(zero_pos_per)
                    if zero_pos_per is not None
                    else self._active_zero_pos_per_for(mid)
                )
                result = {
                    "motor_id": mid,
                    "joint": JOINT_NAMES.get(mid, str(mid)),
                    "mode": "active",
                    "zero_pos_per": joint_zero_per,
                    "success": False,
                }
                try:
                    disable_motor(self.bus, mid, log=self.log)
                    time.sleep(0.05)
                    mode_state = set_control_mode(
                        self.bus, mid, mode="mit", log=self.log
                    )
                    if mode_state != 0:
                        result["error"] = f"切换 MIT 失败, state={mode_state}"
                        results[mid] = result
                        continue

                    success, zero_pos, pos_limit, neg_limit = self._auto_calibrate_zero_joint(
                        mid,
                        zero_pos_per=joint_zero_per,
                        control_torque=control_torque,
                        control_velocity=control_velocity,
                        max_duration=max_duration,
                        verbose=verbose,
                    )
                    result["pos_limit"] = pos_limit
                    result["neg_limit"] = neg_limit
                    result["computed_zero"] = zero_pos

                    hardware_ok, after_pos = self._verify_active_zero_hardware(
                        mid, tolerance_rad
                    )
                    result["after_pos"] = after_pos

                    if not success and not hardware_ok:
                        result["error"] = "主动寻限位或设零失败"
                        results[mid] = result
                        continue

                    result["success"] = hardware_ok or success
                    if result["success"]:
                        if hardware_ok:
                            self.clear_zero_offset(mid)
                        elif after_pos is not None:
                            self.set_zero_offset(mid, float(after_pos))
                        else:
                            self.set_zero_offset(mid, float(zero_pos))
                    else:
                        result["error"] = "主动回零后位置验证未通过"
                except Exception as exc:
                    result["error"] = str(exc)
                results[mid] = result
                time.sleep(0.2)

            if any(r.get("success") for r in results.values()):
                self.is_enabled = False
            return results

    def get_joint_status(self) -> dict:
        """返回 {motor_id: status_dict}。"""
        with self._can_lock:
            return {mid: self.get_motor_status(mid) for mid in self.motor_ids}

    def _clamp_joint_rad(self, position_rad: float) -> float:
        lim = self.joint_limit_rad
        return max(-lim, min(lim, float(position_rad)))

    def move_to_mit(
        self,
        motor_id: Optional[int] = None,
        position: Union[float, List[float]] = 0.0,
        velocity: Union[float, List[float]] = 0.0,
        torque: Union[float, List[float]] = 0.0,
        kp: Optional[Union[float, List[float]]] = None,
        kd: Optional[Union[float, List[float]]] = None,
        wait_response: bool = False,
        timeout: float = 1.0,
        verbose: bool = False,
    ) -> Union[int, Dict[int, int]]:
        """position 为逻辑角度（相对当前零点）。"""
        with self._can_lock:
            if motor_id is not None and not isinstance(position, list):
                clamped_logical = self._clamp_joint_rad(float(position))
                if abs(clamped_logical - float(position)) > 1e-9:
                    log_output(
                        f"头部关节 {motor_id} 目标 {math.degrees(float(position)):.2f}° "
                        f"超出 ±{math.degrees(self.joint_limit_rad):.1f}°，已钳位到 "
                        f"{math.degrees(clamped_logical):.2f}°",
                        "WARNING",
                        self.log,
                    )
                position = self.to_motor_angle(motor_id, clamped_logical)
            return super().move_to_mit(
                motor_id=motor_id,
                position=position,
                velocity=velocity,
                torque=torque,
                kp=kp,
                kd=kd,
                wait_response=wait_response,
                timeout=timeout,
                verbose=verbose,
            )

    def move_joint_delta(self, motor_id: int, delta_rad: float) -> int:
        """相对当前位置移动单关节（MIT）。"""
        with self._can_lock:
            status = self.get_motor_status(motor_id)
            if not status:
                return 1
            current = self.to_logical_angle(
                motor_id, float(status.get("angle", 0.0))
            )
            target = self._clamp_joint_rad(current + float(delta_rad))
            return self.move_to_mit(motor_id=motor_id, position=target)

    @staticmethod
    def _motor_in_mit_mode(info: Optional[dict]) -> bool:
        if not info:
            return False
        mode = str(info.get("mode_status", "")).lower()
        return "motor mode" in mode or "mit" in mode

    def _logical_for_motor(
        self,
        motor_id: int,
        start_logical: Optional[Union[float, Dict[int, float]]],
    ) -> Optional[float]:
        if start_logical is None:
            return None
        if isinstance(start_logical, dict):
            if motor_id not in start_logical:
                return None
            return float(start_logical[motor_id])
        return float(start_logical)

    def _read_motor_position(
        self,
        motor_id: int,
        fallback_logical: Optional[float] = None,
        retries: int = 3,
        timeout: float = 0.5,
    ) -> tuple[Optional[float], Optional[dict]]:
        info: Optional[dict] = None
        for _ in range(max(1, retries)):
            state, info = self._get_motor_status_readonly(
                motor_id, timeout=timeout
            )
            if state == 0 and info is not None and info.get("angle") is not None:
                return float(info["angle"]), info
            time.sleep(0.05)
        if fallback_logical is not None:
            return self.to_motor_angle(motor_id, float(fallback_logical)), info
        return None, info

    def _ensure_motor_mit_enabled(self, motor_id: int, verbose: bool = False) -> int:
        mode_state = self.set_mode("mit", motor_id=motor_id, verbose=verbose)
        if mode_state != 0:
            return mode_state
        time.sleep(0.05)
        enable_state = self.enable_arm_motors(motor_id=motor_id, verbose=verbose)
        if enable_state != 0:
            return enable_state
        time.sleep(0.05)
        return 0

    @staticmethod
    def _smoothstep(t: float) -> float:
        """S 形缓动 [0,1]，起止速度为零。"""
        t = max(0.0, min(1.0, float(t)))
        return t * t * (3.0 - 2.0 * t)

    def _hold_motor_at(self, motor_id: int, position: float, cycles: int = 3) -> int:
        """在当前物理位置短暂保持，避免使能/模式切换后位置跳变。"""
        kp = self._motor_kp[motor_id]
        kd = self._motor_kd[motor_id]
        pos = float(position)
        for _ in range(max(1, cycles)):
            state = mit_motion_control_simple(
                self.bus,
                motor_id,
                position=pos,
                kp=kp,
                kd=kd,
                component_type=self.component_type,
                verbose=False,
                log=self.log,
            )
            if state != 0:
                return state
            time.sleep(0.02)
        return 0

    def _mit_move_to_position(
        self,
        motor_id: int,
        target_position: float,
        duration: float = 2.0,
        control_freq: float = 50.0,
        verbose: bool = False,
        allow_early_exit: bool = True,
        start_motor: Optional[float] = None,
    ) -> int:
        """MIT 插值移动到指定电机坐标位置。"""
        target_position = float(target_position)
        if start_motor is not None:
            current_angle = float(start_motor)
        else:
            state, info = self._get_motor_status_readonly(
                motor_id, timeout=1.0
            )
            if state != 0 or info is None:
                log_output(f"电机ID {motor_id}: 无法读取当前状态，回零失败", "ERROR", self.log)
                return 1
            current_angle = float(info.get("angle", 0.0))

        if allow_early_exit and abs(current_angle - target_position) < 0.01:
            return 0

        total_steps = max(1, int(duration * control_freq))
        dt = 1.0 / control_freq
        kp = self._motor_kp[motor_id]
        kd = self._motor_kd[motor_id]
        delta = target_position - current_angle

        for step in range(total_steps + 1):
            t = step / total_steps
            pos = current_angle + delta * self._smoothstep(t)
            state = mit_motion_control_simple(
                self.bus,
                motor_id,
                position=pos,
                kp=kp,
                kd=kd,
                component_type=self.component_type,
                verbose=False,
                log=self.log,
            )
            if state != 0:
                log_output(
                    f"电机ID {motor_id}: 回零过程中发送指令失败 (步骤 {step}/{total_steps})",
                    "ERROR",
                    self.log,
                )
                return 1
            if step < total_steps:
                time.sleep(dt)

        if verbose:
            log_output(f"电机ID {motor_id}: 回零完成", "SUCCESS", self.log)
        return 0

    def go_home(
        self,
        motor_id: Optional[int] = None,
        duration: float = 2.0,
        control_freq: float = 50.0,
        verbose: bool = False,
        start_logical: Optional[Union[float, Dict[int, float]]] = None,
    ) -> Union[int, dict]:
        """MIT 缓动回逻辑零位（保持使能，移动到 offset 对应的物理零点）。"""
        with self._can_lock:
            single = motor_id is not None
            ids = self._motor_ids(motor_id)
            results: Dict[int, int] = {}

            for mid in ids:
                logical = self._logical_for_motor(mid, start_logical)
                if logical is not None and abs(logical) < 0.01:
                    results[mid] = 0
                    continue

                target_motor = self.to_motor_angle(mid, 0.0)
                current_motor, info = self._read_motor_position(
                    mid, fallback_logical=logical
                )
                if current_motor is None:
                    log_output(
                        f"电机ID {mid}: 无法读取当前位置，回零失败",
                        "ERROR",
                        self.log,
                    )
                    results[mid] = 1
                    continue

                if not self._motor_in_mit_mode(info):
                    enable_state = self._ensure_motor_mit_enabled(
                        mid, verbose=verbose
                    )
                    if enable_state != 0:
                        results[mid] = enable_state
                        continue
                    refreshed, info = self._read_motor_position(
                        mid, fallback_logical=logical
                    )
                    if refreshed is not None:
                        current_motor = refreshed

                hold_state = self._hold_motor_at(mid, current_motor)
                if hold_state != 0:
                    enable_state = self._ensure_motor_mit_enabled(
                        mid, verbose=verbose
                    )
                    if enable_state != 0:
                        results[mid] = enable_state
                        continue
                    hold_state = self._hold_motor_at(mid, current_motor)
                if hold_state != 0:
                    results[mid] = hold_state
                    continue

                state = self._mit_move_to_position(
                    mid,
                    target_motor,
                    duration=duration,
                    control_freq=control_freq,
                    verbose=verbose,
                    allow_early_exit=False,
                    start_motor=current_motor,
                )

                if state == 0:
                    hold_state = self._hold_motor_at(mid, target_motor, cycles=2)
                    if hold_state != 0:
                        state = hold_state

                results[mid] = state

            if any(v == 0 for v in results.values()):
                self.is_enabled = True

            if single:
                return results[motor_id]
            return results

    def stop_joints(self) -> None:
        """保持当前位置（速度/力矩归零）。"""
        with self._can_lock:
            for mid in self.motor_ids:
                try:
                    status = self.get_motor_status(mid)
                    pos = float(status.get("angle", 0.0)) if status else 0.0
                    self.move_to_mit(motor_id=mid, position=pos, velocity=0.0, torque=0.0)
                except Exception:
                    pass
