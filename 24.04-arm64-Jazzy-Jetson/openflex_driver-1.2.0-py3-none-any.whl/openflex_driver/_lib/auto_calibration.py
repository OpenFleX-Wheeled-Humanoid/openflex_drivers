#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   auto_calibration.py
@Time    :   2025/01/XX
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   自动零点标定模块
             提供自动寻找限位并设置零点的功能
'''

import time
from typing import Optional, Tuple

# 导入内部模块
from .motor_manager import (
    enable_motor,
    disable_motor,
    get_motor_status_readonly,
    set_motor_zero
)

from .motor_control import mit_motion_control

from .log_utils import log_output

# 导入异常类
try:
    from ..exceptions import (
        CANTimeoutError,
        MotorTimeoutError
    )
except ImportError:
    import sys
    import os
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, parent_dir)
    from exceptions import (
        CANTimeoutError,
        MotorTimeoutError
    )


class LimitDetector:
    """
    限位检测器

    用于检测电机是否到达机械限位位置。
    通过综合判断角度变化、速度和力矩来确定是否到位。
    """

    def __init__(self, angle_threshold=0.01, velocity_threshold=0.1,
                 torque_threshold=1.0, check_duration=0.5):
        """
        初始化限位检测器

        参数:
            angle_threshold (float): 角度变化阈值（rad），小于此值认为角度不变，默认 0.01
            velocity_threshold (float): 速度阈值（rad/s），小于此值认为速度为0，默认 0.1
            torque_threshold (float): 力矩阈值（Nm），大于此值认为遇到阻力，默认 1.0
            check_duration (float): 检测持续时间（秒），在此时间内满足条件才判定到位，默认 0.5
        """
        self.angle_threshold = angle_threshold
        self.velocity_threshold = velocity_threshold
        self.torque_threshold = torque_threshold
        self.check_duration = check_duration

        self.angle_history = []
        self.time_history = []

    def reset(self):
        """重置检测器，清空历史数据"""
        self.angle_history = []
        self.time_history = []

    def check_limit_reached(self, angle, velocity, torque):
        """
        检查是否到达限位

        参数:
            angle (float): 当前角度（rad）
            velocity (float): 当前速度（rad/s）
            torque (float): 当前力矩（Nm）

        返回:
            bool: True表示到达限位，False表示未到达
        """
        current_time = time.time()

        # 记录角度和时间
        self.angle_history.append(angle)
        self.time_history.append(current_time)

        # 保持历史记录在检测时间窗口内
        while len(self.time_history) > 0 and \
              (current_time - self.time_history[0]) > self.check_duration:
            self.angle_history.pop(0)
            self.time_history.pop(0)

        # 需要足够的历史数据
        if len(self.angle_history) < 5:
            return False

        # 检查条件1：角度变化很小
        angle_change = abs(max(self.angle_history) - min(self.angle_history))
        angle_stable = angle_change < self.angle_threshold

        # 检查条件2：速度接近0
        velocity_low = abs(velocity) < self.velocity_threshold

        # 检查条件3：力矩较大（遇到阻力）
        torque_high = abs(torque) > self.torque_threshold

        # 综合判断
        is_limit = angle_stable and velocity_low and torque_high

        return is_limit


def move_to_limit(bus, motor_id, direction,
                  control_torque=2.0, control_velocity=0.5,
                  angle_threshold=0.01, velocity_threshold=0.1,
                  torque_threshold=1.0, check_duration=0.5,
                  min_travel_distance=0.1, max_duration=15.0,
                  component_type=None, side=None, motor_model=None,
                  verbose=False, log=None):
    """
    移动电机到限位位置

    电机会以恒定速度和力矩向指定方向运动，直到检测到限位。
    限位检测基于角度稳定、速度降低和力矩增大三个条件。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        direction (int): 运动方向，1=正向，-1=反向
        control_torque (float): 控制力矩（Nm），默认 2.0
        control_velocity (float): 控制速度（rad/s），默认 0.5
        angle_threshold (float): 角度变化阈值（rad），默认 0.01
        velocity_threshold (float): 速度阈值（rad/s），默认 0.1
        torque_threshold (float): 力矩阈值（Nm），默认 1.0
        check_duration (float): 检测持续时间（秒），默认 0.5
        min_travel_distance (float): 最小运动距离（rad），运动超过此距离后才开始检测限位，默认 0.1
        max_duration (float): 最大运行时间（秒），超时则停止，默认 15.0
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        verbose (bool): 是否打印详细信息，默认 False
        log (callable): 日志函数，如果为None则使用print，默认 None

    返回:
        float: 限位位置（rad），如果失败返回 None

    异常:
        MotorTimeoutError: 超时未能到达限位
    """
    # 创建限位检测器
    detector = LimitDetector(
        angle_threshold=angle_threshold,
        velocity_threshold=velocity_threshold,
        torque_threshold=torque_threshold,
        check_duration=check_duration
    )
    detector.reset()
    start_time = time.time()

    # 记录起始位置
    state, info = get_motor_status_readonly(bus, motor_id, component_type, side, motor_model, timeout=0.1)
    start_angle = info.get('angle', 0.0) if state == 0 else 0.0
    if verbose:
        log_output(f"开始移动到{'正' if direction > 0 else '负'}向限位", "INFO", log)
        log_output(f"  起始位置: {start_angle:.4f} rad", "INFO", log)
        log_output(f"  控制参数: 速度={control_velocity * direction:.2f} rad/s, 力矩={control_torque:.2f} Nm", "INFO", log)

    limit_position = None
    enable_detection = False  # 限位检测使能标志

    try:
        while (time.time() - start_time) < max_duration:
            # 发送控制命令（速度控制 + 前馈力矩）
            mit_motion_control(
                bus,
                motor_id=motor_id,
                velocity=control_velocity * direction,
                torque=control_torque * direction,
                kp=0.0,
                kd=1.0,
                component_type=component_type,
                side=side,
                motor_model=motor_model,
                verbose=False
            )

            # 查询电机状态
            state, info = get_motor_status_readonly(bus, motor_id, component_type, side, motor_model, timeout=0.1)

            if state == 0:
                angle = info.get('angle', 0.0)
                velocity = info.get('velocity', 0.0)
                torque = info.get('torque', 0.0)

                # 计算已运动距离
                travel_distance = abs(angle - start_angle)

                # 只有运动超过最小距离后才开始检测限位
                if not enable_detection and travel_distance > min_travel_distance:
                    enable_detection = True
                    if verbose:
                        log_output(f"  已运动 {travel_distance:.3f} rad，开始检测限位", "INFO", log)

                # 检查是否到达限位
                is_limit = False
                if enable_detection:
                    is_limit = detector.check_limit_reached(angle, velocity, torque)

                # 详细输出
                if verbose:
                    elapsed = time.time() - start_time
                    if enable_detection:
                        status = "到位" if is_limit else "运行中"
                    else:
                        status = "启动中"

                    log_output(
                        f"  [{elapsed:.1f}s] {status} | "
                        f"角度: {angle:7.3f} rad | "
                        f"速度: {velocity:6.3f} rad/s | "
                        f"力矩: {torque:6.3f} Nm | "
                        f"行程: {travel_distance:6.3f} rad",
                        "INFO", log
                    )

                if is_limit:
                    limit_position = angle
                    if verbose:
                        log_output(f"  到达限位！位置: {limit_position:.4f} rad", "SUCCESS", log)
                    break

            time.sleep(0.05)  # 20Hz 控制频率

        if limit_position is None:
            if verbose:
                log_output(f"  超时！未能在 {max_duration} 秒内到达限位", "WARNING", log)

    except KeyboardInterrupt:
        if verbose:
            log_output("  用户中断", "WARNING", log)

    return limit_position


def move_to_position_smooth(bus, motor_id, target_position,
                            kp=5.0, kd=1.0, duration=2.0,
                            component_type=None, side=None, motor_model=None,
                            verbose=False, log=None):
    """
    平滑移动到指定位置

    使用较小的增益参数，实现柔和的位置控制。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        target_position (float): 目标位置（rad）
        kp (float): 位置增益，默认 5.0（较小，柔和控制）
        kd (float): 速度增益，默认 1.0（较小，柔和控制）
        duration (float): 移动持续时间（秒），默认 2.0
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        verbose (bool): 是否打印详细信息，默认 False
        log (callable): 日志函数，如果为None则使用print，默认 None

    返回:
        bool: 成功返回 True，失败返回 False
    """
    if verbose:
        log_output(f"正在移动到位置 {target_position:.4f} rad", "INFO", log)

    start_time = time.time()
    while (time.time() - start_time) < duration:
        mit_motion_control(
            bus, motor_id=motor_id,
            position=target_position,
            kp=kp,
            kd=kd,
            component_type=component_type,
            side=side,
            motor_model=motor_model,
            verbose=False
        )

        # 查询并显示状态
        if verbose:
            state, info = get_motor_status_readonly(bus, motor_id, component_type, side, motor_model, timeout=0.1)
            if state == 0:
                angle = info.get('angle', 0.0)
                error = abs(angle - target_position)
                log_output(f"  当前位置: {angle:7.4f} rad | 误差: {error:6.4f} rad", "INFO", log)

        time.sleep(0.02)

    if verbose:
        log_output("  到达目标位置", "SUCCESS", log)

    return True


def auto_calibrate_zero(bus, motor_id,
                        control_torque=2.0, control_velocity=0.5,
                        angle_threshold=0.01, velocity_threshold=0.1,
                        torque_threshold=1.0, check_duration=0.5,
                        min_travel_distance=0.1, max_duration=15.0,
                        move_kp=5.0, move_kd=1.0, move_duration=2.0,
                        zero_pos_per = 0.5,
                        component_type=None, side=None, motor_model=None,
                        verbose=False, log=None):
    """
    自动零点标定

    自动寻找电机的正负向限位，计算中点位置，并设置为零点。

    标定流程：
        1. 使能电机
        2. 正向转动到限位 → 记录位置A
        3. 反向转动到限位 → 记录位置B
        4. 计算中点位置 C = (A+B)/2
        5. 转动到中点位置C并停止
        6. 失能电机
        7. 设置零点（将当前位置设为零点）

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        control_torque (float): 寻找限位时的控制力矩（Nm），默认 2.0
        control_velocity (float): 寻找限位时的控制速度（rad/s），默认 0.5
        angle_threshold (float): 角度变化阈值（rad），默认 0.01
        velocity_threshold (float): 速度阈值（rad/s），默认 0.1
        torque_threshold (float): 力矩阈值（Nm），默认 1.0
        check_duration (float): 检测持续时间（秒），默认 0.5
        min_travel_distance (float): 最小运动距离（rad），默认 0.1
        max_duration (float): 单次移动最大时间（秒），默认 15.0
        move_kp (float): 移动到中点时的位置增益，默认 5.0
        move_kd (float): 移动到中点时的速度增益，默认 1.0
        move_duration (float): 移动到中点的持续时间（秒），默认 2.0
        zero_pos_per (float): 零点位置百分比，用来确定零点位置的，默认是取中位也就是（0.5）
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        verbose (bool): 是否打印详细信息，默认 False
        log (callable): 日志函数，如果为None则使用print，默认 None

    返回:
        tuple: (成功标志, 零点位置, 正向限位, 负向限位)
            - 成功标志 (bool): True表示标定成功，False表示失败
            - 零点位置 (float): 计算出的零点位置（rad），失败时为None
            - 正向限位 (float): 正向限位位置（rad），失败时为None
            - 负向限位 (float): 负向限位位置（rad），失败时为None

    异常:
        MotorTimeoutError: 超时未能到达限位

    示例:
        >>> import can
        >>> bus = can.interface.Bus(channel='can0', interface='socketcan', bitrate=1000000)
        >>> success, zero, pos_lim, neg_lim = auto_calibrate_zero(bus, motor_id=2, verbose=True)
        >>> if success:
        >>>     print(f"标定成功！零点: {zero:.4f} rad")

        # 测试时通过型号
        >>> success, zero, pos_lim, neg_lim = auto_calibrate_zero(bus, motor_id=2, motor_model='RS04', verbose=True)
    """
    if verbose:
        log_output("="*80, "INFO", log)
        log_output("自动零点标定程序", "INFO", log)
        log_output("="*80, "INFO", log)
        log_output(f"配置参数：", "INFO", log)
        log_output(f"  电机ID: {motor_id}", "INFO", log)
        log_output(f"  控制力矩: {control_torque} Nm", "INFO", log)
        log_output(f"  控制速度: {control_velocity} rad/s", "INFO", log)
        log_output(f"  角度阈值: {angle_threshold} rad", "INFO", log)
        log_output(f"  速度阈值: {velocity_threshold} rad/s", "INFO", log)
        log_output(f"  力矩阈值: {torque_threshold} Nm", "INFO", log)
        log_output("="*80, "INFO", log)

    try:
        # 步骤1：使能电机
        if verbose:
            log_output(f"[步骤1] 使能电机 {motor_id}", "INFO", log)
        enable_motor(bus, motor_id=motor_id, verbose=verbose)
        time.sleep(0.5)

        # 步骤2：移动到正向限位
        if verbose:
            log_output(f"[步骤2] 移动到正向限位", "INFO", log)
        pos_limit = move_to_limit(
            bus, motor_id,
            direction=1,
            control_torque=control_torque,
            control_velocity=control_velocity,
            angle_threshold=angle_threshold,
            velocity_threshold=velocity_threshold,
            torque_threshold=torque_threshold,
            check_duration=check_duration,
            min_travel_distance=min_travel_distance,
            max_duration=max_duration,
            component_type=component_type,
            side=side,
            motor_model=motor_model,
            verbose=verbose,
            log=log
        )

        if pos_limit is None:
            if verbose:
                log_output("标定失败：无法到达正向限位", "ERROR", log)
            return False, None, None, None

        time.sleep(1.0)

        # 步骤3：移动到负向限位
        if verbose:
            log_output(f"[步骤3] 移动到负向限位", "INFO", log)
        neg_limit = move_to_limit(
            bus, motor_id,
            direction=-1,
            control_torque=control_torque,
            control_velocity=control_velocity,
            angle_threshold=angle_threshold,
            velocity_threshold=velocity_threshold,
            torque_threshold=torque_threshold,
            check_duration=check_duration,
            min_travel_distance=min_travel_distance,
            max_duration=max_duration,
            component_type=component_type,
            side=side,
            motor_model=motor_model,
            verbose=verbose,
            log=log
        )

        if neg_limit is None:
            if verbose:
                log_output("标定失败：无法到达负向限位", "ERROR", log)
            return False, None, pos_limit, None

        # 步骤4：计算中点位置
        zero_position = (pos_limit + neg_limit) * zero_pos_per

        if verbose:
            log_output("="*80, "INFO", log)
            log_output("标定结果：", "INFO", log)
            log_output(f"  正向限位: {pos_limit:7.4f} rad", "INFO", log)
            log_output(f"  负向限位: {neg_limit:7.4f} rad", "INFO", log)
            log_output(f"  中点位置: {zero_position:7.4f} rad", "INFO", log)
            log_output(f"  运动范围: {abs(pos_limit - neg_limit):7.4f} rad", "INFO", log)
            log_output("="*80, "INFO", log)

        # 步骤5：移动到中点位置
        if verbose:
            log_output(f"[步骤4] 移动到中点位置", "INFO", log)
        move_to_position_smooth(
            bus, motor_id, zero_position,
            kp=move_kp, kd=move_kd, duration=move_duration,
            component_type=component_type,
            side=side,
            motor_model=motor_model,
            verbose=verbose, log=log
        )
        time.sleep(0.5)

        # 步骤6：失能电机
        if verbose:
            log_output(f"[步骤5] 失能电机", "INFO", log)
        disable_motor(bus, motor_id=motor_id, verbose=verbose)
        time.sleep(0.5)

        # 步骤7：设置零点
        if verbose:
            log_output(f"[步骤6] 设置零点", "INFO", log)
        set_motor_zero(bus, motor_id, verbose=verbose)
        time.sleep(0.5)

        if verbose:
            log_output("="*80, "INFO", log)
            log_output("零点标定完成！", "SUCCESS", log)
            log_output("="*80, "INFO", log)

        return True, zero_position, pos_limit, neg_limit

    except Exception as e:
        if verbose:
            log_output(f"标定过程出错: {e}", "ERROR", log)
        return False, None, None, None
