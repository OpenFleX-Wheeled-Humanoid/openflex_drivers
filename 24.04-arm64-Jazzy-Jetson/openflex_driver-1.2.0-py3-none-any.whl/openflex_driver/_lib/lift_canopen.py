#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
升降台（lift_slide）CANopen CiA402 通信层

对齐 lift_slide_hardware_interface.cpp 的对象字典与 SDO 读写约定。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .um_motor_manager import sdo_read_um, sdo_write_um

# CiA402 标准对象（升降台使用 0x6064 位置反馈，与 UM 轮毂 0x6063 不同）
OD_CONTROL_WORD = 0x6040
OD_STATUS_WORD = 0x6041
OD_MODE_OF_OPERATION = 0x6060
OD_MODE_OF_OPERATION_DISPLAY = 0x6061
OD_POSITION_ACTUAL = 0x6064
OD_VELOCITY_ACTUAL = 0x606C
OD_TARGET_VELOCITY = 0x60FF
OD_DIGITAL_INPUTS = 0x60FD
OD_TARGET_POSITION = 0x607A
OD_PROFILE_VELOCITY = 0x6081
OD_PROFILE_ACCELERATION = 0x6083
OD_PROFILE_DECELERATION = 0x6084

DI_CONFIG_INDICES = {
    1: 0x2400,
    2: 0x2401,
    3: 0x2402,
    4: 0x2403,
    5: 0x2404,
    6: 0x2405,
}

MODE_POSITION = 1
MODE_VELOCITY = 3

CW_NEW_SETPOINT = 0x0010
CW_CHANGE_IMMEDIATELY = 0x0020
CW_PP_ONLINE_UPDATE = 0x1000
CW_HALT = 0x0100

CMD_DISABLE_VOLTAGE = 0x0000
CMD_SHUTDOWN = 0x0006
CMD_SWITCH_ON = 0x0007
CMD_ENABLE_OPERATION = 0x000F
CMD_FAULT_RESET = 0x0080

CW_POSITION_MOVE = (
    CMD_ENABLE_OPERATION | CW_NEW_SETPOINT | CW_CHANGE_IMMEDIATELY | CW_PP_ONLINE_UPDATE
)

SW_OPERATION_ENABLED = 0x0027
SW_FAULT = 0x0008
SW_TARGET_REACHED = 0x0400


def to_i32(raw: Optional[int]) -> Optional[int]:
    if raw is None:
        return None
    value = int(raw)
    if value >= 0x80000000:
        value -= 0x100000000
    return value


def sdo_read_i32(can_interface: str, node_id: int, index: int, subindex: int = 0,
                 timeout: float = 0.15) -> Optional[int]:
    return to_i32(sdo_read_um(can_interface, node_id, index, subindex, timeout=timeout))


def sdo_write_i32(can_interface: str, node_id: int, index: int, subindex: int,
                  value: int, size: int, timeout: float = 0.15) -> bool:
    return sdo_write_um(can_interface, node_id, index, subindex, value, size, timeout=timeout)


@dataclass
class DigitalInputState:
    raw: int = 0
    cia_not: bool = False
    cia_pot: bool = False
    cia_home: bool = False
    si_levels: tuple[bool, ...] = (False,) * 6

    @classmethod
    def from_raw(cls, raw: int, di_active_low: bool = True) -> "DigitalInputState":
        di = int(raw) & 0xFFFFFFFF
        si = tuple(((di >> (4 + i)) & 1) != 0 for i in range(6))
        if di_active_low:
            si_active = tuple(not level for level in si)
        else:
            si_active = si
        return cls(
            raw=di,
            cia_not=((di >> 0) & 1) != 0,
            cia_pot=((di >> 1) & 1) != 0,
            cia_home=((di >> 2) & 1) != 0,
            si_levels=si_active,
        )

    def physical_di_level_high(self, channel: int) -> bool:
        """0x60FD bit24~29 为 DI1~DI6 物理电平（对齐 lift_slide_hardware_interface）。"""
        if 1 <= channel <= 6:
            return ((self.raw >> (24 + channel - 1)) & 1) != 0
        return False

    def physical_di_channel_active(self, channel: int, di_active_low: bool = True) -> bool:
        level_high = self.physical_di_level_high(channel)
        return (not level_high) if di_active_low else level_high

    def channel_active(self, channel: int) -> bool:
        if 1 <= channel <= 6:
            return self.si_levels[channel - 1]
        return False


def parse_cia402_state(statusword: int) -> str:
    sw = statusword & 0xFFFF
    if sw & SW_FAULT:
        return "FAULT"
    masked = sw & 0x006F
    if masked == 0x0027:
        return "OPERATION_ENABLED"
    if masked == 0x0023:
        return "SWITCHED_ON"
    if masked == 0x0021:
        return "READY_TO_SWITCH_ON"
    if masked == 0x0040:
        return "SWITCH_ON_DISABLED"
    return f"UNKNOWN(0x{sw:04X})"
