#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   motor_control.py
@Time    :   2025/10/01 11:49:13
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   电机运动控制接口
             提供MIT模式、CSP模式等运动控制功能
'''

import time
from .motor_config_loader import MotorConfigLoader
from .motor_manager import get_motor_status_readonly

# 从底层通信模块导入基础函数
from .can_comm import (
    float_to_uint16,
    send_extended_frame_main
)

# 从电机管理模块导入配置和管理函数
from .motor_manager import (
    enable_motor,
    disable_motor,
    set_control_mode,
    _write_motor_parameter
)

# 从日志工具导入统一日志函数
from .log_utils import log_output

# 导入异常类
try:
    from ..exceptions import (
        CANTimeoutError,
        CANTransmissionError,
        PositionLimitError,
        VelocityLimitError,
        TorqueLimitError,
        KpLimitError,
        KdLimitError,
        InvalidMotorIDError,
        ConfigFileError
    )
except ImportError:
    import sys
    import os
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, parent_dir)
    from exceptions import (
        CANTimeoutError,
        CANTransmissionError,
        PositionLimitError,
        VelocityLimitError,
        TorqueLimitError,
        KpLimitError,
        KdLimitError,
        InvalidMotorIDError,
        ConfigFileError
    )

motor_conf = MotorConfigLoader()


# ====================== MIT模式运动控制 ======================

def mit_motion_control(bus, motor_id, position=0.0, velocity=0.0, torque=0.0, kp=0.0, kd=0.0,
                       component_type=None, side=None, motor_model=None,
                       wait_response=False, timeout=1.0, verbose=False, log=None):
    """
    MIT模式标准运动控制函数 (MIT模式/运控模式)

    发送运动控制命令到指定电机，使用电机配置自动获取对应的限制参数。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID (1-8)
        position (float): 目标位置 (弧度, rad) (默认: 0.0)
        velocity (float): 目标速度 (弧度/秒, rad/s) (默认: 0.0)
        torque (float): 前馈扭矩 (牛米, Nm) (默认: 0.0)
        kp (float): 位置增益 KP (默认: 0.0)
        kd (float): 速度增益 KD (默认: 0.0)
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        wait_response (bool): 是否等待电机响应 (默认: False)
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        tuple: (state, rx_data, rx_arbitration_id)
            - state (int): 0=成功
            - rx_data (list): 接收到的数据 (如果 wait_response=True)
            - rx_arbitration_id (int): 接收到的仲裁ID (如果 wait_response=True)

    异常:
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 等待响应超时 (仅当 wait_response=True 时)
        InvalidMotorIDError: 电机ID无效
        ConfigFileError: 配置文件错误

    示例:
        # 基本使用：移动到位置 0.5 弧度
        state, _, _ = mit_motion_control(bus, motor_id=5, position=0.5, kp=20, kd=2)

        # 速度控制
        state, _, _ = mit_motion_control(bus, motor_id=5, velocity=5.0, kp=0, kd=1)

        # 扭矩控制
        state, _, _ = mit_motion_control(bus, motor_id=5, torque=2.0, kp=0, kd=0)

        # 完整的位置-速度-扭矩复合控制
        state, _, _ = mit_motion_control(
            bus, motor_id=5,
            position=1.0, velocity=2.0, torque=0.5,
            kp=30, kd=3, verbose=True
        )

        # 测试时通过型号获取配置
        state, _, _ = mit_motion_control(bus, motor_id=5, position=0.5, kp=20, kd=2, motor_model='RS04')
    """
    # 创建数据缓冲区
    data = [0 for _ in range(8)]

    # 1. 获取扭矩限制并编码到CAN ID中
    t_min, t_max = motor_conf.get_torque_limits(motor_id, component_type, side, motor_model)
    torque_uint16 = float_to_uint16(torque, t_min, t_max)
    arbitration_id = 0x01000000 | (torque_uint16 << 8) | motor_id

    if verbose:
        log_output(f"[Motion Control] 电机ID: {motor_id}", "INFO", log)
        log_output(f"  扭矩限制: [{t_min}, {t_max}] Nm, 扭矩值: {torque} Nm", "INFO", log)

    # 2. 编码位置参数 (Byte 0-1)

    p_min, p_max = motor_conf.get_position_limits(motor_id, component_type, side, motor_model)
    pos_uint16 = float_to_uint16(position, p_min, p_max)
    data[0] = (pos_uint16 >> 8) & 0xFF
    data[1] = pos_uint16 & 0xFF

    if verbose:
        log_output(f"  位置限制: [{p_min}, {p_max}] rad, 位置值: {position} rad", "INFO", log)

    # 3. 编码速度参数 (Byte 2-3)
    v_min, v_max = motor_conf.get_velocity_limits(motor_id, component_type, side, motor_model)
    vel_uint16 = float_to_uint16(velocity, v_min, v_max)
    data[2] = (vel_uint16 >> 8) & 0xFF
    data[3] = vel_uint16 & 0xFF

    if verbose:
        log_output(f"  速度限制: [{v_min}, {v_max}] rad/s, 速度值: {velocity} rad/s", "INFO", log)

    # 4. 编码KP参数 (Byte 4-5)
    kp_min, kp_max = motor_conf.get_kp_limits(motor_id, component_type, side, motor_model)
    kp_uint16 = float_to_uint16(kp, kp_min, kp_max)
    data[4] = (kp_uint16 >> 8) & 0xFF
    data[5] = kp_uint16 & 0xFF

    if verbose:
        log_output(f"  KP限制: [{kp_min}, {kp_max}], KP值: {kp}", "INFO", log)

    # 5. 编码KD参数 (Byte 6-7)
    kd_min, kd_max = motor_conf.get_kd_limits(motor_id, component_type, side, motor_model)
    kd_uint16 = float_to_uint16(kd, kd_min, kd_max)
    data[6] = (kd_uint16 >> 8) & 0xFF
    data[7] = kd_uint16 & 0xFF

    if verbose:
        log_output(f"  KD限制: [{kd_min}, {kd_max}], KD值: {kd}", "INFO", log)

    # 6. 发送CAN消息
    block_receive = 1 if wait_response else 0
    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=block_receive,
        timeout=timeout,
        verbose=verbose
    )

    return (state, rx_data, rx_arbitration_id)


def mit_motion_control_simple(bus, motor_id, position, kp=5.0, kd=0.5,
                              component_type=None, side=None, motor_model=None,
                              verbose=False, log=None):
    """
    MIT模式简化的位置控制函数

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        position (float): 目标位置 (弧度)
        kp (float): 位置增益 (默认: 5.0)
        kd (float): 速度增益 (默认: 0.5)
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        verbose (bool): 调试输出 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 1=失败
    """
    state, _, _ = mit_motion_control(
        bus, motor_id,
        position=position,
        velocity=0.0,
        torque=0.0,
        kp=kp,
        kd=kd,
        component_type=component_type,
        side=side,
        motor_model=motor_model,
        wait_response=False,
        verbose=verbose,
        log=log
    )
    return state


def mit_move_to_zero(bus, motor_id, kp=5.0, kd=0.5,
                     component_type=None, side=None, motor_model=None,
                     duration=2.0, control_freq=50.0,
                     verbose=False, log=None):
    """
    MIT模式：将电机平滑移动到零位

    先读取当前电机角度，然后通过插值让电机匀速缓慢地回到零位

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        kp (float): 位置增益 (默认: 5.0 - 较小值以平稳归零)
        kd (float): 速度增益 (默认: 0.5)
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        duration (float): 运动持续时间(秒) (默认: 2.0)
        control_freq (float): 控制频率(Hz) (默认: 50.0)
        verbose (bool): 调试输出 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 1=失败
    """
    # 1. 读取当前电机角度
    state, info = get_motor_status_readonly(
        bus, motor_id,
        component_type=component_type,
        side=side,
        motor_model=motor_model,
        timeout=1.0,
        verbose=verbose,
        log=log
    )

    if state != 0 or info is None:
        log_output(f"电机ID {motor_id}: 无法读取当前状态，回零失败", "ERROR", log)
        return 1

    current_angle = info.get('angle', 0.0)

    if verbose:
        log_output(f"电机ID {motor_id}: 当前角度 {current_angle:.3f} rad，开始回零", "INFO", log)

    # 如果当前角度已经接近零位（误差小于0.01弧度），直接返回成功
    if abs(current_angle) < 0.01:
        if verbose:
            log_output(f"电机ID {motor_id}: 已在零位附近，无需移动", "INFO", log)
        return 0

    # 2. 计算插值参数
    total_steps = int(duration * control_freq)
    dt = 1.0 / control_freq

    if total_steps < 1:
        total_steps = 1

    # 3. 执行插值运动
    for step in range(total_steps + 1):
        # 线性插值：从 current_angle 到 0.0
        t = step / total_steps  # 归一化时间 [0, 1]
        target_position = current_angle * (1.0 - t)  # 线性插值到零位

        # 发送控制指令
        state = mit_motion_control_simple(
            bus, motor_id,
            position=target_position,
            kp=kp, kd=kd,
            component_type=component_type,
            side=side,
            motor_model=motor_model,
            verbose=False,  # 插值过程中不打印详细信息
            log=log
        )

        if state != 0:
            log_output(f"电机ID {motor_id}: 回零过程中发送指令失败 (步骤 {step}/{total_steps})", "ERROR", log)
            return 1

        # 等待下一个控制周期
        if step < total_steps:
            time.sleep(dt)

    if verbose:
        log_output(f"电机ID {motor_id}: 回零完成", "SUCCESS", log)

    return 0


def mit_move_to_zero_all(bus, motor_ids=None, kp=5.0, kd=0.5,
                         component_type=None, side=None, motor_model=None,
                         duration=2.0, control_freq=50.0,
                         verbose=False, log=None):
    """
    MIT模式：将多个电机同时平滑移动到零位

    先读取所有电机的当前角度，然后通过插值让所有电机近似同时匀速回到零位。
    虽然CAN总线是串行通信，但在同一个时间步内快速依次发送指令，可以达到近似同时的效果。

    参数:
        bus (can.Bus): CAN总线对象
        motor_ids (list): 电机ID列表
        kp (float or list): 位置增益，可以是单个值或列表 (默认: 5.0)
        kd (float or list): 速度增益，可以是单个值或列表 (默认: 0.5)
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        duration (float): 运动持续时间(秒) (默认: 2.0)
        control_freq (float): 控制频率(Hz) (默认: 50.0)
        verbose (bool): 调试输出 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        dict: {motor_id: state} 每个电机的状态码，0=成功, 1=失败
    """
    # 1. 读取所有电机的当前角度
    current_angles = {}
    results = {}

    if motor_ids is None:
        motor_ids = list(range(1, 9))  # 默认 1-8

    for motor_id in motor_ids:
        state, info = get_motor_status_readonly(
            bus, motor_id,
            component_type=component_type,
            side=side,
            motor_model=motor_model,
            timeout=1.0,
            verbose=False,
            log=log
        )

        if state != 0 or info is None:
            if verbose:
                log_output(f"电机ID {motor_id}: 无法读取当前状态，回零失败", "ERROR", log)
            results[motor_id] = 1
            current_angles[motor_id] = None
        else:
            current_angles[motor_id] = info.get('angle', 0.0)
            if verbose:
                log_output(f"电机ID {motor_id}: 当前角度 {current_angles[motor_id]:.3f} rad", "INFO", log)

    # 2. 计算插值参数
    total_steps = int(duration * control_freq)
    dt = 1.0 / control_freq

    if total_steps < 1:
        total_steps = 1

    # 3. 所有电机同时执行插值运动
    for step in range(total_steps + 1):
        t = step / total_steps  # 归一化时间 [0, 1]

        for i, motor_id in enumerate(motor_ids):
            # 跳过读取失败的电机
            if current_angles[motor_id] is None:
                continue

            # 如果已经在零位附近，跳过
            if abs(current_angles[motor_id]) < 0.01:
                if motor_id not in results:
                    results[motor_id] = 0
                continue

            # 线性插值：从 current_angle 到 0.0
            target_position = current_angles[motor_id] * (1.0 - t)

            # 获取对应的kp和kd值
            kp_val = kp[i] if isinstance(kp, list) else kp
            kd_val = kd[i] if isinstance(kd, list) else kd

            # 发送控制指令
            state = mit_motion_control_simple(
                bus, motor_id,
                position=target_position,
                kp=kp_val, kd=kd_val,
                component_type=component_type,
                side=side,
                motor_model=motor_model,
                verbose=False,
                log=log
            )

            if state != 0:
                log_output(f"电机ID {motor_id}: 回零过程中发送指令失败 (步骤 {step}/{total_steps})", "ERROR", log)
                results[motor_id] = 1
            elif step == total_steps:
                # 最后一步，标记成功
                results[motor_id] = 0

        # 等待下一个控制周期
        if step < total_steps:
            time.sleep(dt)

    # 确保所有电机都有结果
    for motor_id in motor_ids:
        if motor_id not in results:
            results[motor_id] = 0

    if verbose:
        success_count = sum(1 for state in results.values() if state == 0)
        log_output(f"多电机回零完成: {success_count}/{len(results)} 个电机成功", "SUCCESS", log)

    return results


def mit_velocity_control(bus, motor_id, velocity, kd=2.0,
                         component_type=None, side=None, motor_model=None,
                         verbose=False, log=None):
    """
    MIT模式：速度控制函数

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        velocity (float): 目标速度 (弧度/秒)
        kd (float): 速度增益 (默认: 2.0)
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        verbose (bool): 调试输出 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 1=失败
    """
    state, _, _ = mit_motion_control(
        bus, motor_id,
        position=0.0,
        velocity=velocity,
        torque=0.0,
        kp=0.0,  # 位置控制关闭
        kd=kd,
        component_type=component_type,
        side=side,
        motor_model=motor_model,
        wait_response=False,
        verbose=verbose,
        log=log
    )
    return state


def mit_torque_control(bus, motor_id, torque,
                       component_type=None, side=None, motor_model=None,
                       verbose=False, log=None):
    """
    MIT模式：扭矩控制函数 (开环力矩控制)

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        torque (float): 目标扭矩 (牛米)
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        verbose (bool): 调试输出 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 1=失败
    """
    state, _, _ = mit_motion_control(
        bus, motor_id,
        position=0.0,
        velocity=0.0,
        torque=torque,
        kp=0.0,
        kd=0.0,
        component_type=component_type,
        side=side,
        motor_model=motor_model,
        wait_response=False,
        verbose=verbose,
        log=log
    )
    return state


# ====================== 位置模式 (CSP) 运动控制接口 ======================

# 依据《灵足时代 RS03 说明书》与本仓库 Robstride 协议实现：
# - 进入位置模式需要通过通信类型 0x1200 设置控制模式为 1
# - 位置目标、速度/电流限制通过通信类型 0x1200 写入单个参数：
#   - 0x7016 LOC_REF   位置模式角度指令 (float, 单位: rad)
#   - 0x7017 LIMIT_SPD 位置模式速度限制 (float, 单位: rad/s)
#   - 0x7018 LIMIT_CUR 位置/速度模式电流限制 (float, 单位: N·m)
# - 本实现使用 socketcan + python-can 的扩展帧发送


def csp_set_speed_limits(bus, motor_id, *, speed_limit=None, current_limit=None,
                         component_type=None, side=None, motor_model=None,
                         timeout=0.2, verbose=False, wait_response=True, log=None):
    """
    设置 CSP 模式下的速度/电流限制。

    - speed_limit 写 0x7017 (rad/s)
    - current_limit 写 0x7018 (N·m)
    若为 None 则跳过对应设置。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        speed_limit (float): 速度限制 (rad/s)，可选
        current_limit (float): 电流限制 (N·m)，可选
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        timeout (float): 超时时间 (默认: 0.2)
        verbose (bool): 调试输出 (默认: False)
        wait_response (bool): 是否等待响应 (默认: True)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 非0=失败
    """
    # 取各项限制，做范围裁剪
    v_min, v_max = motor_conf.get_velocity_limits(motor_id, component_type, side, motor_model)
    t_min, t_max = motor_conf.get_torque_limits(motor_id, component_type, side, motor_model)

    state_agg = 0

    if speed_limit is not None:
        v_cmd = max(min(float(speed_limit), v_max), v_min)
        s, _, _ = _write_motor_parameter(bus, motor_id, 0x7017, v_cmd,
                                         value_type='float', timeout=timeout,
                                         verbose=verbose, wait_response=wait_response, log=log)
        state_agg |= s

    if current_limit is not None:
        c_cmd = max(min(float(current_limit), t_max), t_min)
        s, _, _ = _write_motor_parameter(bus, motor_id, 0x7018, c_cmd,
                                         value_type='float', timeout=timeout,
                                         verbose=verbose, wait_response=wait_response, log=log)
        state_agg |= s

    return state_agg


def csp_motion_control(bus, motor_id, position, *,
                       component_type=None, side=None, motor_model=None,
                       wait_response=False, timeout=0.2, verbose=False, log=None):
    """
    CSP模式运动控制函数（发送位置指令）

    纯粹的 CSP 位置指令发送函数，只负责写入目标位置（LOC_REF 0x7016）。
    使用前需确保电机已设置为 CSP 模式并使能。

    参数:
        bus (can.Bus): CAN 总线
        motor_id (int): 电机ID
        position (float): 目标位置 (rad)
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        wait_response (bool): 是否等待单包回包（循环控制通常设为 False）
        timeout (float): 超时 (默认: 0.2)
        verbose (bool): 调试输出 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 0 成功, 非 0 失败

    用法示例:
        # 初始化：设置模式和限制（只需一次）
        set_control_mode(bus, 5, mode='csp')
        enable_motor(bus, 5)
        csp_set_speed_limits(bus, 5, speed_limit=5.0, current_limit=8.0)

        # 循环发送位置指令（高频）
        for p in traj:  # traj 为离散轨迹
            csp_motion_control(bus, 5, position=p)
            time.sleep(0.002)  # 2ms 周期

        # 测试时通过型号获取配置
        csp_motion_control(bus, 5, position=1.0, motor_model='RS04')
    """
    # 位置裁剪
    p_min, p_max = motor_conf.get_position_limits(motor_id, component_type, side, motor_model)
    p_cmd = max(min(float(position), p_max), p_min)

    # 写 LOC_REF (0x7016)
    state, _, _ = _write_motor_parameter(bus, motor_id, 0x7016, p_cmd,
                                         value_type='float', timeout=timeout,
                                         verbose=verbose, wait_response=wait_response, log=log)

    return state


def csp_move_to_flowwork(bus, motor_id, position, *,
                         speed_limit=None, current_limit=None,
                         component_type=None, side=None, motor_model=None,
                         require_disabled=True,
                         timeout=1.0, verbose=False, log=None):
    """
    严格按说明书的 CSP 流程执行，以保证进入 CSP 并转到目标位置。

    步骤:
      1) 在失能状态写 RUN_MODE=5 (CSP)
      2) 写 LIMIT_CUR(0x7018)、LIMIT_SPD(0x7017)
      3) 使能
      4) 写 LOC_REF(0x7016)

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        position (float): 目标位置 (rad)
        speed_limit (float): 速度限制 (rad/s)，可选
        current_limit (float): 电流限制 (N·m)，可选
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        require_disabled (bool): 是否需要先失能电机 (默认: True)
        timeout (float): 超时时间 (默认: 1.0)
        verbose (bool): 调试输出 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 0=成功, 1=失败
    """
    state = 0
    # 失能电机
    if require_disabled:
        s = disable_motor(bus, motor_id, timeout=timeout, verbose=verbose, log=log)
        state |= s
        time.sleep(0.01)
    # 设置控制模式为 CSP
    s = set_control_mode(bus, motor_id, mode='csp', if_disable_motor=False, timeout=timeout, verbose=verbose, log=log)
    state |= s
    time.sleep(0.005)
    # 设置速度限制
    s = csp_set_speed_limits(bus, motor_id,
                             speed_limit=speed_limit,
                             current_limit=current_limit,
                             component_type=component_type,
                             side=side,
                             motor_model=motor_model,
                             timeout=timeout, verbose=verbose,
                             wait_response=True, log=log)
    state |= s
    time.sleep(0.005)
    # 使能电机
    s = enable_motor(bus, motor_id, timeout=timeout, verbose=verbose, log=log)
    state |= s
    time.sleep(0.005)
    # 发送位置控制指令
    s = csp_motion_control(bus, motor_id, position,
                           component_type=component_type,
                           side=side,
                           motor_model=motor_model,
                           wait_response=True,
                           timeout=timeout, verbose=verbose, log=log)
    state |= s

    return 0 if state == 0 else 1
