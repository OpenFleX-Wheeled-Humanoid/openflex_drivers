#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   motor_config_loader.py
@Time    :   2025/12/16 11:34:14
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   加载电机配置
'''

import yaml
import os
import sys

# 导入异常类 - 需要处理相对导入路径
try:
    from ..exceptions import ConfigFileError, InvalidMotorIDError
except ImportError:
    # 如果作为脚本运行，添加父目录到路径
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, parent_dir)
    from exceptions import ConfigFileError, InvalidMotorIDError

class MotorConfigLoader:
    """电机配置加载器 - 支持双臂、头部、底盘的分组管理"""

    # 定义部件类型常量
    COMPONENT_ARM = 'arm'
    COMPONENT_HEAD = 'head'
    COMPONENT_CHASSIS = 'chassis'

    def __init__(self, config_file_path="motor_config.yaml", direction_config_file_path="direction_config.yaml"):
        """
        初始化配置加载器
        :param config_file_path: 电机参数配置文件路径
        :param direction_config_file_path: 方向系数配置文件路径
        """
        self.config_file_path = config_file_path
        self.direction_config_file_path = direction_config_file_path
        self.config = self._load_config()
        self.direction_config = self._load_direction_config()

        # 每个臂有8个电机，独立编号1-8
        self.motor_dict = {
            'arm': {
                'left': {
                    '1': 'RS04',  # 关节1
                    '2': 'RS04',  # 关节2
                    '3': 'RS03',  # 关节3
                    '4': 'RS03',  # 关节4
                    '5': 'RS00',  # 关节5
                    '6': 'RS00',  # 关节6
                    '7': 'RS00',  # 关节7
                    '8': 'RS00',  # 关节8
                },
                'right': {
                    '1': 'RS04',  # 关节1
                    '2': 'RS04',  # 关节2
                    '3': 'RS03',  # 关节3
                    '4': 'RS03',  # 关节4
                    '5': 'RS00',  # 关节5
                    '6': 'RS00',  # 关节6
                    '7': 'RS00',  # 关节7
                    '8': 'RS00',  # 关节8
                }
            },
            'head': {
                '1': 'RS00',  # 左右
                '2': 'RS00',  # 俯仰
            },
            'chassis': {
                '1': 'RS03',  # 前左转向
                '2': 'RS03',  # 前左驱动
                '3': 'RS03',  # 前右转向
                '4': 'RS03',  # 前右驱动
            }
        }


    def _load_config(self):
        """加载yaml配置文件"""
        # 获取当前脚本所在目录 (_lib/)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # 配置文件在上级目录的 config/ 子目录中
        parent_dir = os.path.dirname(current_dir)
        config_dir = os.path.join(parent_dir, 'config')
        full_path = os.path.join(config_dir, self.config_file_path)

        try:
            with open(full_path, 'r', encoding='utf-8') as file:
                config = yaml.safe_load(file)
                if config is None:
                    raise ConfigFileError(
                        full_path,
                        "配置文件为空或格式错误"
                    )
                return config
        except FileNotFoundError:
            raise ConfigFileError(
                full_path,
                f"配置文件未找到。请确保文件存在于: {config_dir}"
            )
        except yaml.YAMLError as e:
            raise ConfigFileError(
                full_path,
                f"YAML 解析错误: {str(e)}"
            )
        except Exception as e:
            raise ConfigFileError(
                full_path,
                f"加载配置文件时发生未知错误: {str(e)}"
            )

    def _load_direction_config(self):
        """
        加载方向系数配置文件

        如果文件不存在或解析失败，将使用默认配置而不抛出异常，
        因为方向配置是可选的。
        """
        # 获取当前脚本所在目录 (_lib/)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # 配置文件在上级目录的 config/ 子目录中
        parent_dir = os.path.dirname(current_dir)
        config_dir = os.path.join(parent_dir, 'config')
        full_path = os.path.join(config_dir, self.direction_config_file_path)

        try:
            with open(full_path, 'r', encoding='utf-8') as file:
                config = yaml.safe_load(file)
                if config is None:
                    print(f"警告: 方向配置文件 {full_path} 为空，将使用默认配置")
                    return self._get_default_direction_config()
                return config
        except FileNotFoundError:
            print(f"警告: 方向配置文件 {full_path} 未找到，将使用默认配置")
            return self._get_default_direction_config()
        except yaml.YAMLError as e:
            print(f"警告: 解析方向配置文件出错: {e}，将使用默认配置")
            return self._get_default_direction_config()
        except Exception as e:
            print(f"警告: 加载方向配置文件时发生错误: {e}，将使用默认配置")
            return self._get_default_direction_config()

    def _get_default_direction_config(self):
        """返回默认的方向配置"""
        return {
            'arm': {
                'left': {f'motor_{i}': -1.0 for i in range(1, 9)},
                'right': {f'motor_{i}': 1.0 for i in range(1, 9)}
            },
            'head': {
                'motor_1': 1.0,  # pitch
                'motor_2': 1.0,  # yaw
            },
            'chassis': {
                f'motor_{i}': 1.0 for i in range(1, 9)
            }
        }

    def _parse_motor_id(self, motor_id, component_type=None, side=None):
        """
        解析电机ID，支持多种格式

        参数:
            motor_id: 电机ID，支持以下格式：
                - 整数或字符串数字：如 1, '1' (需要指定component_type，对于arm还需指定side)
                - 复合ID：如 'arm:left:1', 'head:2', 'chassis:3'
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'

        返回:
            tuple: (component_type, motor_id_str, side)
                - component_type: 部件类型
                - motor_id_str: 电机ID字符串
                - side: 对于arm返回'left'或'right'，其他返回None
        """
        motor_id_str = str(motor_id)

        # 检查是否为复合ID格式 (component:side:id 或 component:id)
        if ':' in motor_id_str:
            parts = motor_id_str.split(':')
            if len(parts) == 3:
                # 格式: arm:left:1
                component_type = parts[0]
                side = parts[1]
                motor_id_str = parts[2]
            elif len(parts) == 2:
                # 格式: head:1 或 chassis:1
                component_type = parts[0]
                motor_id_str = parts[1]
                # side保持为None或使用传入的值
            else:
                raise ValueError(f"无效的复合ID格式: {motor_id}")

        # 如果没有指定component_type，抛出错误
        if component_type is None:
            raise ValueError(
                f"无法确定电机 {motor_id} 的部件类型。"
                f"请使用复合ID格式 (如 'arm:left:1', 'head:1') 或指定 component_type 参数"
            )

        # 验证component_type
        if component_type not in self.motor_dict:
            raise ValueError(
                f"无效的部件类型: {component_type}。"
                f"支持的类型: {list(self.motor_dict.keys())}"
            )

        # 对于arm，必须有side
        if component_type == 'arm':
            if side is None:
                raise ValueError(
                    f"对于arm部件，必须指定side参数 ('left' 或 'right')。"
                    f"请使用复合ID格式 (如 'arm:left:1') 或指定 side 参数"
                )
            if side not in ['left', 'right']:
                raise ValueError(f"无效的side参数: {side}。必须是 'left' 或 'right'")
        else:
            side = None

        return component_type, motor_id_str, side

    def get_motor_config(self, motor_id=None, component_type=None, side=None, motor_model=None):
        """
        获取指定电机ID的配置

        参数:
            motor_id: 电机ID，支持以下格式：
                - 简单数字：1-8 (需要指定component_type，对于arm还需指定side)
                - 复合ID：'arm:left:1', 'arm:right:1', 'head:2', 'chassis:3'
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'
            motor_model: 电机型号 (如 'RS04', 'RS03', 'RS00', 'RS06')
                        当提供此参数时，直接通过型号获取配置，忽略其他参数

        返回:
            dict: 电机配置字典

        抛出:
            InvalidMotorIDError: 如果电机ID不在支持的范围内
            ConfigFileError: 如果配置加载失败
        """
        if self.config is None:
            raise ConfigFileError(
                self.config_file_path,
                "电机配置未加载或加载失败"
            )

        # 如果提供了motor_model，直接通过型号获取配置
        if motor_model is not None:
            motor_config = self.config.get('motors', {}).get(motor_model)
            if motor_config is None:
                motor_config = self.config.get('default')
                if motor_config is None:
                    raise ConfigFileError(
                        self.config_file_path,
                        f"未找到电机型号 {motor_model} 的配置，且默认配置也不存在"
                    )
                print(f"警告: 电机型号 {motor_model} 未找到配置，使用默认配置")
            return motor_config

        # 如果没有提供motor_model，按原有逻辑处理
        if motor_id is None:
            raise ValueError("必须提供 motor_id 或 motor_model 参数")

        # 解析电机ID
        component_type, motor_id_str, side = self._parse_motor_id(motor_id, component_type, side)

        # 获取motor_type
        if component_type == 'arm':
            motor_type = self.motor_dict['arm'][side].get(motor_id_str)
        else:
            motor_type = self.motor_dict[component_type].get(motor_id_str)

        if motor_type is None:
            # 特殊处理：ID 127 (广播地址)
            if motor_id_str == '127':
                motor_type = self.config.get('default')
            else:
                raise InvalidMotorIDError(
                    motor_id,
                    valid_range=f"{component_type} 部件的有效ID"
                )

        # 根据motor_type获取配置
        motor_config = self.config.get('motors', {}).get(motor_type)

        # 如果没有找到对应motor_type的配置，使用默认配置
        if motor_config is None:
            motor_config = self.config.get('default')
            if motor_config is None:
                raise ConfigFileError(
                    self.config_file_path,
                    f"未找到电机类型 {motor_type} 的配置，且默认配置也不存在"
                )
            print(f"警告: 电机类型 {motor_type} 未找到配置，使用默认配置")

        return motor_config

    def get_position_limits(self, motor_id=None, component_type=None, side=None, motor_model=None):
        """
        获取位置限制

        参数:
            motor_id: 电机ID
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'
            motor_model: 电机型号 (如 'RS04')，提供此参数时直接通过型号获取

        返回:
            tuple: (min, max) 位置限制 (弧度)

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            ConfigFileError: 如果配置文件缺失必要字段
        """
        config = self.get_motor_config(motor_id, component_type, side, motor_model)
        try:
            return config['position']['min'], config['position']['max']
        except KeyError as e:
            raise ConfigFileError(
                self.config_file_path,
                f"电机配置缺少位置限制字段: {e}"
            )

    def get_torque_limits(self, motor_id=None, component_type=None, side=None, motor_model=None):
        """
        获取扭矩限制

        参数:
            motor_id: 电机ID
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'
            motor_model: 电机型号 (如 'RS04')，提供此参数时直接通过型号获取

        返回:
            tuple: (min, max) 扭矩限制 (牛米)

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            ConfigFileError: 如果配置文件缺失必要字段
        """
        config = self.get_motor_config(motor_id, component_type, side, motor_model)
        try:
            return config['torque']['min'], config['torque']['max']
        except KeyError as e:
            raise ConfigFileError(
                self.config_file_path,
                f"电机配置缺少扭矩限制字段: {e}"
            )

    def get_velocity_limits(self, motor_id=None, component_type=None, side=None, motor_model=None):
        """
        获取速度限制

        参数:
            motor_id: 电机ID
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'
            motor_model: 电机型号 (如 'RS04')，提供此参数时直接通过型号获取

        返回:
            tuple: (min, max) 速度限制 (弧度/秒)

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            ConfigFileError: 如果配置文件缺失必要字段
        """
        config = self.get_motor_config(motor_id, component_type, side, motor_model)
        try:
            return config['velocity']['min'], config['velocity']['max']
        except KeyError as e:
            raise ConfigFileError(
                self.config_file_path,
                f"电机配置缺少速度限制字段: {e}"
            )

    def get_kp_limits(self, motor_id=None, component_type=None, side=None, motor_model=None):
        """
        获取KP限制

        参数:
            motor_id: 电机ID
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'
            motor_model: 电机型号 (如 'RS04')，提供此参数时直接通过型号获取

        返回:
            tuple: (min, max) KP增益限制

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            ConfigFileError: 如果配置文件缺失必要字段
        """
        config = self.get_motor_config(motor_id, component_type, side, motor_model)
        try:
            return config['kp']['min'], config['kp']['max']
        except KeyError as e:
            raise ConfigFileError(
                self.config_file_path,
                f"电机配置缺少KP限制字段: {e}"
            )

    def get_kd_limits(self, motor_id=None, component_type=None, side=None, motor_model=None):
        """
        获取KD限制

        参数:
            motor_id: 电机ID
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'
            motor_model: 电机型号 (如 'RS04')，提供此参数时直接通过型号获取

        返回:
            tuple: (min, max) KD增益限制

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            ConfigFileError: 如果配置文件缺失必要字段
        """
        config = self.get_motor_config(motor_id, component_type, side, motor_model)
        try:
            return config['kd']['min'], config['kd']['max']
        except KeyError as e:
            raise ConfigFileError(
                self.config_file_path,
                f"电机配置缺少KD限制字段: {e}"
            )

    def get_all_limits(self, motor_id=None, component_type=None, side=None, motor_model=None):
        """
        获取所有限制参数，返回字典格式

        参数:
            motor_id: 电机ID
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'
            motor_model: 电机型号 (如 'RS04')，提供此参数时直接通过型号获取

        返回:
            dict: 包含所有限制参数的字典

        抛出:
            InvalidMotorIDError: 如果电机ID无效
            ConfigFileError: 如果配置文件缺失必要字段
        """
        config = self.get_motor_config(motor_id, component_type, side, motor_model)
        try:
            return {
                'P_MIN': config['position']['min'],
                'P_MAX': config['position']['max'],
                'T_MIN': config['torque']['min'],
                'T_MAX': config['torque']['max'],
                'V_MIN': config['velocity']['min'],
                'V_MAX': config['velocity']['max'],
                'KP_MIN': config['kp']['min'],
                'KP_MAX': config['kp']['max'],
                'KD_MIN': config['kd']['min'],
                'KD_MAX': config['kd']['max'],
            }
        except KeyError as e:
            raise ConfigFileError(
                self.config_file_path,
                f"电机配置缺少必要字段: {e}"
            )

    def get_direction_multipliers(self, component_type, side=None, motor_ids=None):
        """
        获取指定部件的电机方向系数

        参数:
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，指定 'left' 或 'right'；其他部件忽略此参数
            motor_ids: 电机ID列表，默认为该部件的所有电机

        返回:
            dict: {motor_id: multiplier} 字典，如 {1: -1.0, 2: -1.0, ...}
        """
        # 设置默认motor_ids
        if motor_ids is None:
            if component_type == 'arm':
                motor_ids = list(range(1, 9))  # 每个臂8个电机
            elif component_type == 'head':
                motor_ids = [1, 2]
            elif component_type == 'chassis':
                motor_ids = list(range(1, 9))
            else:
                motor_ids = []

        if self.direction_config is None:
            # 如果配置文件加载失败，返回默认值
            return self._get_default_multipliers(component_type, side, motor_ids)

        # 从配置文件获取方向系数
        if component_type == 'arm':
            if side is None:
                raise ValueError("对于arm部件，必须指定side参数 ('left' 或 'right')")
            component_config = self.direction_config.get('arm', {}).get(side, {})
        else:
            component_config = self.direction_config.get(component_type, {})

        if not component_config:
            print(f"警告: 方向配置中未找到 '{component_type}:{side}'，使用默认配置")
            return self._get_default_multipliers(component_type, side, motor_ids)

        # 构建方向系数字典
        multipliers = {}
        for motor_id in motor_ids:
            key = f'motor_{motor_id}'
            multipliers[motor_id] = component_config.get(key, 1.0)

        return multipliers

    def _get_default_multipliers(self, component_type, side, motor_ids):
        """获取默认的方向系数"""
        multipliers = {}
        for motor_id in motor_ids:
            if component_type == 'arm' and side == 'left':
                multipliers[motor_id] = -1.0
            else:
                multipliers[motor_id] = 1.0
        return multipliers

    def get_component_motor_ids(self, component_type, side=None):
        """
        获取指定部件的所有电机ID

        参数:
            component_type: 部件类型 ('arm', 'head', 'chassis')
            side: 对于arm，可指定 'left' 或 'right'

        返回:
            list: 电机ID列表
        """
        if component_type == 'arm':
            if side == 'left':
                return list(self.motor_dict['arm']['left'].keys())
            elif side == 'right':
                return list(self.motor_dict['arm']['right'].keys())
            else:
                left_ids = list(self.motor_dict['arm']['left'].keys())
                right_ids = list(self.motor_dict['arm']['right'].keys())
                return left_ids + right_ids
        elif component_type in self.motor_dict:
            return list(self.motor_dict[component_type].keys())
        else:
            return []

    def get_chassis_wheel_motors(self, wheel_position):
        """
        获取底盘指定轮子的电机ID

        参数:
            wheel_position: 轮子位置 ('front_left', 'front_right', 'rear_left', 'rear_right')

        返回:
            dict: {'steering': motor_id, 'drive': motor_id}
        """
        wheel_map = {
            'front_left': {'steering': '1', 'drive': '2'},
            'front_right': {'steering': '3', 'drive': '4'},
            'rear_left': {'steering': '5', 'drive': '6'},
            'rear_right': {'steering': '7', 'drive': '8'},
        }
        return wheel_map.get(wheel_position, {})