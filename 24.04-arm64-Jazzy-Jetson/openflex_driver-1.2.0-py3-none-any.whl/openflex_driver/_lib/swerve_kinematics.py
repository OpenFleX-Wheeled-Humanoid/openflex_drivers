#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四转四驱舵轮逆运动学（对齐 swerve_controller/swerve_drive_kinematics.cpp）
"""

import math
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class ChassisSpeeds:
    vx: float = 0.0      # 前进 m/s（机器人坐标系 x）
    vy: float = 0.0      # 左移 m/s（y 向左为正）
    omega: float = 0.0   # 逆时针角速度 rad/s


@dataclass
class SwerveModuleState:
    speed: float = 0.0   # 轮缘线速度 m/s
    angle: float = 0.0   # 转向角 rad


@dataclass
class ModulePosition:
    x: float = 0.0
    y: float = 0.0


def normalize_angle(angle: float) -> float:
    return math.atan2(math.sin(angle), math.cos(angle))


class SwerveDriveKinematics:
    """四舵轮底盘运动学：vx/vy/omega → 各模块轮速与转向角。"""

    NUM_MODULES = 4

    def __init__(
        self,
        positions: List[ModulePosition],
        steering_min: List[float],
        steering_max: List[float],
    ):
        if len(positions) != self.NUM_MODULES:
            raise ValueError("positions 长度须为 4")
        self.positions = positions
        self.steering_min = steering_min
        self.steering_max = steering_max
        self._ik_matrix = self._build_ik_matrix(positions)

    @staticmethod
    def _build_ik_matrix(positions: List[ModulePosition]) -> List[List[float]]:
        """8×3 逆运动学矩阵（行优先展开为 list of rows）。"""
        matrix = []
        for pos in positions:
            matrix.append([1.0, 0.0, -pos.y])
            matrix.append([0.0, 1.0, pos.x])
        return matrix

    def to_module_states(
        self,
        speeds: ChassisSpeeds,
        current_angles: List[float],
    ) -> List[SwerveModuleState]:
        chassis = [speeds.vx, speeds.vy, speeds.omega]
        states: List[SwerveModuleState] = []

        for i in range(self.NUM_MODULES):
            vx_i = 0.0
            vy_i = 0.0
            for j in range(3):
                vx_i += self._ik_matrix[i * 2][j] * chassis[j]
                vy_i += self._ik_matrix[i * 2 + 1][j] * chassis[j]

            speed = math.hypot(vx_i, vy_i)
            if speed < 1e-4:
                states.append(SwerveModuleState(speed=0.0, angle=current_angles[i]))
            else:
                angle = math.atan2(vy_i, vx_i)
                desired = SwerveModuleState(speed=speed, angle=angle)
                states.append(
                    self._optimize(
                        desired,
                        current_angles[i],
                        self.steering_min[i],
                        self.steering_max[i],
                    )
                )
        return states

    @staticmethod
    def desaturate_wheel_speeds(states: List[SwerveModuleState], max_speed: float):
        highest = max((abs(s.speed) for s in states), default=0.0)
        if highest > max_speed > 0.0:
            scale = max_speed / highest
            for st in states:
                st.speed *= scale

    def _optimize(
        self,
        desired: SwerveModuleState,
        current_angle: float,
        min_angle: float,
        max_angle: float,
    ) -> SwerveModuleState:
        fwd_delta = normalize_angle(desired.angle - current_angle)
        fwd_angle = current_angle + fwd_delta
        fwd_speed = desired.speed

        rev_target = normalize_angle(desired.angle + math.pi)
        rev_delta = normalize_angle(rev_target - current_angle)
        rev_angle = current_angle + rev_delta
        rev_speed = -desired.speed

        fwd_clamped = max(min_angle, min(max_angle, fwd_angle))
        fwd_error = abs(fwd_angle - fwd_clamped)

        rev_clamped = max(min_angle, min(max_angle, rev_angle))
        rev_error = abs(rev_angle - rev_clamped)

        fwd_cost = abs(fwd_delta) + fwd_error * 2.0
        rev_cost = abs(rev_delta) + rev_error * 2.0

        if fwd_cost <= rev_cost:
            return SwerveModuleState(speed=fwd_speed, angle=fwd_clamped)
        return SwerveModuleState(speed=rev_speed, angle=rev_clamped)


def default_module_positions(wheelbase: float, track_width: float) -> List[ModulePosition]:
    """FL, FR, BL, BR — 与 swerve.urdf.xacro 一致（x 前 y 左）。"""
    hx = wheelbase / 2.0
    hy = track_width / 2.0
    return [
        ModulePosition(hx, hy),
        ModulePosition(hx, -hy),
        ModulePosition(-hx, hy),
        ModulePosition(-hx, -hy),
    ]
