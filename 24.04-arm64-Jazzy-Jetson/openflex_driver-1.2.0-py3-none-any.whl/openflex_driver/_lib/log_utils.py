#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   log_utils.py
@Time    :   2025/12/10
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   统一日志输出工具
             提供标准化的日志输出接口，支持多种日志级别
'''


#**************************************************************************
# 日志级别定义
#**************************************************************************

# 标准日志级别，与GUI的log函数保持一致
LOG_LEVEL_INFO = "INFO"        # 普通信息 (黑色)
LOG_LEVEL_SUCCESS = "SUCCESS"  # 成功消息 (绿色)
LOG_LEVEL_WARNING = "WARNING"  # 警告消息 (橙色)
LOG_LEVEL_ERROR = "ERROR"      # 错误消息 (红色)


#**************************************************************************
# 日志输出函数
#**************************************************************************

def log_output(message, level="INFO", log=None):
    """
    统一的日志输出函数

    参数:
        message (str): 要输出的消息
        level (str): 日志级别 ("INFO", "SUCCESS", "WARNING", "ERROR")
        log (callable): 日志函数，如果为None则使用print

    说明:
        - 如果提供了log函数，会调用 log(message, level)
        - 如果log函数不支持level参数，会fallback到只传message
        - 如果没有提供log函数，使用print输出，带level前缀

    日志级别说明:
        - INFO: 普通信息，用于一般性说明、状态输出
        - SUCCESS: 成功消息，用于操作成功、完成等正面结果
        - WARNING: 警告消息，用于非致命性问题、注意事项
        - ERROR: 错误消息，用于失败、异常、严重问题

    示例:
        >>> from lib.log_utils import log_output
        >>>
        >>> # 在脚本中使用（使用print）
        >>> log_output("CAN接口检测完成", "INFO")
        >>> log_output("✓ 启用成功!", "SUCCESS")
        >>> log_output("⚠ 部分电机无响应", "WARNING")
        >>> log_output("✗ 通信失败", "ERROR")
        >>>
        >>> # 在GUI中使用（传入self.log）
        >>> log_output("开始初始化", "INFO", log=self.log)
        >>> log_output("初始化完成", "SUCCESS", log=self.log)
    """
    if log is not None:
        # 尝试调用log函数，传递level参数
        try:
            log(message, level)
        except TypeError:
            # 如果log函数不接受level参数，只传message
            log(message)
    else:
        # 使用print输出，添加level前缀（除了INFO）
        if level in [LOG_LEVEL_SUCCESS, LOG_LEVEL_WARNING, LOG_LEVEL_ERROR]:
            print(f"[{level}] {message}")
        else:
            print(message)


#**************************************************************************
# 便捷日志函数（可选）
#**************************************************************************

def log_info(message, log=None):
    """输出INFO级别日志"""
    log_output(message, LOG_LEVEL_INFO, log)


def log_success(message, log=None):
    """输出SUCCESS级别日志"""
    log_output(message, LOG_LEVEL_SUCCESS, log)


def log_warning(message, log=None):
    """输出WARNING级别日志"""
    log_output(message, LOG_LEVEL_WARNING, log)


def log_error(message, log=None):
    """输出ERROR级别日志"""
    log_output(message, LOG_LEVEL_ERROR, log)
