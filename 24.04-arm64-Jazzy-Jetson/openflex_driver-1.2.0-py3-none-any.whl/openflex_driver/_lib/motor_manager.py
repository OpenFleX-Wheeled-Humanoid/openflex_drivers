#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   motor_manager.py
@Time    :   2025/12/11
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   电机配置和管理接口
             提供电机使能、模式设置、零点设置、状态查询等管理功能
'''

import can
import time
import struct
from .motor_config_loader import MotorConfigLoader

# 从底层通信模块导入基础函数
from .can_comm import (
    float_to_uint16,
    uint16_to_float,
    send_extended_frame_main
)

# 从日志工具导入统一日志函数
from .log_utils import log_output

# 导入异常类
try:
    from ..exceptions import (
        CANTimeoutError,
        CANTransmissionError,
        InvalidMotorIDError,
        InvalidModeError,
        InvalidParameterError,
        ConfigFileError,
        MotorFaultError
    )
except ImportError:
    import sys
    import os
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, parent_dir)
    from exceptions import (
        CANTimeoutError,
        CANTransmissionError,
        InvalidMotorIDError,
        InvalidModeError,
        InvalidParameterError,
        ConfigFileError,
        MotorFaultError
    )

motor_conf = MotorConfigLoader()


# ====================== 状态查询和解析函数 ======================

def parse_motor_feedback(rx_data, motorID, component_type=None, side=None, motor_model=None):
    """
    解析电机反馈数据

    参数:
        rx_data (list): 接收到的8字节数据
        motorID (int): 电机ID
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置

    返回:
        dict: 包含angle, velocity, torque, temperature的字典
              如果数据无效则返回None
    """
    if len(rx_data) < 8:
        return None
    # 解析当前角度 (Byte0~1)
    angle_raw = (rx_data[0] << 8) | rx_data[1]
    P_MIN, P_MAX = motor_conf.get_position_limits(motorID, component_type, side, motor_model)
    current_angle = uint16_to_float(angle_raw, P_MIN, P_MAX)

    # 解析当前角速度 (Byte2~3)
    velocity_raw = (rx_data[2] << 8) | rx_data[3]
    V_MIN, V_MAX = motor_conf.get_velocity_limits(motorID, component_type, side, motor_model)
    current_velocity = uint16_to_float(velocity_raw, V_MIN, V_MAX)

    # 解析当前力矩 (Byte4~5)
    torque_raw = (rx_data[4] << 8) | rx_data[5]
    T_MIN, T_MAX = motor_conf.get_torque_limits(motorID, component_type, side, motor_model)
    current_torque = uint16_to_float(torque_raw, T_MIN, T_MAX)

    # 解析当前温度 (Byte6~7)
    temp_raw = (rx_data[6] << 8) | rx_data[7]
    current_temp = temp_raw / 10.0  # 温度×10

    return {
        'angle': current_angle,
        'velocity': current_velocity,
        'torque': current_torque,
        'temperature': current_temp
    }


def parse_control_mode_and_status(arbitration_id, rx_data):
    """
    解析控制模式和使能状态信息

    根据电机说明书通信类型2的返回格式解析

    参数:
        arbitration_id (int): 扩展帧仲裁ID
        rx_data (list): 接收到的8字节数据

    返回:
        dict: 包含mode_status, fault_status, fault_code的字典
              如果数据无效则返回None
    """
    if len(rx_data) < 8:
        return None

    # 从仲裁号中提取信息 (bit21~16:故障信息, bit22~23:模式状态)
    fault_info = (arbitration_id >> 16) & 0x3F  # bit21~16: 故障信息
    mode_status = (arbitration_id >> 22) & 0x03  # bit22~23: 模式状态

    # 模式状态解析
    mode_status_desc = {
        0: "Reset mode",
        1: "Cali mode",
        2: "Motor mode",
        3: "Unknown mode"
    }.get(mode_status, f"Unknown mode({mode_status})")

    # 故障信息解析
    fault_flags = []
    if fault_info & (1 << 5):  # bit21
        fault_flags.append("Not calibrated")
    if fault_info & (1 << 4):  # bit20
        fault_flags.append("Stall overload")
    if fault_info & (1 << 3):  # bit19
        fault_flags.append("Encoder fault")
    if fault_info & (1 << 2):  # bit18
        fault_flags.append("Overtemp")
    if fault_info & (1 << 1):  # bit17
        fault_flags.append("Driver fault")
    if fault_info & (1 << 0):  # bit16
        fault_flags.append("Undervoltage")

    fault_status = "Normal" if not fault_flags else ", ".join(fault_flags)

    return {
        'mode_status': mode_status_desc,
        'fault_status': fault_status,
        'fault_code': fault_info
    }


def get_motor_status_readonly(bus, motor_id, component_type=None, side=None, motor_model=None, timeout=1.0, verbose=False, log=None):
    """
    只读查询电机状态（不改变电机控制状态）

    按 RS03 手册与本仓库协议，使用通信类型 0x0200 (MOTOR_REQUEST) 请求电机上报当前状态。
    - 不发送任何位置/速度/增益等控制参数，不会改变电机当前控制模式或控制量。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID
        component_type (str): 部件类型 ('arm', 'head', 'chassis')，可选
        side (str): 对于arm，指定 'left' 或 'right'，可选
        motor_model (str): 电机型号 (如 'RS04')，提供此参数时直接通过型号获取配置
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        tuple: (state, info)
            - state: 0=成功
            - info: dict 或 None，包含以下字段（成功时）：
                angle, velocity, torque, temperature
                mode_status, fault_status, fault_code
                raw: {rx_data, rx_id}

    异常:
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 等待响应超时
        InvalidMotorIDError: 电机ID无效 (从配置加载器抛出)

    示例:
        state, info = get_motor_status_readonly(bus, 5, verbose=True)
        if state == 0:
            print(info)

        # 测试时通过型号获取
        state, info = get_motor_status_readonly(bus, 5, motor_model='RS04', verbose=True)
    """
    # 功能码 0x0200: 电机状态请求
    arbitration_id = 0x0200fd00 + motor_id
    data = [0] * 8
    data[0] = 0x01  # 请求帧 data[0]=0x01

    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=1,
        timeout=timeout,
        verbose=verbose
    )

    if state != 0:
        if verbose:
            log_output(f"电机ID {motor_id}: 状态请求失败/超时", "ERROR", log)
        return state, None
    # 解析反馈
    feedback = parse_motor_feedback(rx_data, motor_id, component_type, side, motor_model) or {}
    mode_info = parse_control_mode_and_status(rx_arbitration_id, rx_data) or {}

    info = {}
    info.update(feedback)
    info.update(mode_info)
    info['raw'] = {
        'rx_data': rx_data,
        'rx_id': rx_arbitration_id
    }

    if verbose:
        log_output(f"电机ID {motor_id} 状态: {info}", "INFO", log)

    return 0, info


# ====================== 电机使能/停止函数 ======================

def enable_motor(bus, motor_id, timeout=1.0, verbose=False, log=None):
    """
    使能电机

    发送使能命令到指定电机，启动电机。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID (1-8)
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功

    异常:
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 等待响应超时
        InvalidMotorIDError: 电机ID无效 (从配置加载器抛出)

    示例:
        # 使能单个电机
        state = enable_motor(bus, motor_id=5)
        if state == 0:
            print("电机使能成功")

        # 使能多个电机
        for motor_id in range(1, 9):
            enable_motor(bus, motor_id)
    """
    # 功能码 0x0300
    # 仲裁ID: 0x0300fd00 + motorID
    arbitration_id = 0x0300fd00 + motor_id
    data = [0] * 8

    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=1,
        timeout=timeout,
        verbose=verbose
    )

    if verbose and state == 0:
        if state == 0:
            log_output(f"电机ID {motor_id}: 使能成功", "SUCCESS", log)
        else:
            log_output(f"电机ID {motor_id}: 使能失败", "ERROR", log)

    return state


def disable_motor(bus, motor_id, timeout=1.0, verbose=False, log=None):
    """
    停止电机

    发送停止命令到指定电机。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID (1-8)
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功

    异常:
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 等待响应超时

    示例:
        # 停止单个电机
        state = disable_motor(bus, motor_id=5)

        # 停止所有电机
        for motor_id in range(1, 9):
            disable_motor(bus, motor_id)
    """
    # 功能码 0x0400
    # 仲裁ID: 0x0400fd00 + motorID
    arbitration_id = 0x0400fd00 + motor_id
    data = [0] * 8  # 全0数据

    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=1,
        timeout=timeout,
        verbose=verbose
    )

    if verbose and state == 0:
        if state == 0:
            log_output(f"电机ID {motor_id}: 停止成功", "SUCCESS", log)
        else:
            log_output(f"电机ID {motor_id}: 停止失败", "ERROR", log)

    return state


def enable_all_motors(bus, motor_ids=None, verbose=False, log=None):
    """
    批量使能电机

    参数:
        bus (can.Bus): CAN总线对象
        motor_ids (list): 电机ID列表，默认 None (使能ID 1-8 所有电机)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        dict: {motor_id: state} 每个电机的状态

    示例:
        # 使能所有电机 (ID 1-8)
        results = enable_all_motors(bus)

        # 使能指定电机
        results = enable_all_motors(bus, motor_ids=[1, 2, 5, 6])

        # 检查结果
        for motor_id, state in results.items():
            if state == 0:
                print(f"电机 {motor_id}: OK")
            else:
                print(f"电机 {motor_id}: 失败")
    """
    if motor_ids is None:
        motor_ids = list(range(1, 9))  # 默认 1-8

    results = {}
    for motor_id in motor_ids:
        state = enable_motor(bus, motor_id, verbose=verbose, log=log)
        results[motor_id] = state
        time.sleep(0.01)  # 短暂延迟避免总线拥塞

    return results


def disable_all_motors(bus, motor_ids=None, verbose=False, log=None):
    """
    批量停止电机

    参数:
        bus (can.Bus): CAN总线对象
        motor_ids (list): 电机ID列表，默认 None (停止ID 1-8 所有电机)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        dict: {motor_id: state} 每个电机的状态

    示例:
        # 停止所有电机
        results = disable_all_motors(bus)

        # 紧急停止指定电机
        results = disable_all_motors(bus, motor_ids=[1, 2, 3])
    """
    if motor_ids is None:
        motor_ids = list(range(1, 9))

    results = {}
    for motor_id in motor_ids:
        state = disable_motor(bus, motor_id, verbose=verbose, log=log)
        results[motor_id] = state
        time.sleep(0.01)

    return results


# ====================== 模式设置函数 ======================

def _write_motor_parameter(bus, motor_id, param_index, value, *, value_type='float',
                           timeout=0.2, verbose=False, wait_response=True, log=None):
    """
    写单个参数的通用函数 (通信类型 0x1200)

    参数:
        bus (can.Bus): CAN 总线
        motor_id (int): 电机ID
        param_index (int): 参数索引 (如 0x7016/0x7017/0x7018)
        value: 写入的数值
        value_type (str): 'float' 或 'u8'
        timeout (float): 超时
        verbose (bool): 调试输出
        wait_response (bool): 是否等待电机回包
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        (state, rx_data, rx_arbitration_id)
    """
    arbitration_id = 0x1200fd00 + motor_id
    data = [0] * 8

    # 索引采用现有实现习惯：低字节在 data[0]，高字节在 data[1]
    data[0] = param_index & 0xFF
    data[1] = (param_index >> 8) & 0xFF

    if value_type == 'float':
        # 按小端写入到 data[4:8]，与 read_motor_parameter 的解析相匹配
        b = struct.pack('<f', float(value))
        data[4] = b[0]
        data[5] = b[1]
        data[6] = b[2]
        data[7] = b[3]
    elif value_type == 'u8':
        data[4] = int(value) & 0xFF
    else:
        raise ValueError("Unsupported value_type, use 'float' or 'u8'")

    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=1 if wait_response else 0,
        timeout=timeout,
        verbose=verbose
    )

    if verbose:
        if state == 0:
            log_output(f"电机ID {motor_id}: 写参数 0x{param_index:04X} = {value} 成功", "SUCCESS", log)
        else:
            log_output(f"电机ID {motor_id}: 写参数 0x{param_index:04X} 失败", "ERROR", log)

    return state, rx_data, rx_arbitration_id


def set_control_mode(bus, motor_id, mode='mit', *, timeout=1.0, verbose=False, log=None):
    """
    设置电机控制模式 (RUN_MODE = 0x7005)

    根据RS03手册要求：在关节运行时不可切换控制方式，如需切换需要发送停止运行命令后再做切换。
    因此默认会先失能电机再切换模式（if_disable_motor=True）。

    控制模式映射：
        0 / 'mit': 运控模式 (MIT)
        1 / 'pp': 位置模式 (PP)
        2 / 'speed': 速度模式
        3 / 'current': 电流模式
        5 / 'csp': 位置模式 (CSP)

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID (1-8)
        mode (str|int): 控制模式，可选值:
            - 'mit' / 0: 运控模式 (MIT模式)
            - 'pp' / 1: 位置模式 (PP)
            - 'speed' / 2: 速度模式
            - 'current' / 3: 电流模式
            - 'csp' / 5: 位置模式 (CSP)
        if_disable_motor (bool): 切换前是否自动disable电机（默认 True，符合手册要求）
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 非0=失败

    异常:
        InvalidModeError: 无效的控制模式
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 等待响应超时

    示例:
        # 设置为MIT运控模式（推荐，自动失能电机）
        set_control_mode(bus, motor_id=5, mode='mit')

        # 设置为CSP位置模式
        set_control_mode(bus, motor_id=5, mode='csp')

        # 不自动disable电机（不推荐，违反手册要求）
        set_control_mode(bus, motor_id=5, mode='pp', if_disable_motor=False)
    """
    # 模式名称映射
    MODE_MAP = {
        # 字符串命名
        "mit": 0,
        "pp": 1,
        "speed": 2,
        "current": 3,
        "csp": 5,
        # 数字形式
        0: 0,
        1: 1,
        2: 2,
        3: 3,
        5: 5
    }

    # 检查模式有效性
    if mode not in MODE_MAP:
        valid_modes = ['mit', 'pp', 'speed', 'current', 'csp']
        raise InvalidModeError(mode, valid_modes)

    # 失能电机（符合手册要求）
    disable_motor(bus, motor_id, timeout=timeout, verbose=verbose, log=log)
    time.sleep(0.1)

    # 写入RUN_MODE参数（0x7005）
    return _write_motor_parameter(
        bus, motor_id, 0x7005, MODE_MAP[mode],
        value_type='u8', timeout=timeout,
        verbose=verbose, wait_response=True, log=log
    )[0]

# ====================== 参数读取函数 ======================

def read_motor_parameter(bus, motor_id, param_index, timeout=1.0, verbose=False, log=None):
    """
    读取电机单个参数值

    使用通信类型17读取电机内部参数。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID (1-8)
        param_index (int): 参数索引，常用值:
            - 0x7019: mechPos (负载端计圈机械角度, float)
            - 0x7029: zero_sta (零点标志位, uint8)
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        tuple: (state, param_value)
            - state (int): 状态码 0=成功, 1=失败
            - param_value: 参数值 (类型取决于参数, 失败时为None)

    示例:
        # 读取机械角度
        state, mech_pos = read_motor_parameter(bus, motor_id=5, param_index=0x7019)
        if state == 0:
            print(f"机械角度: {mech_pos} rad")

        # 读取zero_sta参数
        state, zero_sta = read_motor_parameter(bus, motor_id=5, param_index=0x7029)
        if state == 0:
            print(f"zero_sta: {zero_sta}")
    """
    # 仲裁帧ID - 通信类型17
    arbitration_id = 0x1100fd00 + motor_id
    data = [0] * 8

    # 设置参数索引
    data[0] = param_index & 0xFF        # 低字节
    data[1] = (param_index >> 8) & 0xFF # 高字节
    data[2] = 0x00
    data[3] = 0x00
    data[4] = 0x00
    data[5] = 0x00
    data[6] = 0x00
    data[7] = 0x00

    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=1,
        timeout=timeout,
        verbose=verbose
    )

    if state == 0:
        # 解析返回的参数值 (Byte4-7包含参数数据)
        if param_index == 0x7029:  # zero_sta 是 uint8 类型
            param_value = rx_data[4]
        elif param_index == 0x7019:  # mechPos 是 float 类型 (大端序)
            param_bytes = bytes([rx_data[7], rx_data[6], rx_data[5], rx_data[4]])
            param_value = struct.unpack('>f', param_bytes)[0]
        else:
            # 默认按uint8处理
            param_value = rx_data[4]

        if verbose:
            log_output(f"电机ID {motor_id}: 读取参数 0x{param_index:04X} = {param_value}", "SUCCESS", log)
    else:
        param_value = None
        if verbose:
            log_output(f"电机ID {motor_id}: 读取参数 0x{param_index:04X} 失败", "ERROR", log)

    return state, param_value


def get_motor_basic_telemetry(bus, motor_id, timeout=1.0, verbose=False, log=None):
    """
    只读方式逐项读取关键遥测（通过通信类型 0x1100 逐个参数读取）

    当设备不支持 0x0200 状态回传时，可使用该函数按参数索引读取：
      - 0x7019: 负载端计圈机械角度 (float, rad)
      - 0x701B: 负载端转速 (float, rad/s)
      - 0x701A: iq 滤波值 (float) – 可近似表征力矩/电流
      - 0x701C: 母线电压 (float, V)

    返回:
        tuple: (state, info)
            - state: 0=成功（至少读取成功一项），1=全部失败
            - info: dict，包含成功读取到的键
    """
    ok = 0
    info = {}

    # 角度
    s, val = read_motor_parameter(bus, motor_id, 0x7019, timeout=timeout, verbose=verbose, log=log)
    if s == 0 and val is not None:
        info['mech_pos'] = float(val)
        ok |= 1

    # 速度
    s, val = read_motor_parameter(bus, motor_id, 0x701B, timeout=timeout, verbose=verbose, log=log)
    if s == 0 and val is not None:
        info['mech_vel'] = float(val)
        ok |= 1

    # iq 滤波值（近似电流/力矩指标）
    s, val = read_motor_parameter(bus, motor_id, 0x701A, timeout=timeout, verbose=verbose, log=log)
    if s == 0 and val is not None:
        info['iqf'] = float(val)
        ok |= 1

    # 母线电压
    s, val = read_motor_parameter(bus, motor_id, 0x701C, timeout=timeout, verbose=verbose, log=log)
    if s == 0 and val is not None:
        info['vbus'] = float(val)
        ok |= 1

    if verbose:
        if ok:
            log_output(f"电机ID {motor_id} 基本遥测: {info}", "INFO", log)
        else:
            log_output(f"电机ID {motor_id} 基本遥测读取失败", "ERROR", log)

    return (0 if ok else 1), (info if ok else None)


# ====================== 零点设置函数 ======================

def set_motor_zero(bus, motor_id, component_type='arm', side='right', motor_model=None,timeout=1.0, verbose=False, log=None):
    """
    设置电机机械零点（带验证和重试机制）

    将当前电机位置设置为负载端零角度。此操作会将当前电机的机械位置标记为零点。
    设置后会自动验证零点是否设置成功，如果验证失败会自动重试，最多重试3次。

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID (1-8)
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 1=失败

    示例:
        # 设置单个电机的零点
        state = set_motor_zero(bus, motor_id=5, verbose=True)
        if state == 0:
            print("零点设置成功")

        # 设置所有电机的零点
        for motor_id in range(1, 9):
            set_motor_zero(bus, motor_id)
            time.sleep(0.01)
    """
    import time

    max_retries = 3  # 最多尝试3次
    zero_tolerance = 0.05  # 零点容差（弧度），约2.86度

    for attempt in range(max_retries):
        # 功能码 0x0600
        # 仲裁ID: 0x0600fd00 + motorID
        arbitration_id = 0x0600fd00 + motor_id
        data = [0] * 8
        data[0] = 0x01  # 第一个字节设置为0x01表示设置零点
        # 先失能电机
        disable_motor(bus, motor_id, timeout=timeout, verbose=verbose, log=log)
        time.sleep(0.1)
        # 发送设置零点命令
        state, rx_data, rx_arbitration_id = send_extended_frame_main(
            bus, arbitration_id, data,
            block_receive=1,
            timeout=timeout,
            verbose=verbose
        )
        # 如果发送失败（电机无响应），直接返回失败，不再重试
        if state != 0:
            if verbose:
                log_output(f"电机ID {motor_id}: 设置零点命令发送失败（电机无响应）", "ERROR", log)
            return 1

        # 等待电机处理零点设置
        time.sleep(0.2)
        # 验证零点是否设置成功：读取当前位置
        verify_state, verify_info = get_motor_status_readonly(
            bus, motor_id, component_type=component_type, side=side, motor_model=motor_model,
            timeout=timeout,
            verbose=False,  # 验证时不输出详细日志
            log=log
        )
        if verify_state == 0 and verify_info is not None:
            current_angle = verify_info.get('angle', None)
            if current_angle is not None:
                # 检查角度是否接近零点
                if abs(current_angle) <= zero_tolerance:
                    if verbose:
                        log_output(
                            f"电机ID {motor_id}: 设置零点成功并验证通过 "
                            f"(当前角度: {current_angle:.4f} rad, 尝试次数: {attempt + 1})",
                            "SUCCESS", log
                        )
                    return 0
                else:
                    # 角度不为零，需要重试
                    if verbose:
                        log_output(
                            f"电机ID {motor_id}: 零点验证失败 "
                            f"(当前角度: {current_angle:.4f} rad, 期望: ~0.0 rad), "
                            f"尝试 {attempt + 1}/{max_retries}",
                            "WARNING", log
                        )

                    # 如果还有重试机会，继续重试
                    if attempt < max_retries - 1:
                        time.sleep(0.2)  # 等待后重试
                        continue
            else:
                if verbose:
                    log_output(
                        f"电机ID {motor_id}: 无法读取角度信息进行验证, "
                        f"尝试 {attempt + 1}/{max_retries}",
                        "WARNING", log
                    )
                # 如果还有重试机会，继续重试
                if attempt < max_retries - 1:
                    time.sleep(0.2)
                    continue
        else:
            # 验证读取失败
            if verbose:
                log_output(
                    f"电机ID {motor_id}: 零点验证读取失败, "
                    f"尝试 {attempt + 1}/{max_retries}",
                    "WARNING", log
                )
            # 如果还有重试机会，继续重试
            if attempt < max_retries - 1:
                time.sleep(0.2)
                continue

    # 所有重试都失败
    if verbose:
        log_output(
            f"电机ID {motor_id}: 设置零点失败（已重试{max_retries}次）",
            "ERROR", log
        )
    return 1


def set_zero_sta_parameter(bus, motor_id, zero_sta, timeout=1.0, verbose=False, log=None):
    """
    设置零点标志位参数 (zero_sta)

    该参数控制电机角度表示范围:
    - zero_sta = 0: 角度范围为 0 到 2π
    - zero_sta = 1: 角度范围为 -π 到 π

    参数:
        bus (can.Bus): CAN总线对象
        motor_id (int): 电机ID (1-8)
        zero_sta (int): 零点标志位，0代表0~2π, 1代表-π~π
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 1=失败

    示例:
        # 设置为 -π~π 范围
        state = set_zero_sta_parameter(bus, motor_id=5, zero_sta=1, verbose=True)

        # 设置为 0~2π 范围
        state = set_zero_sta_parameter(bus, motor_id=5, zero_sta=0, verbose=True)
    """
    # 使用通信类型18写入单个参数
    # index: 0x7029 (zero_sta参数)

    # 仲裁帧ID - 通信类型18
    arbitration_id = 0x1200fd00 + motor_id
    data = [0] * 8

    # 设置index (0x7029)
    param_index = 0x7029
    data[0] = param_index & 0xFF        # 低字节
    data[1] = (param_index >> 8) & 0xFF # 高字节
    data[2] = 0x00
    data[3] = 0x00

    # 设置参数值 (zero_sta)
    data[4] = zero_sta & 0xFF
    data[5] = 0x00
    data[6] = 0x00
    data[7] = 0x00

    disable_motor(bus, motor_id, timeout=timeout, verbose=verbose, log=log)
    time.sleep(0.1)

    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=1,
        timeout=timeout,
        verbose=verbose
    )

    if verbose:
        if state == 0:
            zero_range = "-π~π" if zero_sta == 1 else "0~2π"
            log_output(f"电机ID {motor_id}: 设置zero_sta={zero_sta} ({zero_range}) 成功", "SUCCESS", log)
        else:
            log_output(f"电机ID {motor_id}: 设置zero_sta={zero_sta} 失败", "ERROR", log)

    return state


# ====================== CAN ID 设置函数 ======================

def set_motor_canid(bus, current_motor_id, new_motor_id, master_id=0xFD, timeout=1.0, verbose=False, log=None):
    """
    设置电机CAN ID

    使用通信类型7修改电机的CAN ID。修改成功后，电机将使用新的ID进行通信。

    警告:
        - 修改ID后需要重新初始化CAN总线连接
        - 确保新ID不与其他电机冲突
        - 新ID范围应在 1-127 之间

    参数:
        bus (can.Bus): CAN总线对象
        current_motor_id (int): 当前电机ID (1-127)
        new_motor_id (int): 新的电机ID (1-127)
        master_id (int): 主机ID (默认: 0xFD)
        timeout (float): 响应超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        log (callable): 日志函数，如果为None则使用print (默认: None)

    返回:
        int: 状态码 0=成功, 非0=失败

    异常:
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 等待响应超时
        InvalidParameterError: 电机ID超出有效范围

    示例:
        # 将电机ID从5修改为6
        state = set_motor_canid(bus, current_motor_id=5, new_motor_id=6, verbose=True)
        if state == 0:
            print("电机ID修改成功，请重新初始化连接")

        # 批量修改电机ID（注意：一次只能修改一个）
        id_mapping = {1: 11, 2: 12, 3: 13}
        for old_id, new_id in id_mapping.items():
            set_motor_canid(bus, old_id, new_id)
            time.sleep(0.1)  # 短暂延迟确保修改生效
    """
    # 验证ID范围
    if not (1 <= current_motor_id <= 127):
        raise InvalidParameterError(f"当前电机ID {current_motor_id} 超出有效范围 (1-127)")
    if not (1 <= new_motor_id <= 127):
        raise InvalidParameterError(f"新电机ID {new_motor_id} 超出有效范围 (1-127)")

    # 功能码 0x07 (通信类型7: 设置电机CAN_ID)
    # 仲裁ID格式: 0x0700fd00 + (new_motor_id << 16) + current_motor_id
    # Bit0~7: 当前电机ID
    # Bit8~15: 主机ID (默认0xFD)
    # Bit16~23: 新的电机ID
    # Bit24~31: 功能码 (0x07)
    arbitration_id = 0x07000000 | (new_motor_id << 16) | (master_id << 8) | current_motor_id
    data = [0] * 8  # 数据全0

    disable_motor(bus, current_motor_id, timeout=timeout, verbose=verbose, log=log)
    time.sleep(0.1)

    state, rx_data, rx_arbitration_id = send_extended_frame_main(
        bus, arbitration_id, data,
        block_receive=1,
        timeout=timeout,
        verbose=verbose,
        expected_motor_id=new_motor_id  # 期待新ID的响应，因为电机修改ID后会用新ID回复
    )

    if verbose or state == 0:
        if state == 0:
            log_output(f"电机ID修改成功: {current_motor_id} -> {new_motor_id}", "SUCCESS", log)
            log_output(f"提示: 请使用新ID ({new_motor_id}) 重新初始化电机连接", "INFO", log)
        else:
            log_output(f"电机ID修改失败: {current_motor_id} -> {new_motor_id}", "ERROR", log)

    return state
