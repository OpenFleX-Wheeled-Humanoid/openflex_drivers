#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UM 轮毂电机管理模块

提供 UM 系列轮毂电机的底层通信和管理功能，基于 CANopen SDO/PDO 协议。

功能模块：
1. 基础 SDO 通信接口
2. TPDO 配置和数据解析
3. 高层监控函数
4. 电机扫描和 ID 设置
"""

import socket
import struct
import time
import math

# ==================== CANopen SDO 常量 ====================
SDO_CMD_READ = 0x40
SDO_CMD_WRITE_1BYTE = 0x2F
SDO_CMD_WRITE_2BYTE = 0x2B
SDO_CMD_WRITE_4BYTE = 0x23
SDO_RESP_WRITE_OK = 0x60
SDO_TIMEOUT = 0.15
SAVE_WRITE_DELAY_S = 0.2

# ==================== 对象字典地址 ====================
# 标准 CiA402 对象
OD_CONTROL_WORD = (0x6040, 0x00)
OD_STATUS_WORD = (0x6041, 0x00)
OD_ERROR_CODE = (0x603F, 0x00)
OD_MODE_OF_OPERATION = (0x6060, 0x00)
OD_MODE_DISPLAY = (0x6061, 0x00)
OD_TARGET_VELOCITY = (0x60FF, 0x00)     # 32S, 单位 0.1rpm
OD_PROFILE_ACCEL = (0x6083, 0x00)       # 32U, 单位 ms
OD_PROFILE_DECEL = (0x6084, 0x00)       # 32U, 单位 ms
OD_POSITION_ACTUAL = (0x6063, 0x00)     # 32S, 实际位置
OD_VELOCITY_SENSOR = (0x6069, 0x00)     # 32S, 实际速度, 0.1rpm
OD_CURRENT_ACTUAL = (0x6078, 0x00)      # 16S, 电流实际值

# UM 厂商参数对象
OD_FN_CONTROL_MODE = (0x2102, 0x00)     # Fn1.002, 20=CANopen
OD_PN_CAN_NODE_ID = (0x4506, 0x00)      # Pn5.006
OD_PN_WRITE_PROTECT = (0x450A, 0x00)    # Pn5.00A
OD_PN_CAN_WATCHDOG_MS = (0x450B, 0x00)  # Pn5.00B
OD_PN_CAN_WATCHDOG_ACT = (0x450C, 0x00) # Pn5.00C
OD_PN_ALARM_CLEAR = (0x4602, 0x00)      # Pn6.002
OD_PN_REBOOT = (0x4603, 0x00)           # Pn6.003
OD_DN_ALARM_CODE = (0x5012, 0x00)       # Dn0.012
OD_DN_MOTOR_TEMP = (0x501B, 0x00)       # Dn0.01B, 电机温度 ℃
OD_DN_DRIVER_TEMP = (0x501D, 0x00)      # Dn0.01D, 驱动器温度 ℃

# TPDO1 配置对象
OD_TPDO1_COMM = 0x1800
OD_TPDO1_MAPPING = 0x1A00

# TPDO1 映射对象
MAP_I32_VELOCITY_SENSOR = 0x60690020
MAP_I32_POSITION_ACTUAL = 0x60630020


# ==================== 辅助函数 ====================

def _pack_can_frame(can_id, data=b"\x00" * 8):
    """打包 CAN 帧"""
    return struct.pack("=IB3x8s", can_id, 8, data.ljust(8, b"\x00"))


def _flush_can_rx(sock, timeout=0.02, max_frames=500):
    """清空 CAN 接收缓冲区"""
    sock.settimeout(timeout)
    for _ in range(max_frames):
        try:
            sock.recv(16)
        except socket.timeout:
            break


def _decode_signed(raw, bits):
    """解码有符号整数"""
    sign = 1 << (bits - 1)
    full = 1 << bits
    return raw - full if raw & sign else raw


def _get_sdo_ids(node_id):
    """获取 SDO 通信 ID"""
    return {
        'tx': 0x600 + node_id,
        'rx': 0x580 + node_id,
        'pdo1': 0x180 + node_id
    }


# ==================== 基础通讯 SDO 接口 ====================

def sdo_read_um(can_interface, node_id, index, subindex, timeout=SDO_TIMEOUT):
    """
    读取 UM 电机 SDO 对象

    Args:
        can_interface: CAN 接口名称（如 "can4"）
        node_id: 电机节点 ID (1-127)
        index: 对象字典索引
        subindex: 对象字典子索引
        timeout: 超时时间（秒）

    Returns:
        int or None: 读取的值，失败返回 None
    """
    sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
    try:
        sock.bind((can_interface,))
    except OSError as e:
        sock.close()
        raise RuntimeError(f"无法绑定 CAN 接口 {can_interface}: {e}")

    try:
        ids = _get_sdo_ids(node_id)

        # 构造 SDO 读请求
        data = bytearray(8)
        data[0] = SDO_CMD_READ
        data[1] = index & 0xFF
        data[2] = (index >> 8) & 0xFF
        data[3] = subindex

        sock.send(_pack_can_frame(ids['tx'], bytes(data)))

        # 等待响应
        sock.settimeout(timeout)
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                frame = sock.recv(16)
            except socket.timeout:
                break

            can_id = struct.unpack("=I", frame[:4])[0] & 0x1FFFFFFF
            if can_id != ids['rx']:
                continue

            resp = frame[8:16]
            if resp[1] != (index & 0xFF) or resp[2] != ((index >> 8) & 0xFF) or resp[3] != subindex:
                continue

            cmd = resp[0]
            if cmd == 0x80:  # SDO 错误
                return None
            if cmd == 0x4F:  # 1 字节
                return resp[4]
            if cmd == 0x4B:  # 2 字节
                return struct.unpack("<H", resp[4:6])[0]
            if cmd == 0x43:  # 4 字节
                return struct.unpack("<I", resp[4:8])[0]
            return None

        return None
    finally:
        sock.close()


def sdo_write_um(can_interface, node_id, index, subindex, value, size, timeout=SDO_TIMEOUT):
    """
    写入 UM 电机 SDO 对象

    Args:
        can_interface: CAN 接口名称（如 "can4"）
        node_id: 电机节点 ID (1-127)
        index: 对象字典索引
        subindex: 对象字典子索引
        value: 要写入的值
        size: 数据大小（1, 2, 或 4 字节）
        timeout: 超时时间（秒）

    Returns:
        bool: 写入成功返回 True，失败返回 False
    """
    if size not in (1, 2, 4):
        raise ValueError(f"size 必须是 1, 2, 或 4，当前为 {size}")

    sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
    try:
        sock.bind((can_interface,))
    except OSError as e:
        sock.close()
        raise RuntimeError(f"无法绑定 CAN 接口 {can_interface}: {e}")

    try:
        ids = _get_sdo_ids(node_id)
        cmd = {1: SDO_CMD_WRITE_1BYTE, 2: SDO_CMD_WRITE_2BYTE, 4: SDO_CMD_WRITE_4BYTE}[size]

        # 构造 SDO 写请求
        data = bytearray(8)
        data[0] = cmd
        data[1] = index & 0xFF
        data[2] = (index >> 8) & 0xFF
        data[3] = subindex
        for i in range(size):
            data[4 + i] = (value >> (8 * i)) & 0xFF

        sock.send(_pack_can_frame(ids['tx'], bytes(data)))

        # 等待响应
        sock.settimeout(timeout)
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                frame = sock.recv(16)
            except socket.timeout:
                break

            can_id = struct.unpack("=I", frame[:4])[0] & 0x1FFFFFFF
            if can_id != ids['rx']:
                continue

            resp = frame[8:16]
            if resp[1] != (index & 0xFF) or resp[2] != ((index >> 8) & 0xFF) or resp[3] != subindex:
                continue

            return resp[0] == SDO_RESP_WRITE_OK

        return False
    finally:
        sock.close()


# ==================== TPDO 接口 ====================

def configure_um_motor_tpdo(can_interface, node_id, period_ms=20):
    """
    配置 UM 电机 TPDO1（速度 + 位置）

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        period_ms: TPDO 发送周期（毫秒），范围 5-1000

    Returns:
        bool: 配置成功返回 True
    """
    period_ms = min(max(int(period_ms), 5), 1000)
    inhibit_100us = period_ms * 10
    pdo1_id = 0x180 + node_id

    # 禁用 TPDO1
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_COMM, 0x01, pdo1_id | 0x80000000, 4):
        return False

    # 清空映射
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_MAPPING, 0x00, 0, 1):
        return False

    # 映射速度（0x6069）
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_MAPPING, 0x01, MAP_I32_VELOCITY_SENSOR, 4):
        return False

    # 映射位置（0x6063）
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_MAPPING, 0x02, MAP_I32_POSITION_ACTUAL, 4):
        return False

    # 启用映射（2 个对象）
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_MAPPING, 0x00, 2, 1):
        return False

    # 设置传输类型（254 = 事件驱动 + 周期）
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_COMM, 0x02, 254, 1):
        return False

    # 设置抑制时间
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_COMM, 0x03, inhibit_100us, 2):
        return False

    # 设置事件定时器（周期）
    if not sdo_write_um(can_interface, node_id, OD_TPDO1_COMM, 0x05, period_ms, 2):
        return False

    # 启用 TPDO1
    return sdo_write_um(can_interface, node_id, OD_TPDO1_COMM, 0x01, pdo1_id, 4)


def read_um_motor_pdo(can_interface, node_id, timeout=0.1):
    """
    读取 UM 电机 TPDO1 数据

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        timeout: 超时时间（秒）

    Returns:
        bytes or None: 8 字节 PDO 数据，失败返回 None
    """
    sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
    try:
        sock.bind((can_interface,))
    except OSError as e:
        sock.close()
        raise RuntimeError(f"无法绑定 CAN 接口 {can_interface}: {e}")

    try:
        pdo1_id = 0x180 + node_id
        sock.settimeout(timeout)
        deadline = time.time() + timeout

        while time.time() < deadline:
            try:
                frame = sock.recv(16)
            except socket.timeout:
                break

            can_id = struct.unpack("=I", frame[:4])[0] & 0x1FFFFFFF
            if can_id == pdo1_id:
                return frame[8:16]

        return None
    finally:
        sock.close()


def parse_um_motor_pdo(pdo_data, direction=1, position_resolution=2097152):
    """
    解析 UM 电机 TPDO1 数据（速度 + 位置）

    Args:
        pdo_data: 8 字节 PDO 数据
        direction: 电机方向（1 或 -1）
        position_resolution: 位置分辨率（编码器线数）

    Returns:
        dict: {'velocity_rpm': float, 'velocity_rads': float, 'position_raw': int, 'position_rad': float}
    """
    if len(pdo_data) < 8:
        raise ValueError("PDO 数据长度不足 8 字节")

    velocity_01rpm = struct.unpack("<i", pdo_data[0:4])[0]
    position_raw = struct.unpack("<i", pdo_data[4:8])[0]

    velocity_rpm = (velocity_01rpm / 10.0) * direction
    velocity_rads = velocity_rpm * 2.0 * math.pi / 60.0
    position_rad = (position_raw * 2.0 * math.pi / position_resolution) * direction

    return {
        'velocity_rpm': velocity_rpm,
        'velocity_rads': velocity_rads,
        'position_raw': position_raw,
        'position_rad': position_rad
    }


# ==================== 高层监控函数 ====================

def read_um_motor_status(can_interface, node_id, timeout=SDO_TIMEOUT):
    """
    读取 UM 电机完整状态

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        timeout: 超时时间（秒）

    Returns:
        dict: 包含位置、速度、电流、温度、报警码等信息
    """
    status = {
        'node_id': node_id,
        'position_raw': None,
        'velocity_rpm': None,
        'velocity_rads': None,
        'current_a': None,
        'motor_temp_c': None,
        'driver_temp_c': None,
        'alarm_code': None,
        'status_word': None,
        'mode': None,
        'online': False
    }

    # 读取位置
    pos = sdo_read_um(can_interface, node_id, *OD_POSITION_ACTUAL, timeout=timeout)
    if pos is not None:
        status['position_raw'] = _decode_signed(pos, 32)
        status['online'] = True

    # 读取速度
    vel = sdo_read_um(can_interface, node_id, *OD_VELOCITY_SENSOR, timeout=timeout)
    if vel is not None:
        vel_signed = _decode_signed(vel, 32)
        status['velocity_rpm'] = vel_signed / 10.0
        status['velocity_rads'] = status['velocity_rpm'] * 2.0 * math.pi / 60.0

    # 读取电流
    cur = sdo_read_um(can_interface, node_id, *OD_CURRENT_ACTUAL, timeout=timeout)
    if cur is not None:
        status['current_a'] = _decode_signed(cur, 16) / 1000.0

    # 读取电机温度
    motor_temp = sdo_read_um(can_interface, node_id, *OD_DN_MOTOR_TEMP, timeout=timeout)
    if motor_temp is not None:
        status['motor_temp_c'] = float(_decode_signed(motor_temp, 16))

    # 读取驱动器温度
    driver_temp = sdo_read_um(can_interface, node_id, *OD_DN_DRIVER_TEMP, timeout=timeout)
    if driver_temp is not None:
        status['driver_temp_c'] = float(_decode_signed(driver_temp, 16))

    # 读取报警码
    alarm = sdo_read_um(can_interface, node_id, *OD_DN_ALARM_CODE, timeout=timeout)
    if alarm is not None:
        status['alarm_code'] = int(alarm)

    # 读取状态字
    status_word = sdo_read_um(can_interface, node_id, *OD_STATUS_WORD, timeout=timeout)
    if status_word is not None:
        status['status_word'] = status_word

    # 读取模式
    mode = sdo_read_um(can_interface, node_id, *OD_MODE_DISPLAY, timeout=timeout)
    if mode is not None:
        status['mode'] = _decode_signed(mode, 8)

    return status


def read_um_motor_position(can_interface, node_id, timeout=SDO_TIMEOUT):
    """
    读取 UM 电机位置

    Returns:
        int or None: 编码器位置（原始值）
    """
    pos = sdo_read_um(can_interface, node_id, *OD_POSITION_ACTUAL, timeout=timeout)
    if pos is not None:
        return _decode_signed(pos, 32)
    return None


def read_um_motor_velocity(can_interface, node_id, timeout=SDO_TIMEOUT):
    """
    读取 UM 电机速度

    Returns:
        dict or None: {'rpm': float, 'rads': float}
    """
    vel = sdo_read_um(can_interface, node_id, *OD_VELOCITY_SENSOR, timeout=timeout)
    if vel is not None:
        vel_signed = _decode_signed(vel, 32)
        rpm = vel_signed / 10.0
        rads = rpm * 2.0 * math.pi / 60.0
        return {'rpm': rpm, 'rads': rads}
    return None


def read_um_motor_temperature(can_interface, node_id, timeout=SDO_TIMEOUT):
    """
    读取 UM 电机温度

    Returns:
        dict or None: {'motor_temp_c': float, 'driver_temp_c': float}
    """
    motor_temp = sdo_read_um(can_interface, node_id, *OD_DN_MOTOR_TEMP, timeout=timeout)
    driver_temp = sdo_read_um(can_interface, node_id, *OD_DN_DRIVER_TEMP, timeout=timeout)

    result = {}
    if motor_temp is not None:
        result['motor_temp_c'] = float(_decode_signed(motor_temp, 16))
    if driver_temp is not None:
        result['driver_temp_c'] = float(_decode_signed(driver_temp, 16))

    return result if result else None


# ==================== 电机扫描和 ID 设置 ====================

def scan_um_motors(can_interface, id_start=1, id_end=127, timeout=0.18, quick_scan=True):
    """
    扫描 CAN 总线上的 UM 电机

    Args:
        can_interface: CAN 接口名称
        id_start: 起始节点 ID（默认 1）
        id_end: 结束节点 ID（默认 127）
        timeout: 每个节点的超时时间（秒）
        quick_scan: 是否启用快速扫描模式（先扫描 1-4，未找到再扫描全部）

    Returns:
        list: 在线电机的节点 ID 列表
    """
    found = []

    if quick_scan and id_start == 1 and id_end == 127:
        # 快速扫描模式：先扫描常用 ID 1-4
        print(f"快速扫描常用 ID 1-4...")
        for node_id in range(1, 5):
            pos = sdo_read_um(can_interface, node_id, *OD_POSITION_ACTUAL, timeout=timeout)
            if pos is not None:
                found.append(node_id)

        # 如果找到了电机，直接返回
        if found:
            return found

        # 没找到，扫描剩余 ID 5-127
        print(f"未找到电机，扫描剩余 ID 5-127...")
        for node_id in range(5, 128):
            pos = sdo_read_um(can_interface, node_id, *OD_POSITION_ACTUAL, timeout=timeout)
            if pos is not None:
                found.append(node_id)
                print(f"  发现电机 ID {node_id}")
    else:
        # 普通扫描模式：按指定范围扫描
        for node_id in range(id_start, id_end + 1):
            pos = sdo_read_um(can_interface, node_id, *OD_POSITION_ACTUAL, timeout=timeout)
            if pos is not None:
                found.append(node_id)

    return found


def verify_um_motor(can_interface, node_id, timeout=0.2):
    """
    验证 UM 电机是否在线并读取基本信息

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        timeout: 超时时间（秒）

    Returns:
        dict or None: 电机信息字典，离线返回 None
    """
    pos = sdo_read_um(can_interface, node_id, *OD_POSITION_ACTUAL, timeout=timeout)
    if pos is None:
        return None

    info = {
        'node_id': node_id,
        'position': _decode_signed(pos, 32),
        'online': True
    }

    # 读取存储的节点 ID
    stored_id = sdo_read_um(can_interface, node_id, *OD_PN_CAN_NODE_ID, timeout=timeout)
    if stored_id is not None:
        info['stored_node_id'] = stored_id

    # 读取控制模式
    ctrl_mode = sdo_read_um(can_interface, node_id, *OD_FN_CONTROL_MODE, timeout=timeout)
    if ctrl_mode is not None:
        info['control_mode'] = ctrl_mode

    # 读取报警码
    alarm = sdo_read_um(can_interface, node_id, *OD_DN_ALARM_CODE, timeout=timeout)
    if alarm is not None:
        info['alarm_code'] = alarm

    return info


def set_um_motor_id(can_interface, current_id, new_id, timeout=0.2):
    """
    设置 UM 电机节点 ID

    流程：
    1. 打开通讯写保护 (Pn5.00A=1)
    2. 写入节点号 (Pn5.006=新ID)
    3. 关闭通讯写保护 (Pn5.00A=0)
    4. 重启电机 (Pn6.003=1)

    Args:
        can_interface: CAN 接口名称
        current_id: 当前节点 ID
        new_id: 新节点 ID (1-127)
        timeout: 超时时间（秒）

    Returns:
        bool: 设置成功返回 True
    """
    if not (1 <= current_id <= 127 and 1 <= new_id <= 127):
        raise ValueError("节点 ID 必须在 1-127 范围内")

    if current_id == new_id:
        raise ValueError("新 ID 与当前 ID 相同")

    # 验证电机在线
    pos = sdo_read_um(can_interface, current_id, *OD_POSITION_ACTUAL, timeout=timeout)
    if pos is None:
        return False

    # 打开写保护
    if not sdo_write_um(can_interface, current_id, *OD_PN_WRITE_PROTECT, 1, 2, timeout=timeout):
        return False
    time.sleep(SAVE_WRITE_DELAY_S)

    # 写入节点号
    if not sdo_write_um(can_interface, current_id, *OD_PN_CAN_NODE_ID, new_id, 2, timeout=timeout):
        # 写入失败，尝试关闭写保护
        sdo_write_um(can_interface, current_id, *OD_PN_WRITE_PROTECT, 0, 2, timeout=timeout)
        return False
    time.sleep(SAVE_WRITE_DELAY_S)

    # 关闭写保护
    if not sdo_write_um(can_interface, current_id, *OD_PN_WRITE_PROTECT, 0, 2, timeout=timeout):
        return False
    time.sleep(SAVE_WRITE_DELAY_S)

    # 重启电机
    sdo_write_um(can_interface, current_id, *OD_PN_REBOOT, 1, 2, timeout=0.3)
    time.sleep(1.0)

    return True


# ==================== 电机运动控制接口 ====================

# 控制字常量
CW_SHUTDOWN = 0x0006
CW_SWITCH_ON = 0x0007
CW_ENABLE_OPERATION = 0x000F
CW_DISABLE_OPERATION = 0x0007
CW_CLEAR_FAULT = 0x0080

# 控制模式
CONTROL_MODE_CANOPEN = 20
MODE_PROFILE_VELOCITY = 3


def enable_um_motor(can_interface, node_id,
                    profile_accel_ms=1000,
                    profile_decel_ms=1000,
                    can_watchdog_timeout_ms=100,
                    can_watchdog_action=2,
                    timeout=0.2):
    """
    使能 UM 电机（Profile Velocity 模式）

    流程：
    1. 确保 CANopen 模式
    2. 发送 NMT Start 命令
    3. 配置看门狗
    4. 设置 PV 模式和加减速参数
    5. 执行使能状态机：Shutdown -> Switch On -> Enable Operation

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        profile_accel_ms: 加速时间（毫秒），0->3000rpm 的时间
        profile_decel_ms: 减速时间（毫秒）
        can_watchdog_timeout_ms: CAN 看门狗超时（毫秒），0-111
        can_watchdog_action: 看门狗动作（0=无动作, 1=报警, 2=停机）
        timeout: SDO 超时时间（秒）

    Returns:
        bool: 使能成功返回 True
    """
    # 确保 CANopen 模式
    current_mode = sdo_read_um(can_interface, node_id, *OD_FN_CONTROL_MODE, timeout=timeout)
    if current_mode != CONTROL_MODE_CANOPEN:
        # 需要切换到 CANopen 模式并重启
        if not sdo_write_um(can_interface, node_id, *OD_PN_WRITE_PROTECT, 1, 2, timeout=timeout):
            return False
        time.sleep(SAVE_WRITE_DELAY_S)

        if not sdo_write_um(can_interface, node_id, *OD_FN_CONTROL_MODE, CONTROL_MODE_CANOPEN, 2, timeout=timeout):
            sdo_write_um(can_interface, node_id, *OD_PN_WRITE_PROTECT, 0, 2, timeout=timeout)
            return False
        time.sleep(SAVE_WRITE_DELAY_S)

        if not sdo_write_um(can_interface, node_id, *OD_PN_WRITE_PROTECT, 0, 2, timeout=timeout):
            return False
        time.sleep(SAVE_WRITE_DELAY_S)

        # 重启
        sdo_write_um(can_interface, node_id, *OD_PN_REBOOT, 1, 2, timeout=0.3)
        time.sleep(1.0)

    # 发送 NMT Start 命令（让节点进入 Operational 状态）
    sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
    try:
        sock.bind((can_interface,))
        # NMT Start: COB-ID=0x000, data=[0x01, node_id]
        nmt_data = bytes([0x01, node_id])
        sock.send(_pack_can_frame(0x000, nmt_data))
        time.sleep(0.02)
    finally:
        sock.close()

    # 清除报警
    sdo_write_um(can_interface, node_id, *OD_PN_ALARM_CLEAR, 1, 2, timeout=timeout)
    time.sleep(0.02)

    # 配置看门狗
    if not sdo_write_um(can_interface, node_id, *OD_PN_CAN_WATCHDOG_MS, can_watchdog_timeout_ms, 2, timeout=timeout):
        return False
    if not sdo_write_um(can_interface, node_id, *OD_PN_CAN_WATCHDOG_ACT, can_watchdog_action, 2, timeout=timeout):
        return False

    # 设置 Profile Velocity 模式
    if not sdo_write_um(can_interface, node_id, *OD_MODE_OF_OPERATION, MODE_PROFILE_VELOCITY, 1, timeout=timeout):
        return False

    # 设置加减速时间
    if not sdo_write_um(can_interface, node_id, *OD_PROFILE_ACCEL, profile_accel_ms, 4, timeout=timeout):
        return False
    if not sdo_write_um(can_interface, node_id, *OD_PROFILE_DECEL, profile_decel_ms, 4, timeout=timeout):
        return False

    # 清零目标速度
    if not sdo_write_um(can_interface, node_id, *OD_TARGET_VELOCITY, 0, 4, timeout=timeout):
        return False

    # 状态机：Shutdown -> Switch On -> Enable Operation
    if not sdo_write_um(can_interface, node_id, *OD_CONTROL_WORD, CW_SHUTDOWN, 2, timeout=timeout):
        return False
    if not sdo_write_um(can_interface, node_id, *OD_CONTROL_WORD, CW_SWITCH_ON, 2, timeout=timeout):
        return False
    if not sdo_write_um(can_interface, node_id, *OD_CONTROL_WORD, CW_ENABLE_OPERATION, 2, timeout=timeout):
        return False

    return True


def disable_um_motor(can_interface, node_id, timeout=0.2):
    """
    失能 UM 电机

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        timeout: SDO 超时时间（秒）

    Returns:
        bool: 失能成功返回 True
    """
    # 先停止电机
    sdo_write_um(can_interface, node_id, *OD_TARGET_VELOCITY, 0, 4, timeout=timeout)
    time.sleep(0.03)

    # 失能
    return sdo_write_um(can_interface, node_id, *OD_CONTROL_WORD, CW_DISABLE_OPERATION, 2, timeout=timeout)


def set_um_motor_speed_rpm(can_interface, node_id, speed_rpm, max_speed_rpm=330, timeout=0.08):
    """
    设置 UM 电机目标速度（RPM）

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        speed_rpm: 目标速度（RPM），正值为正转，负值为反转
        max_speed_rpm: 最大速度限制（RPM）
        timeout: SDO 超时时间（秒）

    Returns:
        bool: 设置成功返回 True
    """
    # 限制速度范围
    speed_rpm = max(min(float(speed_rpm), max_speed_rpm), -max_speed_rpm)

    # 转换为 0.1rpm 单位
    velocity_01rpm = int(round(speed_rpm * 10.0))

    # 写入目标速度
    if not sdo_write_um(
        can_interface, node_id, *OD_TARGET_VELOCITY, velocity_01rpm & 0xFFFFFFFF, 4, timeout=timeout
    ):
        return False
    # 刷新 6040 运行态，同时喂 CAN 看门狗（Pn5.00B 默认 100ms 无通信会清零速度）
    return sdo_write_um(
        can_interface, node_id, *OD_CONTROL_WORD, CW_ENABLE_OPERATION, 2, timeout=timeout
    )


def set_um_motor_speed_rads(can_interface, node_id, speed_rads, max_speed_rpm=330, timeout=0.08):
    """
    设置 UM 电机目标速度（rad/s）

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        speed_rads: 目标速度（rad/s）
        max_speed_rpm: 最大速度限制（RPM）
        timeout: SDO 超时时间（秒）

    Returns:
        bool: 设置成功返回 True
    """
    # 转换为 RPM
    speed_rpm = speed_rads * 60.0 / (2.0 * math.pi)
    return set_um_motor_speed_rpm(can_interface, node_id, speed_rpm, max_speed_rpm, timeout)


def stop_um_motor(can_interface, node_id, timeout=0.08):
    """
    停止 UM 电机（设置目标速度为 0）

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        timeout: SDO 超时时间（秒）

    Returns:
        bool: 停止成功返回 True
    """
    return sdo_write_um(can_interface, node_id, *OD_TARGET_VELOCITY, 0, 4, timeout=timeout)


def clear_um_motor_alarm(can_interface, node_id, timeout=0.2):
    """
    清除 UM 电机报警

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        timeout: SDO 超时时间（秒）

    Returns:
        bool: 清除成功返回 True
    """
    # 发送清除报警命令
    if not sdo_write_um(can_interface, node_id, *OD_PN_ALARM_CLEAR, 1, 2, timeout=timeout):
        return False

    # 或者发送 Clear Fault 控制字
    return sdo_write_um(can_interface, node_id, *OD_CONTROL_WORD, CW_CLEAR_FAULT, 2, timeout=timeout)


def set_um_motor_profile_params(can_interface, node_id, accel_ms=1000, decel_ms=1000, timeout=0.2):
    """
    设置 UM 电机加减速参数

    Args:
        can_interface: CAN 接口名称
        node_id: 电机节点 ID
        accel_ms: 加速时间（毫秒），0->3000rpm 的时间
        decel_ms: 减速时间（毫秒）
        timeout: SDO 超时时间（秒）

    Returns:
        bool: 设置成功返回 True
    """
    if not sdo_write_um(can_interface, node_id, *OD_PROFILE_ACCEL, accel_ms, 4, timeout=timeout):
        return False
    return sdo_write_um(can_interface, node_id, *OD_PROFILE_DECEL, decel_ms, 4, timeout=timeout)
