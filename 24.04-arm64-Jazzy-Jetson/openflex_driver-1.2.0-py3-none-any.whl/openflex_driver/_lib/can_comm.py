#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   can_comm.py
@Time    :   2025/12/10
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   CAN总线底层通信接口
             包含CAN帧发送/接收、数据转换等基础功能
'''

import can
import time
import struct
import sys
import os

# 导入异常类
try:
    from ..exceptions import CANTransmissionError, CANTimeoutError
except ImportError:
    # 如果作为脚本运行
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, parent_dir)
    from exceptions import CANTransmissionError, CANTimeoutError


#**************************************************************************
# 数据类型转换函数
#**************************************************************************

def float_to_uint16(float_data, float_data_min, float_data_max):
    """
    有符号浮点型转十六进制(0~65535)无符号型

    参数:
        float_data (float): 输入的浮点数
        float_data_min (float): 浮点数的最小值
        float_data_max (float): 浮点数的最大值

    返回:
        int: 转换后的无符号整数 (0-65535)

    说明:
        - 将浮点数映射到 0-65535 的范围
        - 超出范围的值会被限制在 min/max
        - 常用于电机参数的编码
    """
    if float_data > float_data_max:
        float_data_s = float_data_max
    elif float_data < float_data_min:
        float_data_s = float_data_min
    else:
        float_data_s = float_data

    return int((float_data_s - float_data_min) / (float_data_max - float_data_min) * 65535)


def uint16_to_float(uint16_data, float_data_min, float_data_max):
    """
    十六进制(0~65535)无符号型转有符号浮点型

    参数:
        uint16_data (int): 输入的无符号整数 (0-65535)
        float_data_min (float): 浮点数的最小值
        float_data_max (float): 浮点数的最大值

    返回:
        float: 转换后的浮点数

    说明:
        - 将 0-65535 的范围映射回浮点数
        - 常用于电机反馈数据的解码
    """
    return float(uint16_data / 65535) * (float_data_max - float_data_min) + float_data_min


def float_to_P4hex(float_data):
    """
    有符号浮点型转四位十六进制(输出小端模式：低在左高在右)

    参数:
        float_data (float): 输入的浮点数

    返回:
        bytes: 4字节的字节序列 (小端模式)

    说明:
        - 适合单个参数写函数
        - 使用IEEE 754浮点数标准
        - 小端模式: 低字节在前
    """
    byte_representation = struct.pack('f', float_data)
    return byte_representation


def P4hex_to_float(P4hex_data):
    """
    四位十六进制转有符号浮点型(输入小端模式：低在左高在右)

    参数:
        P4hex_data (int): 4字节整数

    返回:
        float: 转换后的浮点数

    说明:
        - 适合单个参数读函数
        - 大端转换后解包
    """
    bytes_obj = P4hex_data.to_bytes(4, byteorder='big')
    float_value = struct.unpack('f', bytes_obj)[0]
    return float_value


#**************************************************************************
# CAN帧发送/接收函数
#**************************************************************************

def send_extended_frame_main(bus, arbitration_id, data, block_receive=1, timeout=1.0, verbose=False, expected_motor_id=None):
    """
    标准CAN扩展帧收发接口（核心函数）

    参数:
        bus (can.Bus): CAN总线对象
        arbitration_id (int): 29位扩展仲裁ID
        data (list): CAN数据字段，长度0-8字节
        block_receive (int): 是否阻塞接收 0=不等待接收, 1=等待接收 (默认: 1)
        timeout (float): 接收超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)
        expected_motor_id (int): 期待的响应电机ID，如果为None则使用发送帧中的电机ID (默认: None)
                                 用于处理电机ID可能改变的特殊情况（如设置CAN ID命令）

    返回:
        tuple: (state, rx_data, rx_arbitration_id)
            - state (int): 状态码 0=成功
            - rx_data (list): 接收到的数据(8字节)
            - rx_arbitration_id (int): 接收到的仲裁ID (如果未接收则为0)

    异常:
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 等待响应超时 (仅当 block_receive=1 时)

    示例:
        >>> # 发送并等待响应
        >>> try:
        >>>     state, rx_data, rx_id = send_extended_frame_main(bus, 0x01000005, [0]*8, block_receive=1)
        >>> except CANTimeoutError:
        >>>     print("通信超时")
        >>>
        >>> # 只发送不等待
        >>> state, rx_data, rx_id = send_extended_frame_main(bus, 0x03000005, [0]*8, block_receive=0)
        >>>
        >>> # 设置电机ID时，期待新ID的响应
        >>> state, rx_data, rx_id = send_extended_frame_main(bus, 0x07050005, [0]*8, expected_motor_id=5)

    说明:
        - 这是所有CAN通信的核心函数
        - 支持阻塞和非阻塞模式
        - 通过异常处理超时和传输错误
        - 支持自定义期待的响应电机ID（用于特殊命令）
    """
    # 初始化返回值
    state = 0
    rx_data = [0 for _ in range(8)]
    rx_arbitration_id = 0

    # 创建CAN消息
    message = can.Message(
        arbitration_id=arbitration_id,
        data=data,
        is_extended_id=True
    )

    # 发送CAN消息
    try:
        bus.send(message)
        if verbose:
            print(f"[TX] ID: 0x{arbitration_id:08X}, Data: {[f'{b:02X}' for b in data]}")
    except can.CanError as e:
        # 抛出 CANTransmissionError 异常
        raise CANTransmissionError(f"CAN message send failed (ID: 0x{arbitration_id:08X}): {e}")

    # 如果需要阻塞接收
    if block_receive == 1:
        time_start = time.time()

        while True:
            # 计算剩余超时时间
            elapsed = time.time() - time_start
            remaining_timeout = timeout - elapsed

            if remaining_timeout <= 0:
                # 超时 - 抛出 CANTimeoutError 异常
                if verbose:
                    print(f"[TIMEOUT] Arbitration ID: 0x{arbitration_id:08X} no response received (timeout: {timeout}s)")
                # 从仲裁ID提取电机ID (假设格式: [comm_type 6bit][reserved 16bit][motor_id 8bit])
                motor_id = (arbitration_id >> 8) & 0xFF
                # raise CANTimeoutError(
                #     motor_id=motor_id,
                #     timeout=timeout,
                #     message=f"CAN 通信超时 (仲裁ID: 0x{arbitration_id:08X})"
                # )
                # break
                return 1, None, None

            # 尝试接收消息
            message_rx = bus.recv(timeout=min(0.1, remaining_timeout))

            if message_rx is not None:
                # 成功接收到消息
                rx_data = list(message_rx.data)
                rx_arbitration_id = message_rx.arbitration_id

                # 从仲裁ID中提取电机ID
                tx_motor_id = arbitration_id & 0xFF  # 发送帧中的目标电机ID (Bit0-7)
                rx_motor_id = (rx_arbitration_id >> 8) & 0xFF  # 接收帧中的电机ID (Bit8-15)

                # 确定期待的电机ID：如果指定了expected_motor_id，使用它；否则使用发送帧中的ID
                expected_id = expected_motor_id if expected_motor_id is not None else tx_motor_id

                if verbose:
                    print(f"[RX] ID: 0x{rx_arbitration_id:08X}, Data: {[f'{b:02X}' for b in rx_data]}")

                    # 解析通信类型
                    comm_type = (rx_arbitration_id >> 24) & 0x3F
                    print(f"     Comm type: {comm_type}, Motor ID: {rx_motor_id}, Expected ID: {expected_id}")

                # 验证响应是否来自目标电机
                if rx_motor_id == expected_id:
                    # 电机ID匹配，这是目标电机的响应
                    state = 0
                    break
                else:
                    # 收到非目标电机的消息，继续等待
                    if verbose:
                        print(f"     [IGNORED] Message from unexpected motor (expected ID:{expected_id}, received ID:{rx_motor_id})")
                    continue

    return (state, rx_data, rx_arbitration_id)


def send_extended_frame_no_wait(bus, arbitration_id, data, verbose=False):
    """
    发送CAN扩展帧(不等待响应)

    参数:
        bus (can.Bus): CAN总线对象
        arbitration_id (int): 29位扩展仲裁ID
        data (list): CAN数据字段，长度0-8字节
        verbose (bool): 是否打印详细调试信息 (默认: False)

    返回:
        int: 状态码 0=成功, 1=失败

    示例:
        >>> # 发送命令，不等待响应
        >>> state = send_extended_frame_no_wait(bus, 0x03000005, [0]*8)
        >>> if state == 0:
        >>>     print("发送成功")

    说明:
        - 用于不需要响应的命令
        - 比阻塞模式更快
        - 适合批量发送命令
    """
    state, _, _ = send_extended_frame_main(bus, arbitration_id, data, block_receive=0, verbose=verbose)
    return state


def send_extended_frame_with_retry(bus, arbitration_id, data, max_retries=3, timeout=1.0, verbose=False):
    """
    发送CAN扩展帧并重试(如果失败)

    参数:
        bus (can.Bus): CAN总线对象
        arbitration_id (int): 29位扩展仲裁ID
        data (list): CAN数据字段，长度0-8字节
        max_retries (int): 最大重试次数 (默认: 3)
        timeout (float): 每次尝试的超时时间(秒) (默认: 1.0)
        verbose (bool): 是否打印详细调试信息 (默认: False)

    返回:
        tuple: (state, rx_data, rx_arbitration_id)
            - state (int): 状态码 0=成功
            - rx_data (list): 接收到的数据(8字节)
            - rx_arbitration_id (int): 接收到的仲裁ID

    异常:
        CANTransmissionError: CAN消息发送失败
        CANTimeoutError: 所有重试均超时

    示例:
        >>> # 发送命令，最多重试3次
        >>> try:
        >>>     state, rx_data, rx_id = send_extended_frame_with_retry(
        >>>         bus, 0x01000005, [0]*8, max_retries=3, timeout=1.0
        >>>     )
        >>>     print("通信成功")
        >>> except CANTimeoutError:
        >>>     print("所有重试均超时")

    说明:
        - 提高通信可靠性
        - 自动重试失败的通信
        - 每次重试之间有短暂延迟
        - CANTransmissionError 会立即抛出，不重试
    """
    last_exception = None

    for attempt in range(max_retries):
        try:
            state, rx_data, rx_arbitration_id = send_extended_frame_main(
                bus, arbitration_id, data,
                block_receive=1,
                timeout=timeout,
                verbose=verbose
            )

            # 成功
            if verbose and attempt > 0:
                print(f"[SUCCESS] Attempt {attempt + 1} succeeded")
            return (state, rx_data, rx_arbitration_id)

        except CANTransmissionError:
            # 传输错误不重试，直接抛出
            raise

        except CANTimeoutError as e:
            # 超时错误，保存异常并重试
            last_exception = e
            if attempt < max_retries - 1:
                if verbose:
                    print(f"[RETRY] Attempt {attempt + 1} timed out, retrying...")
                time.sleep(0.1)  # 重试前短暂延迟

    # 所有重试都失败，抛出最后一次的异常
    if verbose:
        print(f"[FAILED] All {max_retries} attempts failed")

    if last_exception:
        raise last_exception

    # 理论上不会到这里
    rx_data = [0 for _ in range(8)]
    return (1, rx_data, 0)
