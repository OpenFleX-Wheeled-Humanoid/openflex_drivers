#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   teleop_core.py
@Time    :   2026/04/30
@Author  :   Li Qingran
@Version :   1.0
@Desc    :   IK逆解
             提供 VR 遥操使用
             Pinocchio teleoperation core for OpenArmX.

             This module preserves the legacy public teleop symbols while replacing the
             Placo-based implementation with the Pinocchio core
'''


from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

import pinocchio as pin


class WeightedMovingFilter:
    """Weighted moving average filter for smoothing trajectories."""

    def __init__(self, weights, dim):
        self.weights = np.array(weights, dtype=np.float64)
        self.weights = self.weights / np.sum(self.weights)
        self.window_size = len(weights)
        self.dim = dim
        self.buffer = []

    def filter(self, data):
        self.buffer.append(np.array(data, dtype=np.float64))
        if len(self.buffer) > self.window_size:
            self.buffer.pop(0)

        if len(self.buffer) < self.window_size:
            return data

        filtered = np.zeros(self.dim, dtype=np.float64)
        for i, weight in enumerate(self.weights):
            filtered += weight * self.buffer[-(i + 1)]
        return filtered

    def reset(self):
        self.buffer = []


class OpenArmXIKSolver:
    """Solve 14 arm joints against dual end-effector targets."""

    def __init__(
        self,
        urdf_path,
        left_ee_frame="openarmx_left_link7_pico",
        right_ee_frame="openarmx_right_link7_pico",
    ):
        self.urdf_path = str(urdf_path)
        self.left_ee_frame = left_ee_frame
        self.right_ee_frame = right_ee_frame

        self.robot = self._build_robot_wrapper(self.urdf_path)
        self.model = self.robot.model
        self.data = self.model.createData()

        self.arm_joint_names = [
            "openarmx_left_joint1",
            "openarmx_left_joint2",
            "openarmx_left_joint3",
            "openarmx_left_joint4",
            "openarmx_left_joint5",
            "openarmx_left_joint6",
            "openarmx_left_joint7",
            "openarmx_right_joint1",
            "openarmx_right_joint2",
            "openarmx_right_joint3",
            "openarmx_right_joint4",
            "openarmx_right_joint5",
            "openarmx_right_joint6",
            "openarmx_right_joint7",
        ]
        self.arm_joint_ids = [self.model.getJointId(name) for name in self.arm_joint_names]
        self.arm_q_indices = np.array(
            [self.model.idx_qs[jid] for jid in self.arm_joint_ids], dtype=np.int64
        )
        self.arm_v_indices = np.array(
            [self.model.idx_vs[jid] for jid in self.arm_joint_ids], dtype=np.int64
        )

        self.nq = len(self.arm_joint_names)
        self.left_ee_id = self.model.getFrameId(left_ee_frame)
        self.right_ee_id = self.model.getFrameId(right_ee_frame)

        self._neutral_q = np.asarray(pin.neutral(self.model), dtype=np.float64)
        self._zero_v = np.zeros(self.model.nv, dtype=np.float64)
        self.q_lower = np.asarray(
            self.model.lowerPositionLimit[self.arm_q_indices], dtype=np.float64
        )
        self.q_upper = np.asarray(
            self.model.upperPositionLimit[self.arm_q_indices], dtype=np.float64
        )

        self.max_iterations = 30
        self.position_weight = 50.0
        self.rotation_weight = 1.0
        self.damping = 1e-4
        self.step_size = 0.5
        self.error_tolerance = 1e-4

        self.q_filter = WeightedMovingFilter(weights=[0.4, 0.3, 0.2, 0.1], dim=self.nq)
        self.tauff_filter = WeightedMovingFilter(weights=[0.4, 0.3, 0.2, 0.1], dim=self.nq)
        self.q_last = self._neutral_q[self.arm_q_indices].copy()

    @staticmethod
    def _build_robot_wrapper(urdf_path: str) -> pin.RobotWrapper:
        urdf = Path(urdf_path).resolve()

        package_root = None
        for parent in urdf.parents:
            if parent.name == "openarmx_description":
                package_root = parent.parent
                break

        if package_root is not None:
            try:
                return pin.RobotWrapper.BuildFromURDF(str(urdf), str(package_root))
            except Exception:
                pass

        return pin.RobotWrapper.BuildFromURDF(str(urdf))

    def _build_full_configuration(self, q_arm):
        q_full = self._neutral_q.copy()
        q_full[self.arm_q_indices] = np.asarray(q_arm, dtype=np.float64)
        return q_full

    def _build_full_velocity(self, dq_arm=None):
        v_full = self._zero_v.copy()
        if dq_arm is not None:
            v_full[self.arm_v_indices] = np.asarray(dq_arm, dtype=np.float64)
        return v_full

    @staticmethod
    def _to_se3(transform):
        transform = np.asarray(transform, dtype=np.float64).reshape(4, 4)
        return pin.SE3(transform[:3, :3], transform[:3, 3])

    def _weighted_error_and_jacobian(self, q_arm, left_target, right_target):
        q_full = self._build_full_configuration(q_arm)
        pin.computeJointJacobians(self.model, self.data, q_full)
        pin.framesForwardKinematics(self.model, self.data, q_full)

        left_current = self.data.oMf[self.left_ee_id]
        right_current = self.data.oMf[self.right_ee_id]

        left_error = np.asarray(pin.log6(left_current.inverse() * left_target).vector).reshape(-1)
        right_error = np.asarray(pin.log6(right_current.inverse() * right_target).vector).reshape(-1)

        left_jacobian = pin.computeFrameJacobian(
            self.model, self.data, q_full, self.left_ee_id, pin.LOCAL
        )[:, self.arm_v_indices]
        right_jacobian = pin.computeFrameJacobian(
            self.model, self.data, q_full, self.right_ee_id, pin.LOCAL
        )[:, self.arm_v_indices]

        error = np.concatenate([left_error, right_error])
        jacobian = np.vstack([left_jacobian, right_jacobian])

        weights = np.array(
            [self.rotation_weight] * 3
            + [self.position_weight] * 3
            + [self.rotation_weight] * 3
            + [self.position_weight] * 3,
            dtype=np.float64,
        )

        return weights * error, weights[:, None] * jacobian

    def solve_ik(self, left_wrist, right_wrist, current_q=None, current_dq=None):
        if current_q is not None:
            current_q = np.asarray(current_q, dtype=np.float64).reshape(-1)
            if current_q.shape == (self.nq,):
                q_arm = current_q.copy()
            else:
                q_arm = self.q_last.copy()
        else:
            q_arm = self.q_last.copy()

        left_target = self._to_se3(left_wrist)
        right_target = self._to_se3(right_wrist)

        for _ in range(self.max_iterations):
            weighted_error, weighted_jacobian = self._weighted_error_and_jacobian(
                q_arm, left_target, right_target
            )
            if np.linalg.norm(weighted_error) < self.error_tolerance:
                break

            lhs = weighted_jacobian.T @ weighted_jacobian
            lhs += self.damping * np.eye(self.nq, dtype=np.float64)
            rhs = weighted_jacobian.T @ weighted_error

            try:
                dq = np.linalg.solve(lhs, rhs)
            except np.linalg.LinAlgError:
                dq = np.linalg.lstsq(lhs, rhs, rcond=None)[0]

            q_arm = q_arm + self.step_size * dq
            q_arm = np.clip(q_arm, self.q_lower, self.q_upper)

        q_arm = np.asarray(self.q_filter.filter(q_arm), dtype=np.float64).reshape(-1)
        self.q_last = q_arm.copy()

        q_full = self._build_full_configuration(q_arm)
        v_full = self._build_full_velocity(current_dq)
        tau_full = pin.rnea(
            self.model,
            self.data,
            q_full,
            v_full,
            np.zeros(self.model.nv, dtype=np.float64),
        )
        tau_arm = np.asarray(tau_full[self.arm_v_indices], dtype=np.float64).reshape(-1)
        tau_arm = np.asarray(self.tauff_filter.filter(tau_arm), dtype=np.float64).reshape(-1)

        return q_arm, tau_arm

    def get_end_effector_transforms(self, q_arm=None):
        if q_arm is None:
            q_arm = self.q_last

        q_full = self._build_full_configuration(np.asarray(q_arm, dtype=np.float64).reshape(-1))
        pin.framesForwardKinematics(self.model, self.data, q_full)

        left_pose = self.data.oMf[self.left_ee_id]
        right_pose = self.data.oMf[self.right_ee_id]

        left_tf = np.eye(4, dtype=np.float64)
        left_tf[:3, :3] = left_pose.rotation
        left_tf[:3, 3] = left_pose.translation

        right_tf = np.eye(4, dtype=np.float64)
        right_tf[:3, :3] = right_pose.rotation
        right_tf[:3, 3] = right_pose.translation

        return left_tf, right_tf

    def reset(self):
        self.q_filter.reset()
        self.tauff_filter.reset()
        self.q_last = self._neutral_q[self.arm_q_indices].copy()


@dataclass
class RelativePose:
    """Relative hand pose from VR side, already expressed as delta pose."""

    position: Tuple[float, float, float]
    orientation_xyzw: Tuple[float, float, float, float]
    timestamp: float = 0.0


@dataclass
class PoseInput:
    """Generic pose sample used by the teleop core."""

    position: np.ndarray
    orientation_xyzw: Tuple[float, float, float, float]
    timestamp: float


class TeleopInputFrame:
    """Inputs required for one relative teleoperation control step."""

    def __init__(
        self,
        left_pose: Optional[RelativePose],
        right_pose: Optional[RelativePose],
        left_grip: float,
        right_grip: float,
        left_trigger: float,
        right_trigger: float,
        is_full_speed: bool,
    ):
        self.left_pose = left_pose
        self.right_pose = right_pose
        self.left_grip = left_grip
        self.right_grip = right_grip
        self.left_trigger = left_trigger
        self.right_trigger = right_trigger
        self.is_full_speed = is_full_speed


@dataclass
class RelativeTeleopInputFrame:
    left_pose: Optional[PoseInput]
    right_pose: Optional[PoseInput]
    left_grip: float
    right_grip: float
    left_trigger: float
    right_trigger: float


@dataclass
class AbsoluteTeleopInputFrame:
    head_pose: Optional[PoseInput]
    left_pose: Optional[PoseInput]
    right_pose: Optional[PoseInput]
    left_grip: float
    right_grip: float
    left_trigger: float
    right_trigger: float
    mode_selected: bool


class TeleopConfig:
    """Configuration used by Pinocchio teleop cores."""

    def __init__(
        self,
        urdf_path: str,
        constraint_mode: str = "joint",
        use_link4_ext: bool = True,
        grip_threshold: float = 0.5,
        slow_max_step_deg: float = 3.0,
        fast_max_step_deg: float = 0.0,
        resync_threshold_deg: float = 5.0,
        ik_iterations: int = 3,
        sync_joint_states_each_cycle: bool = True,
        joint3_regularization_weight: float = 0.05,
        joint4_regularization_weight: float = 0.12,
        link4_task_weight: float = 0.25,
        joint_regularization_weight: float = 0.2,
        print_performance: bool = False,
        enable_placo_viewer: bool = False,
        body_anchor_offset: Optional[np.ndarray] = None,
        position_scale_xyz: Optional[np.ndarray] = None,
        left_axis_matrix: Optional[np.ndarray] = None,
        right_axis_matrix: Optional[np.ndarray] = None,
        left_orientation_matrix: Optional[np.ndarray] = None,
        right_orientation_matrix: Optional[np.ndarray] = None,
        stream_timeout_sec: float = 0.3,
    ):
        self.urdf_path = urdf_path
        self.constraint_mode = constraint_mode
        self.use_link4_ext = use_link4_ext
        self.grip_threshold = grip_threshold
        self.slow_max_step_deg = slow_max_step_deg
        self.fast_max_step_deg = fast_max_step_deg
        self.resync_threshold_deg = resync_threshold_deg
        self.ik_iterations = ik_iterations
        self.sync_joint_states_each_cycle = sync_joint_states_each_cycle
        self.joint3_regularization_weight = joint3_regularization_weight
        self.joint4_regularization_weight = joint4_regularization_weight
        self.link4_task_weight = link4_task_weight
        self.joint_regularization_weight = joint_regularization_weight
        self.print_performance = print_performance
        self.enable_placo_viewer = enable_placo_viewer
        self.body_anchor_offset = (
            np.asarray(body_anchor_offset, dtype=np.float64)
            if body_anchor_offset is not None
            else np.array([0.0, -0.18, 0.08], dtype=np.float64)
        )
        self.position_scale_xyz = (
            np.asarray(position_scale_xyz, dtype=np.float64)
            if position_scale_xyz is not None
            else np.array([1.0, 1.0, 0.9], dtype=np.float64)
        )
        self.left_axis_matrix = (
            np.asarray(left_axis_matrix, dtype=np.float64)
            if left_axis_matrix is not None
            else np.array([[0.0, 0.0, -1.0], [-1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float64)
        )
        self.right_axis_matrix = (
            np.asarray(right_axis_matrix, dtype=np.float64)
            if right_axis_matrix is not None
            else np.array([[0.0, 0.0, -1.0], [-1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float64)
        )
        self.left_orientation_matrix = (
            np.asarray(left_orientation_matrix, dtype=np.float64)
            if left_orientation_matrix is not None
            else np.eye(3, dtype=np.float64)
        )
        self.right_orientation_matrix = (
            np.asarray(right_orientation_matrix, dtype=np.float64)
            if right_orientation_matrix is not None
            else np.eye(3, dtype=np.float64)
        )
        self.stream_timeout_sec = float(stream_timeout_sec)


class TeleopStepResult:
    """Relative teleoperation output compatible with the legacy API."""

    def __init__(self):
        self.waiting_for_poses: bool = False
        self.should_publish_left: bool = False
        self.should_publish_right: bool = False
        self.left_command: List[float] = []
        self.right_command: List[float] = []
        self.ik_time_ms: float = 0.0
        self.error: Optional[str] = None
        self.left_target_transform: Optional[np.ndarray] = None
        self.right_target_transform: Optional[np.ndarray] = None
        self.left_current_transform: Optional[np.ndarray] = None
        self.right_current_transform: Optional[np.ndarray] = None
        self.left_link4_target: Optional[np.ndarray] = None
        self.right_link4_target: Optional[np.ndarray] = None


@dataclass
class TeleopCoreStepResult:
    active_mode: Optional[str] = None
    target_q: Optional[np.ndarray] = None
    left_active: bool = False
    right_active: bool = False
    waiting_for_joint_states: bool = False
    calibration_required: bool = False
    error: Optional[str] = None
    left_target_transform: Optional[np.ndarray] = None
    right_target_transform: Optional[np.ndarray] = None


class PinocchioTeleopCore:
    """Encapsulates IK, relative/absolute semantics, and mode arbitration."""

    def __init__(self, config: TeleopConfig):
        self.config = config
        self.ik_solver = OpenArmXIKSolver(config.urdf_path)

        self.joint_positions: Dict[str, float] = {}
        self.joint_states_received = False
        self.absolute_mode_selected = False
        self.absolute_mode_text = "relative"
        self.absolute_calibrated = False

        self.body_anchor = None
        self.user_frame_rot = None
        self.left_reference_rel_user = None
        self.right_reference_rel_user = None
        self.left_reference_rot = None
        self.right_reference_rot = None
        self.left_ee_calib = None
        self.right_ee_calib = None

        self.relative_left_enabled = False
        self.relative_right_enabled = False
        self.relative_left_reference_robot = None
        self.relative_right_reference_robot = None

    def update_joint_states(self, joint_names, joint_positions):
        for name, position in zip(joint_names, joint_positions):
            self.joint_positions[name] = float(position)
        self.joint_states_received = True

    def update_absolute_mode(self, mode_text: str):
        mode = str(mode_text).strip().lower()
        self.absolute_mode_text = mode
        self.absolute_mode_selected = mode == "absolute"

    def calibrate_absolute(self, absolute_input: AbsoluteTeleopInputFrame) -> bool:
        if (
            absolute_input.head_pose is None
            or absolute_input.left_pose is None
            or absolute_input.right_pose is None
        ):
            return False

        head_pos = absolute_input.head_pose.position.copy()
        left_pos = absolute_input.left_pose.position.copy()
        right_pos = absolute_input.right_pose.position.copy()

        self.user_frame_rot = self._yaw_rotation_from_quaternion(
            *absolute_input.head_pose.orientation_xyzw
        )
        self.body_anchor = head_pos + self.user_frame_rot @ self.config.body_anchor_offset

        initial_left_reference = self.user_frame_rot.T @ (left_pos - self.body_anchor)
        initial_right_reference = self.user_frame_rot.T @ (right_pos - self.body_anchor)
        lateral_center_offset = 0.5 * (
            initial_left_reference[0] + initial_right_reference[0]
        )
        self.body_anchor = self.body_anchor + self.user_frame_rot[:, 0] * lateral_center_offset

        self.left_reference_rel_user = self.user_frame_rot.T @ (left_pos - self.body_anchor)
        self.right_reference_rel_user = self.user_frame_rot.T @ (right_pos - self.body_anchor)
        self.left_reference_rot = self._quaternion_to_rotation_matrix(
            *absolute_input.left_pose.orientation_xyzw
        )
        self.right_reference_rot = self._quaternion_to_rotation_matrix(
            *absolute_input.right_pose.orientation_xyzw
        )

        # Pico calibration UI asks the user to place controllers at the robot
        # zero-pose correspondence, so the robot-side anchor must be formal
        # zero pose rather than the current joint state.
        current_q = np.zeros(self.ik_solver.nq, dtype=np.float64)
        self.left_ee_calib, self.right_ee_calib = self.ik_solver.get_end_effector_transforms(
            current_q
        )
        self.absolute_calibrated = True
        return True

    def step(
        self,
        relative_input: RelativeTeleopInputFrame,
        absolute_input: AbsoluteTeleopInputFrame,
    ) -> TeleopCoreStepResult:
        result = TeleopCoreStepResult()
        result.active_mode = self._resolve_active_mode(relative_input, absolute_input)
        if result.active_mode is None:
            return result

        current_q = self.get_current_joint_positions()
        if current_q is None:
            result.waiting_for_joint_states = True
            return result

        if result.active_mode == "relative":
            return self._step_relative(relative_input, current_q)
        return self._step_absolute(absolute_input, current_q)

    def compute_absolute_capture_targets(
        self, absolute_input: AbsoluteTeleopInputFrame
    ) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        if not self.absolute_mode_selected or not self.absolute_calibrated:
            return None
        if absolute_input.left_pose is None or absolute_input.right_pose is None:
            return None

        return self._compute_absolute_targets(
            absolute_input,
            left_active=True,
            right_active=True,
            current_q=self.get_current_joint_positions(),
        )

    def get_current_joint_positions(self):
        if not self.joint_states_received:
            return None
        joint_names = [
            "openarmx_left_joint1",
            "openarmx_left_joint2",
            "openarmx_left_joint3",
            "openarmx_left_joint4",
            "openarmx_left_joint5",
            "openarmx_left_joint6",
            "openarmx_left_joint7",
            "openarmx_right_joint1",
            "openarmx_right_joint2",
            "openarmx_right_joint3",
            "openarmx_right_joint4",
            "openarmx_right_joint5",
            "openarmx_right_joint6",
            "openarmx_right_joint7",
        ]
        values = []
        for name in joint_names:
            current = self.joint_positions.get(name)
            if current is None:
                return None
            values.append(float(current))
        return np.asarray(values, dtype=np.float64)

    def _step_relative(self, relative_input: RelativeTeleopInputFrame, current_q: np.ndarray):
        result = TeleopCoreStepResult()
        result.active_mode = "relative"
        self._update_relative_enable_state("left", relative_input.left_pose, relative_input.left_grip, current_q)
        self._update_relative_enable_state("right", relative_input.right_pose, relative_input.right_grip, current_q)

        left_enabled = self.relative_left_enabled and self._stream_active(relative_input.left_pose)
        right_enabled = self.relative_right_enabled and self._stream_active(relative_input.right_pose)
        result.left_active = left_enabled
        result.right_active = right_enabled
        if not left_enabled and not right_enabled:
            return result

        left_current, right_current = self.ik_solver.get_end_effector_transforms(current_q)
        left_target = left_current
        right_target = right_current

        if left_enabled and relative_input.left_pose is not None and self.relative_left_reference_robot is not None:
            left_target = self._build_relative_target_transform(
                relative_input.left_pose, self.relative_left_reference_robot
            )
        if right_enabled and relative_input.right_pose is not None and self.relative_right_reference_robot is not None:
            right_target = self._build_relative_target_transform(
                relative_input.right_pose, self.relative_right_reference_robot
            )

        target_q, _ = self.ik_solver.solve_ik(left_target, right_target, current_q=current_q)
        result.target_q = target_q
        result.left_target_transform = left_target
        result.right_target_transform = right_target
        return result

    def _step_absolute(self, absolute_input: AbsoluteTeleopInputFrame, current_q: np.ndarray):
        result = TeleopCoreStepResult()
        result.active_mode = "absolute"
        if not self.absolute_calibrated:
            result.calibration_required = True
            return result

        left_active = absolute_input.left_grip > self.config.grip_threshold
        right_active = absolute_input.right_grip > self.config.grip_threshold
        result.left_active = left_active
        result.right_active = right_active
        if not left_active and not right_active:
            return result

        if absolute_input.head_pose is None:
            result.error = "absolute head pose missing"
            return result
        if left_active and absolute_input.left_pose is None:
            result.error = "absolute left pose missing"
            return result
        if right_active and absolute_input.right_pose is None:
            result.error = "absolute right pose missing"
            return result

        left_target, right_target = self._compute_absolute_targets(
            absolute_input,
            left_active=left_active,
            right_active=right_active,
            current_q=current_q,
        )
        target_q, _ = self.ik_solver.solve_ik(left_target, right_target, current_q=current_q)
        result.target_q = target_q
        result.left_target_transform = left_target
        result.right_target_transform = right_target
        return result

    def _compute_absolute_targets(
        self,
        absolute_input: AbsoluteTeleopInputFrame,
        *,
        left_active: bool,
        right_active: bool,
        current_q: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        left_current, right_current = self.ik_solver.get_end_effector_transforms(current_q)
        left_target = left_current
        right_target = right_current

        if left_active and absolute_input.left_pose is not None:
            left_target = self._build_absolute_target_transform(
                absolute_input.left_pose,
                self.left_reference_rel_user,
                self.left_reference_rot,
                self.left_ee_calib,
                self.config.left_axis_matrix,
                self.config.left_orientation_matrix,
            )
        if right_active and absolute_input.right_pose is not None:
            right_target = self._build_absolute_target_transform(
                absolute_input.right_pose,
                self.right_reference_rel_user,
                self.right_reference_rot,
                self.right_ee_calib,
                self.config.right_axis_matrix,
                self.config.right_orientation_matrix,
            )
        return left_target, right_target

    def _resolve_active_mode(
        self,
        relative_input: RelativeTeleopInputFrame,
        absolute_input: AbsoluteTeleopInputFrame,
    ) -> Optional[str]:
        relative_stream_active = (
            self._stream_active(relative_input.left_pose)
            or self._stream_active(relative_input.right_pose)
        )
        if relative_stream_active:
            return "relative"

        absolute_stream_active = (
            self._stream_active(absolute_input.left_pose)
            or self._stream_active(absolute_input.right_pose)
        )
        if absolute_stream_active and self.absolute_mode_selected and self.absolute_calibrated:
            return "absolute"
        return None

    def _update_relative_enable_state(
        self, arm: str, pose: Optional[PoseInput], grip: float, current_q: np.ndarray
    ):
        enabled_attr = f"relative_{arm}_enabled"
        reference_attr = f"relative_{arm}_reference_robot"
        is_enabled = getattr(self, enabled_attr)

        if grip > self.config.grip_threshold:
            if (not is_enabled) and (pose is not None):
                left_tf, right_tf = self.ik_solver.get_end_effector_transforms(current_q)
                reference_tf = left_tf if arm == "left" else right_tf
                setattr(
                    self,
                    reference_attr,
                    {
                        "position": reference_tf[:3, 3].copy(),
                        "rotation": reference_tf[:3, :3].copy(),
                    },
                )
                setattr(self, enabled_attr, True)
        else:
            setattr(self, enabled_attr, False)

    def _build_relative_target_transform(self, pose: PoseInput, reference):
        delta_pos = pose.position.copy()
        delta_rot = self._quaternion_to_rotation_matrix(*pose.orientation_xyzw)
        ref_pos = reference["position"]
        ref_rot = reference["rotation"]

        target = np.eye(4, dtype=np.float64)
        target[:3, :3] = ref_rot @ delta_rot
        target[:3, 3] = ref_pos + ref_rot @ delta_pos
        return target

    def _build_absolute_target_transform(
        self,
        pose: PoseInput,
        reference_rel_user: np.ndarray,
        reference_rot: np.ndarray,
        ee_calib: np.ndarray,
        axis_matrix: np.ndarray,
        orientation_matrix: np.ndarray,
    ):
        current_pos = pose.position.copy()
        current_rel_world = current_pos - self.body_anchor
        current_rel_user = self.user_frame_rot.T @ current_rel_world
        delta_user = current_rel_user - reference_rel_user

        delta_robot = self.config.position_scale_xyz * (axis_matrix @ delta_user)

        target = ee_calib.copy()
        target[:3, 3] = ee_calib[:3, 3] + delta_robot

        current_rot = self._quaternion_to_rotation_matrix(*pose.orientation_xyzw)
        delta_rot = reference_rot.T @ current_rot
        mapped_delta_rot = orientation_matrix @ delta_rot @ orientation_matrix.T
        target[:3, :3] = ee_calib[:3, :3] @ self._normalize_rotation(mapped_delta_rot)
        return target

    def _stream_active(self, pose: Optional[PoseInput]) -> bool:
        if pose is None or pose.timestamp <= 0.0:
            return False
        return (self._now() - pose.timestamp) <= self.config.stream_timeout_sec

    @staticmethod
    def _quaternion_to_rotation_matrix(qx, qy, qz, qw):
        return np.array(
            [
                [1 - 2 * (qy**2 + qz**2), 2 * (qx * qy - qw * qz), 2 * (qx * qz + qw * qy)],
                [2 * (qx * qy + qw * qz), 1 - 2 * (qx**2 + qz**2), 2 * (qy * qz - qw * qx)],
                [2 * (qx * qz - qw * qy), 2 * (qy * qz + qw * qx), 1 - 2 * (qx**2 + qy**2)],
            ],
            dtype=np.float64,
        )

    @staticmethod
    def _normalize_rotation(rotation):
        u, _, vt = np.linalg.svd(rotation)
        normalized = u @ vt
        if np.linalg.det(normalized) < 0.0:
            u[:, -1] *= -1.0
            normalized = u @ vt
        return normalized

    @staticmethod
    def _yaw_rotation_from_quaternion(qx, qy, qz, qw):
        rotation = PinocchioTeleopCore._quaternion_to_rotation_matrix(qx, qy, qz, qw)
        yaw = np.arctan2(rotation[0, 2], rotation[2, 2])
        cy = np.cos(yaw)
        sy = np.sin(yaw)
        return np.array(
            [
                [cy, 0.0, sy],
                [0.0, 1.0, 0.0],
                [-sy, 0.0, cy],
            ],
            dtype=np.float64,
        )

    @staticmethod
    def _now() -> float:
        import time

        return float(time.monotonic())


class OpenArmTeleopController:
    """Backward-compatible relative teleop controller API backed by Pinocchio."""

    def __init__(
        self,
        config: TeleopConfig,
        log_info=None,
        log_warn=None,
        log_error=None,
    ):
        self.config = config
        self.core = PinocchioTeleopCore(config)
        self.left_joint_names = [f"openarmx_left_joint{i}" for i in range(1, 8)]
        self.right_joint_names = [f"openarmx_right_joint{i}" for i in range(1, 8)]
        self.joint_positions = self.core.joint_positions
        self.joint_states_received = False

    def update_joint_states(self, joint_names, joint_positions):
        self.core.update_joint_states(joint_names, joint_positions)
        self.joint_positions = self.core.joint_positions
        self.joint_states_received = self.core.joint_states_received

    def step(self, frame: TeleopInputFrame) -> TeleopStepResult:
        relative_input = RelativeTeleopInputFrame(
            left_pose=self._relative_pose_to_pose_input(frame.left_pose),
            right_pose=self._relative_pose_to_pose_input(frame.right_pose),
            left_grip=frame.left_grip,
            right_grip=frame.right_grip,
            left_trigger=frame.left_trigger,
            right_trigger=frame.right_trigger,
        )
        absolute_input = AbsoluteTeleopInputFrame(
            head_pose=None,
            left_pose=None,
            right_pose=None,
            left_grip=0.0,
            right_grip=0.0,
            left_trigger=0.0,
            right_trigger=0.0,
            mode_selected=False,
        )
        core_result = self.core.step(relative_input, absolute_input)

        result = TeleopStepResult()
        if core_result.waiting_for_joint_states:
            result.error = "joint_states not received"
            return result
        if core_result.target_q is None:
            result.waiting_for_poses = True
            return result

        result.should_publish_left = core_result.left_active
        result.should_publish_right = core_result.right_active
        if core_result.left_active:
            result.left_command = core_result.target_q[:7].tolist() + [
                max(0.0, min(1.0, float(frame.left_trigger))) * 0.04
            ]
        if core_result.right_active:
            result.right_command = core_result.target_q[7:14].tolist() + [
                max(0.0, min(1.0, float(frame.right_trigger))) * 0.04
            ]
        result.left_target_transform = core_result.left_target_transform
        result.right_target_transform = core_result.right_target_transform
        return result

    @staticmethod
    def _relative_pose_to_pose_input(pose: Optional[RelativePose]) -> Optional[PoseInput]:
        if pose is None:
            return None
        return PoseInput(
            position=np.asarray(pose.position, dtype=np.float64),
            orientation_xyzw=pose.orientation_xyzw,
            timestamp=float(getattr(pose, "timestamp", 0.0)),
        )