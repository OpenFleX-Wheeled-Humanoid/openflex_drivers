#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   can_utils.py
@Time    :   2025/12/10 17:13:01
@Author  :   Wei Lindong
@Version :   1.0
@Desc    :   CAN接口通用工具函数库
             包含CAN接口检测、启用、验证等标准接口
'''


import subprocess
import re
import time
import functools

# 支持的CAN驱动模块
CAN_DRIVER_KCAN = "kcan"
CAN_DRIVER_PEAK_USB = "peak_usb"
SUPPORTED_CAN_DRIVERS = (CAN_DRIVER_KCAN, CAN_DRIVER_PEAK_USB)

# 导入统一日志工具
try:
    from .log_utils import log_output
except ImportError:
    # 如果作为脚本运行
    import sys
    import os
    parent_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, parent_dir)
    from log_utils import log_output


#**************************************************************************
# CAN驱动装饰器
#**************************************************************************

def _is_driver_loaded(driver):
    """检查内核模块是否已加载（lsmod）"""
    try:
        result = subprocess.run(
            ["lsmod"],
            capture_output=True, text=True, check=True
        )
        return any(
            line.split()[0] == driver
            for line in result.stdout.splitlines()
            if line
        )
    except Exception:
        return False


def require_can_driver(func):
    """
    装饰器：在执行前确保CAN驱动已加载。

    从被装饰函数的关键字参数中读取 driver / verbose / log / password，
    若驱动未加载则自动调用 load_can_driver 加载；已加载则跳过。

    适用于所有需要CAN接口存在才能正常工作的函数。

    示例:
        @require_can_driver
        def enable_can_interface(interface, ..., driver=CAN_DRIVER_KCAN, ...):
            ...
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        driver  = kwargs.get("driver",   CAN_DRIVER_KCAN)
        verbose = kwargs.get("verbose",  True)
        log     = kwargs.get("log",      None)
        password = kwargs.get("password", None)

        if not _is_driver_loaded(driver):
            if not load_can_driver(driver=driver, verbose=verbose, log=log, password=password):
                return False
        elif verbose:
            log_output(f"✓ CAN driver '{driver}' already loaded, skipping modprobe", "INFO", log)

        return func(*args, **kwargs)
    return wrapper


#**************************************************************************
# CAN接口检测相关函数
#**************************************************************************

def get_available_can_interfaces(log=None):
    """
    自动检测系统中所有可用且已启用的CAN接口

    参数:
        log (callable): 日志函数，默认None（使用print）

    返回:
        list: 可用的CAN接口列表，例如 ['can0', 'can1']

    示例:
        >>> from lib.can_utils import get_available_can_interfaces
        >>> can_interfaces = get_available_can_interfaces()
        >>> print(can_interfaces)
        ['can0', 'can1', 'can2']

    说明:
        - 使用 'ip link show' 命令检测系统中的网络接口
        - 只返回状态为 UP 的 CAN 接口
        - 按照 can 编号排序（can0, can1, can2...）
        - 如果检测失败，返回空列表
    """
    try:
        # 使用 ip link show 列出所有网络接口
        result = subprocess.run(
            ['ip', 'link', 'show'],
            capture_output=True,
            text=True,
            check=True
        )

        # 提取所有UP状态的can接口
        can_interfaces = []
        lines = result.stdout.split('\n')

        for i, line in enumerate(lines):
            # 匹配 can 接口名称
            match = re.search(r'^\d+:\s+(can\d+):', line)
            if match:
                can_name = match.group(1)

                # 检查接口状态（在同一行或下一行）
                status_line = line
                if i + 1 < len(lines):
                    status_line += ' ' + lines[i + 1]

                # 只添加 UP 状态的接口
                if 'UP' in status_line:
                    can_interfaces.append(can_name)

        # 按照can号排序
        can_interfaces.sort(key=lambda x: int(x.replace('can', '')))

        return can_interfaces

    except subprocess.CalledProcessError as e:
        log_output(f"⚠ Failed to detect CAN interfaces: {e}", "ERROR", log)
        return []
    except Exception as e:
        log_output(f"⚠ Error while detecting CAN interfaces: {e}", "ERROR", log)
        return []


def get_all_can_interfaces(log=None):
    """
    检测系统中所有的CAN接口（包括未启用的）

    参数:
        log (callable): 日志函数，默认None（使用print）

    返回:
        list: 所有CAN接口列表，例如 ['can0', 'can1', 'can2']

    示例:
        >>> from lib.can_utils import get_all_can_interfaces
        >>> all_interfaces = get_all_can_interfaces()
        >>> print(all_interfaces)
        ['can0', 'can1', 'can2', 'can3']

    说明:
        - 检测所有CAN接口，不管是否已启用
        - 先使用 'ip link show' 检测
        - 如果未找到，尝试从 /sys/class/net/ 检测
        - 按照 can 编号排序
    """
    try:
        # 方法1: 使用 ip link show 列出所有网络接口
        result = subprocess.run(
            ['ip', 'link', 'show'],
            capture_output=True,
            text=True,
            check=True
        )

        # 提取所有can接口名称
        can_interfaces = []
        for line in result.stdout.split('\n'):
            match = re.search(r'^\d+:\s+(can\d+):', line)
            if match:
                can_name = match.group(1)
                can_interfaces.append(can_name)

        # 方法2: 如果方法1没找到，尝试直接检查 /sys/class/net/
        if not can_interfaces:
            import os
            net_dir = '/sys/class/net'
            if os.path.exists(net_dir):
                for iface in os.listdir(net_dir):
                    if iface.startswith('can'):
                        can_interfaces.append(iface)

        # 按照can号排序
        can_interfaces.sort(key=lambda x: int(x.replace('can', '')))

        return can_interfaces

    except subprocess.CalledProcessError as e:
        log_output(f"⚠ Failed to detect CAN interfaces: {e}", "ERROR", log)
        return []
    except Exception as e:
        log_output(f"⚠ Error while detecting CAN interfaces: {e}", "ERROR", log)
        return []


def check_can_interface_type(interface, log=None):
    """
    检查CAN接口类型，判断是否为虚拟接口

    参数:
        interface (str): CAN接口名称，如 'can0'
        log (callable): 日志函数，默认None（使用print）

    返回:
        bool: True=真实接口, False=虚拟接口

    示例:
        >>> from lib.can_utils import check_can_interface_type
        >>> is_real = check_can_interface_type('can0')
        >>> print(f"can0 是真实接口: {is_real}")

    说明:
        - 使用 'ip -details link show' 检查接口详细信息
        - 虚拟接口（vcan）会被识别为 False
        - 真实硬件CAN接口返回 True
        - 出错时默认返回 True（假设为真实接口）
    """
    try:
        result = subprocess.run(
            ['ip', '-details', 'link', 'show', interface],
            capture_output=True,
            text=True,
            check=False
        )

        output = result.stdout.lower()

        # 排除vcan虚拟接口
        if 'vcan' in output:
            return False

        # 检查是否是真实的CAN设备
        if 'link/can' in output or 'can state' in output:
            return True

        return True  # 默认认为是真实接口

    except Exception:
        return True  # 出错时默认尝试启用


def verify_can_interface(interface, log=None):
    """
    验证CAN接口是否已成功启用

    参数:
        interface (str): CAN接口名称，如 'can0'
        log (callable): 日志函数，默认None（使用print）

    返回:
        bool: True=已启用(UP状态), False=未启用

    示例:
        >>> from lib.can_utils import verify_can_interface
        >>> is_up = verify_can_interface('can0')
        >>> print(f"can0 状态: {'UP' if is_up else 'DOWN'}")

    说明:
        - 使用 'ip link show' 检查接口状态
        - 只有状态为 UP 时返回 True
        - 接口不存在或DOWN状态返回 False
    """
    try:
        result = subprocess.run(
            ['ip', 'link', 'show', interface],
            capture_output=True,
            text=True,
            check=True
        )

        # 检查接口状态
        if 'UP' in result.stdout:
            return True
        else:
            return False

    except subprocess.CalledProcessError:
        return False


#**************************************************************************
# CAN接口配置相关函数
#**************************************************************************

def enable_can_interface(interface, bitrate=1000000, loopback=False, driver=CAN_DRIVER_KCAN, verbose=True, log=None, password=None):
    """
    启用单个CAN接口（标准接口函数）

    参数:
        interface (str): CAN接口名称，如 'can0'
        bitrate (int): 波特率，默认1000000 (1Mbps)
        loopback (bool): 是否启用loopback模式，默认False
        driver (str): CAN驱动模块名称，默认 'kcan'，支持 'kcan' / 'peak_usb'
                      由 @require_can_driver 装饰器读取并处理，函数体内不直接使用
        verbose (bool): 是否显示详细信息，默认True
        log (callable): 日志函数，默认None（使用print）
        password (str): sudo密码，默认None（手动输入密码）

    返回:
        bool: True=成功, False=失败

    示例:
        >>> from lib.can_utils import enable_can_interface
        >>> # 启用can0，1Mbps波特率，不显示详细信息
        >>> success = enable_can_interface('can0', bitrate=1000000, verbose=False)
        >>> if success:
        >>>     print("CAN接口启用成功")
        >>>
        >>> # 使用密码自动输入
        >>> success = enable_can_interface('can0', password='your_password')

    说明:
        - 执行步骤：加载驱动(modprobe，由装饰器处理) -> down接口 -> 配置参数 -> up接口
        - 需要sudo权限
        - 如果提供password参数，将自动输入密码；否则需要手动输入
        - 默认关闭loopback模式
        - 失败时返回False，不抛出异常
    """
    # driver 由 @require_can_driver 装饰器读取，函数体内不使用
    _ = driver
    if verbose:
        log_output(f"\n{'='*50}", "INFO", log)
        log_output(f"Configuring: {interface}", "INFO", log)
        log_output(f"{'='*50}", "INFO", log)

    loopback_str = "on" if loopback else "off"

    commands = [
        f"ip link set down {interface}",
        f"ip link set {interface} type can bitrate {bitrate} loopback {loopback_str}",
        f"ip link set up {interface}"
    ]

    for cmd in commands:
        if verbose:
            log_output(f"  Executing: sudo {cmd}", "INFO", log)

        try:
            if password is not None:
                # 使用密码自动输入
                # echo 'password' | sudo -S command
                full_cmd = f"echo '{password}' | sudo -S {cmd}"
                result = subprocess.run(
                    full_cmd,
                    shell=True,
                    check=True,
                    capture_output=True,
                    text=True
                )
            else:
                # 手动输入密码
                result = subprocess.run(
                    f"sudo {cmd}",
                    shell=True,
                    check=True,
                    capture_output=True,
                    text=True
                )

            if verbose:
                log_output(f"  ✓ Success", "SUCCESS", log)

        except subprocess.CalledProcessError as e:
            if verbose:
                log_output(f"  ✗ Failed: {e.stderr.strip()}", "ERROR", log)
            return False

    # 等待CAN接口完全初始化（解决重新拔插USB后立即通信失败的问题）
    # CAN硬件和驱动需要额外的初始化时间才能真正准备好收发数据
    if verbose:
        log_output(f"  Waiting for {interface} to be fully ready...", "INFO", log)

    if verbose:
        log_output(f"✓ {interface} enabled successfully!", "SUCCESS", log)

    return True


def disable_can_interface(interface, verbose=True, log=None, password=None):
    """
    禁用单个CAN接口（标准接口函数）

    参数:
        interface (str): CAN接口名称，如 'can0'
        verbose (bool): 是否显示详细信息，默认True
        log (callable): 日志函数，默认None（使用print）
        password (str): sudo密码，默认None（手动输入密码）

    返回:
        bool: True=成功, False=失败

    示例:
        >>> from lib.can_utils import disable_can_interface
        >>> success = disable_can_interface('can0')
        >>> if success:
        >>>     print("CAN接口禁用成功")
        >>>
        >>> # 使用密码自动输入
        >>> success = disable_can_interface('can0', password='your_password')

    说明:
        - 执行 'sudo ip link set down' 命令
        - 需要sudo权限
        - 如果提供password参数，将自动输入密码；否则需要手动输入
        - 失败时返回False，不抛出异常
    """
    if verbose:
        log_output(f"\n{'='*50}", "INFO", log)
        log_output(f"Disabling: {interface}", "INFO", log)
        log_output(f"{'='*50}", "INFO", log)

    cmd = f"ip link set down {interface}"

    try:
        if password is not None:
            # 使用密码自动输入
            full_cmd = f"echo '{password}' | sudo -S {cmd}"
            result = subprocess.run(
                full_cmd,
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )
        else:
            # 手动输入密码
            result = subprocess.run(
                f"sudo {cmd}",
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )

        if verbose:
            log_output(f"✓ {interface} disabled successfully", "SUCCESS", log)

        return True

    except subprocess.CalledProcessError as e:
        if verbose:
            log_output(f"✗ Failed to disable {interface}: {e.stderr.strip()}", "ERROR", log)
        return False


@require_can_driver
def enable_all_can_interfaces(bitrate=1000000, loopback=False, driver=CAN_DRIVER_KCAN, verbose=True, log=None, password=None):
    """
    启用所有检测到的CAN接口（批量操作）

    参数:
        bitrate (int): 波特率，默认1000000 (1Mbps)
        loopback (bool): 是否启用loopback模式，默认False
        driver (str): CAN驱动模块名称，默认 'kcan'，支持 'kcan' / 'peak_usb'
                      由 @require_can_driver 装饰器读取并处理，函数体内不直接使用
        verbose (bool): 是否显示详细信息，默认True
        log (callable): 日志函数，默认None（使用print）
        password (str): sudo密码，默认None（手动输入密码）

    返回:
        dict: {interface: success}，例如 {'can0': True, 'can1': False}

    示例:
        >>> from lib.can_utils import enable_all_can_interfaces
        >>> results = enable_all_can_interfaces(bitrate=1000000, verbose=True)
        >>> for iface, success in results.items():
        >>>     print(f"{iface}: {'成功' if success else '失败'}")
        >>>
        >>> # 使用密码自动输入
        >>> results = enable_all_can_interfaces(password='your_password')

    说明:
        - 自动检测所有CAN接口（包括未启用的）
        - 过滤掉虚拟接口（vcan）
        - 逐个启用，返回每个接口的结果
        - 需要sudo权限
        - 如果提供password参数，将自动输入密码；否则需要手动输入
    """
    if verbose:
        log_output("="*60, "INFO", log)
        log_output("      Enabling CAN Interfaces in Batch", "INFO", log)
        log_output("="*60, "INFO", log)

    # 检测所有CAN接口
    all_interfaces = get_all_can_interfaces(log=log)

    if not all_interfaces:
        if verbose:
            log_output("✗ No CAN interfaces detected", "WARNING", log)
        return {}

    # 过滤真实接口
    real_interfaces = [iface for iface in all_interfaces if check_can_interface_type(iface, log=log)]

    if not real_interfaces:
        if verbose:
            log_output("✗ No real CAN interfaces found (only virtual interfaces)", "WARNING", log)
        return {}

    if verbose:
        log_output(f"Detected {len(real_interfaces)} real CAN interface(s): {', '.join(real_interfaces)}", "INFO", log)
        log_output("", "INFO", log)

    # 逐个启用
    results = {}
    tt = time.time()
    for iface in real_interfaces:
        success = enable_can_interface(iface, bitrate=bitrate, loopback=loopback, driver=driver, verbose=verbose, log=log, password=password)
        results[iface] = success

    # 显示总结
    if verbose:
        log_output("\n" + "="*60, "INFO", log)
        success_count = sum(1 for s in results.values() if s)
        if success_count == len(results):
            log_output(f"Enable result: {success_count}/{len(results)} succeeded", "SUCCESS", log)
        elif success_count > 0:
            log_output(f"Enable result: {success_count}/{len(results)} succeeded", "WARNING", log)
        else:
            log_output(f"Enable result: {success_count}/{len(results)} succeeded", "ERROR", log)
        log_output("="*60, "INFO", log)
    return results


def disable_all_can_interfaces(verbose=True, log=None, password=None):
    """
    禁用所有检测到的CAN接口（批量操作）

    参数:
        verbose (bool): 是否显示详细信息，默认True
        log (callable): 日志函数，默认None（使用print）
        password (str): sudo密码，默认None（手动输入密码）

    返回:
        dict: {interface: success}，例如 {'can0': True, 'can1': False}

    示例:
        >>> from lib.can_utils import disable_all_can_interfaces
        >>> results = disable_all_can_interfaces(verbose=True)
        >>> for iface, success in results.items():
        >>>     print(f"{iface}: {'成功' if success else '失败'}")
        >>>
        >>> # 使用密码自动输入
        >>> results = disable_all_can_interfaces(password='your_password')

    说明:
        - 自动检测所有已启用的CAN接口
        - 过滤掉虚拟接口（vcan）
        - 逐个禁用，返回每个接口的结果
        - 需要sudo权限
        - 如果提供password参数，将自动输入密码；否则需要手动输入
    """
    if verbose:
        log_output("="*60, "INFO", log)
        log_output("      Disabling CAN Interfaces in Batch", "INFO", log)
        log_output("="*60, "INFO", log)

    # 检测所有已启用的CAN接口
    active_interfaces = get_available_can_interfaces(log=log)

    if not active_interfaces:
        if verbose:
            log_output("✗ No active CAN interfaces detected", "WARNING", log)
            log_output("Hint: All CAN interfaces may already be in DOWN state", "INFO", log)
        return {}

    # 过滤真实接口
    real_interfaces = [iface for iface in active_interfaces if check_can_interface_type(iface, log=log)]

    if not real_interfaces:
        if verbose:
            log_output("✗ No real CAN interfaces found (only virtual interfaces)", "WARNING", log)
        return {}

    if verbose:
        log_output(f"Detected {len(real_interfaces)} active real CAN interface(s): {', '.join(real_interfaces)}", "INFO", log)
        log_output("", "INFO", log)

    # 逐个禁用
    results = {}
    for iface in real_interfaces:
        success = disable_can_interface(iface, verbose=verbose, log=log, password=password)
        results[iface] = success

    # 显示总结
    if verbose:
        log_output("\n" + "="*60, "INFO", log)
        success_count = sum(1 for s in results.values() if s)
        if success_count == len(results):
            log_output(f"Disable result: {success_count}/{len(results)} succeeded", "SUCCESS", log)
        elif success_count > 0:
            log_output(f"Disable result: {success_count}/{len(results)} succeeded", "WARNING", log)
        else:
            log_output(f"Disable result: {success_count}/{len(results)} succeeded", "ERROR", log)
        log_output("="*60, "INFO", log)

    return results


def load_can_driver(driver=CAN_DRIVER_KCAN, verbose=True, log=None, password=None):
    """
    加载CAN内核驱动模块（modprobe）

    参数:
        driver (str): 驱动模块名称，支持 'kcan' 或 'peak_usb'，默认 'kcan'
        verbose (bool): 是否显示详细信息，默认True
        log (callable): 日志函数，默认None（使用print）
        password (str): sudo密码，默认None（手动输入密码）

    返回:
        bool: True=加载成功且检测到CAN接口, False=失败

    示例:
        >>> from lib.can_utils import load_can_driver, CAN_DRIVER_KCAN, CAN_DRIVER_PEAK_USB
        >>> # 加载 kcan 驱动
        >>> success = load_can_driver(CAN_DRIVER_KCAN, password='your_password')
        >>> # 加载 peak_usb 驱动
        >>> success = load_can_driver(CAN_DRIVER_PEAK_USB, verbose=False)

    说明:
        - 执行 'sudo modprobe <driver>' 加载内核模块
        - 加载后等待最多3秒，轮询确认CAN接口出现
        - 需要sudo权限
        - 如果提供password参数，将自动输入密码；否则需要手动输入
        - 不支持的驱动名称直接返回False
    """
    if driver not in SUPPORTED_CAN_DRIVERS:
        log_output(f"✗ Unsupported driver: '{driver}'. Supported: {SUPPORTED_CAN_DRIVERS}", "ERROR", log)
        return False

    if verbose:
        log_output("=" * 50, "INFO", log)
        log_output(f"Loading CAN driver: {driver}", "INFO", log)
        log_output("=" * 50, "INFO", log)

    cmd = f"modprobe {driver}"

    try:
        if password is not None:
            full_cmd = f"echo '{password}' | sudo -S {cmd}"
            subprocess.run(
                full_cmd,
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )
        else:
            subprocess.run(
                f"sudo {cmd}",
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )
    except subprocess.CalledProcessError as e:
        log_output(f"✗ modprobe {driver} failed: {e.stderr.strip()}", "ERROR", log)
        return False

    if verbose:
        log_output(f"✓ modprobe {driver} executed, waiting for interfaces...", "INFO", log)

    # 轮询等待CAN接口出现，最多3秒
    for _ in range(6):
        interfaces = get_all_can_interfaces(log=None)
        if interfaces:
            if verbose:
                log_output(f"✓ Driver loaded, detected: {', '.join(interfaces)}", "SUCCESS", log)
            return True
        time.sleep(0.5)

    log_output(f"✗ Driver loaded but no CAN interfaces detected after 3s", "WARNING", log)
    return False

def pair_can_channels(available_channels):
    """
    将可用的CAN通道按固定规则配对为双臂机器人
    配对规则：偶数通道(右臂) - 奇数通道(左臂)
              can0(右) - can1(左), can2(右) - can3(左), can4(右) - can5(左)...
    只有当一组中的两个通道都可用时，才保留该组

    参数：
        available_channels: 可用的CAN通道列表（字符串格式，如 ['can0', 'can1']）

    返回：
        有效的配对组列表（右臂, 左臂），例如：[('can0', 'can1'), ('can2', 'can3')]
        每个元组的格式：(right_arm_channel, left_arm_channel)
    """
    # 从字符串中提取通道号（'can0' -> 0）
    channel_numbers = []
    for channel in available_channels:
        # 提取 'can' 后面的数字部分
        if channel.startswith('can'):
            try:
                num = int(channel[3:])  # 提取 'can' 之后的数字
                channel_numbers.append(num)
            except ValueError:
                continue

    # 将可用通道号转换为集合，方便查找
    available_set = set(channel_numbers)

    # 存储有效的配对组
    valid_pairs = []

    # 查找最大的通道号，以确定需要检查的配对范围
    if channel_numbers:
        max_channel = max(channel_numbers)

        # 按固定规则检查配对：偶数通道(右臂) - 奇数通道(左臂)
        for i in range(0, max_channel + 2, 2):
            right_arm_channel = i      # 右臂：偶数通道 (0, 2, 4, 6...)
            left_arm_channel = i + 1   # 左臂：奇数通道 (1, 3, 5, 7...)

            # 只有当两个通道都可用时，才保留该组
            if right_arm_channel in available_set and left_arm_channel in available_set:
                valid_pairs.append((f'can{right_arm_channel}', f'can{left_arm_channel}'))
                print(f"✓ Found valid pair: right_arm can{right_arm_channel} - left_arm can{left_arm_channel}")
            elif right_arm_channel in available_set or left_arm_channel in available_set:
                # 如果只有一个通道可用，给出提示
                if right_arm_channel in available_set:
                    print(f"✗ Incomplete pair: right_arm can{right_arm_channel} available, but left_arm can{left_arm_channel} missing, excluded")
                else:
                    print(f"✗ Incomplete pair: left_arm can{left_arm_channel} available, but right_arm can{right_arm_channel} missing, excluded")

    return valid_pairs